import numpy as NP
from numpy import random as NP_RND

class GRAPH_MATCH_CLASS(object):

    def __init__(self,
                 i_graph1_matrix: NP.ndarray,
                 i_graph2_matrix: NP.ndarray,
                 i_population_multiple_of_16: int,
                 i_lin_kernighan_mutation_probability: 
                 NP.float64 = 0.005,
                 i_simple_transposition_mutation_probability: 
                 NP.float64 = 0.005,
                 i_supervised_selection: bool = True):

        super(GRAPH_MATCH_CLASS, self).__init__()
        # The first column is the station. It is not included in
        # the permutations.

        i_ok = True

        if i_population_multiple_of_16 & 15 > 0:
            print('Error: i_population_multiple_of_16 must be a'
                  ' multiple of 16!')
            i_ok = False

        if i_graph1_matrix.ndim != 2 or i_graph2_matrix.ndim != 2:
            print('ERROR: Graph matrices must be two dimensional!')
            i_ok = False
        elif i_graph1_matrix.shape[0] != i_graph1_matrix.shape[1]:
            print('ERROR: Graph matrices must be square, not rectangular!')
            i_ok = False
        elif i_graph1_matrix.shape != i_graph2_matrix.shape:
            print('ERROR: The two graphs must have the same dimensions!')
            i_ok = False
        elif (i_graph1_matrix < 0).any() or (i_graph2_matrix < 0).any():
            print('ERROR: Matrix entries must be >= 0 !')
            i_ok = False

        if not i_ok:
            self.member_n = 0
            self.member_population = 0
            self.member_lin_kernighan_mutation_probability = 0
            self.member_transposition_probability = 0
            self.member_perm_matrix = None
            self.member_graph1_matrix = None
            self.member_graph2_matrix = None
            return

        self.member_n = i_graph1_matrix.shape[0]
        self.member_population = i_population_multiple_of_16
        self.member_supervised_selection = i_supervised_selection

        self.member_lin_kernighan_mutation_probability = \
            i_lin_kernighan_mutation_probability
        self.member_transposition_probability = \
            i_simple_transposition_mutation_probability

        self.member_perm_matrix = \
            NP.zeros((i_population_multiple_of_16, self.member_n), 
                     dtype=int)

        self.member_graph1_matrix = i_graph1_matrix.copy()
        self.member_graph2_matrix = i_graph2_matrix.copy()

        self.member_last_best = None
        self.member_stagnancy_counter = 0
        self.member_start_power = 0.004
        self.member_end_power = 0.001
        self.meber_lowest_power = self.member_start_power

        for i in range(self.member_population):
            self.member_perm_matrix[i, :] = \
                NP.random.permutation(self.member_n)


    def function_score(self, s_perm_arr:NP.ndarray) -> \
            NP.float64:

        if not GRAPH_MATCH_CLASS.function_check_validity(s_perm_arr):
            return None

        # Get a permutated second graph matrix.
        # We look for the best permutation.
        s_perm_graph2_matrix = \
            self.member_graph2_matrix[s_perm_arr, :][:, s_perm_arr]

        # Calculate the sum of squared deltas between the graphs.
        s_delta = \
            ((s_perm_graph2_matrix - \
              self.member_graph1_matrix) ** 2).sum()

        return s_delta


    def function_delta(self, d_perm_arr1: NP.ndarray,
                       d_perm_arr2: NP.ndarray) -> \
            NP.float64:

        # This function is used by the supervised evolution.
        # It checks the similarity to the leading gene.
        # Similarity destroys genes diversity.

        if not GRAPH_MATCH_CLASS.function_check_validity(d_perm_arr1) or \
            not GRAPH_MATCH_CLASS.function_check_validity(d_perm_arr2):
            return None

        d_perm_graph1_matrix = \
            self.member_graph2_matrix[d_perm_arr1, :][:, d_perm_arr1]

        d_perm_graph2_matrix = \
            self.member_graph2_matrix[d_perm_arr2, :][:, d_perm_arr2]

        # Calculate the sum of squared deltas between the graphs.
        d_delta = \
            ((d_perm_graph2_matrix - d_perm_graph1_matrix) ** 2).sum()

        return d_delta


    # def function_cosine(self, c_perm_arr1:NP.ndarray,
    #                     c_perm_arr2:NP.ndarray) -> \
    #         NP.float64:
    #
    #     # This function is used by the supervised evolution.
    #     # It checks the similarity to the leading gene.
    #     # Similarity destroys genes diversity.
    #
    #     if not GRAPH_MATCH_CLASS.function_check_validity(c_perm_arr1) or \
    #         not GRAPH_MATCH_CLASS.function_check_validity(c_perm_arr2):
    #         return None
    #
    #     # Get a permutated second graph matrix.
    #     # We look for the best permutation.
    #     c_perm_graph1_matrix = \
    #         self.member_graph2_matrix[c_perm_arr1, :][:, c_perm_arr1]
    #
    #     c_perm_graph2_matrix = \
    #         self.member_graph2_matrix[c_perm_arr2, :][:, c_perm_arr2]
    #
    #     # ------------------------------------------
    #     # Start: Calculate the cosine similarity.
    #     #        It is used in supervised evolution.
    #     # ------------------------------------------
    #     c_dot = (c_perm_graph1_matrix * c_perm_graph2_matrix).sum()
    #     c_ssum1 = (c_perm_graph1_matrix ** 2).sum()
    #     c_ssum2 = (c_perm_graph2_matrix ** 2).sum()
    #     c_denom = NP.sqrt(c_ssum1 * c_ssum2)
    #     c_cosine = c_dot / max(c_denom, 0.00000001)
    #     # ------------------------------------------
    #     # End: Calculate the cosine similarity.
    #     # ------------------------------------------
    #
    #     return c_cosine

    def function_cosine2(self, c_bad_delta_matrix: NP.ndarray,
                         c_perm_arr2:NP.ndarray) -> \
            NP.float64:

        # This function is used by the supervised evolution.
        # It checks the similarity to the leading gene.
        # Similarity destroys genes diversity.

        if not GRAPH_MATCH_CLASS.function_check_validity(c_perm_arr2):
            return None

        # Get a permutated second graph matrix.
        # We look for the best permutation.

        c_perm_graph2_matrix = \
            self.member_graph2_matrix[c_perm_arr2, :][:, c_perm_arr2]

        # ------------------------------------------
        # Start: Calculate the cosine similarity.
        #        It is used in supervised evolution.
        # ------------------------------------------
        c_dot = (c_bad_delta_matrix * c_perm_graph2_matrix).sum()
        c_ssum = (c_bad_delta_matrix ** 2).sum()
        c_cosine = c_dot / max(c_ssum, 0.00000001)
        # ------------------------------------------
        # End: Calculate the cosine similarity.
        # ------------------------------------------

        return c_cosine

    # ********************************************************
    # Start: Crossing-over, Lin-Kernighan, and transpositions.
    # ********************************************************

    @staticmethod
    def function_check_validity(cv_perm: NP.array):

        cv_n = cv_perm.shape[0]

        if cv_perm.max() >= cv_n:
            return False

        cv_counts = NP.zeros(cv_n, dtype=int)

        cv_counts[cv_perm] += 1

        return cv_counts.min() == cv_counts.max() == 1

    @staticmethod
    def function_cross_perm(cp_perm1: NP.array, cp_perm2: NP.array):

        # --------------------------------
        # Start: check arguments validity.
        # --------------------------------

        if cp_perm1.ndim != cp_perm2.ndim or cp_perm1.ndim != 1:
            return None

        if cp_perm1.shape[0] != cp_perm2.shape[0] or \
                cp_perm1.shape[0] < 1:
            return None

        if 1 == cp_perm1.shape[0]:
            if cp_perm1[0] == cp_perm2[0]:
                return cp_perm1
            else:
                return None

        cp_n = cp_perm1.shape[0]

        if cp_perm1.max() >= cp_n or cp_perm2.max() >= cp_n:
            return None

        # --------------------------------
        # End: check arguments validity.
        # --------------------------------

        cp_inverse2 = NP.zeros(cp_n, dtype=NP.int32)
        cp_new_perm = NP.zeros(cp_n, dtype=NP.int32)

        for i in range(cp_n):
            cp_inverse2[cp_perm2[i]] = i

        cp_cycles_arr = -1 * NP.ones(cp_n, dtype=NP.int32)

        cp_cycle_count = 0

        # -------------------------------------------------------
        # Start: deconstruct the permutations into common cycles.
        # -------------------------------------------------------

        for i in range(cp_n):
            cp_scan_idx = i

            if cp_cycles_arr[cp_scan_idx] > -1:
                continue

            while -1 == cp_cycles_arr[cp_scan_idx]:
                cp_cycles_arr[cp_scan_idx] = cp_cycle_count
                cp_in_perm1 = cp_perm1[cp_scan_idx]
                cp_scan_idx = cp_inverse2[cp_in_perm1]

            cp_cycle_count += 1

        # -------------------------------------------------------
        # End: deconstruct the permutations into common cycles.
        # -------------------------------------------------------

        # -------------------------------------------------------
        # Start: from each matching cycle choose from cp_perm1 or
        #        from cp_perm2.
        # -------------------------------------------------------

        cp_chosen_cycle = NP.zeros(cp_cycle_count, dtype=bool)

        for cp_cycle in range(cp_cycle_count):
            cp_chosen_cycle[cp_cycle] = bool(NP_RND.randint(2))

        for i in range(cp_n):
            cp_cycle = cp_cycles_arr[i]
            if cp_chosen_cycle[cp_cycle]:
                cp_new_perm[i] = cp_perm1[i]
            else:
                cp_new_perm[i] = cp_perm2[i]

        # -------------------------------------------------------
        # End: from each matching cycle choose from cp_perm1 or
        #      from cp_perm2.
        # -------------------------------------------------------

        return cp_new_perm

    @staticmethod
    def function_transpositions(t_perm, t_perm_probability=0.005):

        t_n = t_perm.shape[0]

        for i in range(t_n-1):
            if NP.random.uniform() < t_perm_probability:
                continue

            k = NP.random.randint(i, t_n)

            t_perm[i], t_perm[k] = t_perm[k], t_perm[i]


        return

    @staticmethod
    def function_perm_reflect(pr_perm, pr_start, pr_end):

        # There is no need to reflect a subsequence where the
        # end is before the start because such a Lin - Kernighan
        # mutation is equivalent to starting from pr_end and ending
        # in pr_start, regarding the TSP/TSA problem.

        if pr_end < pr_start:

            pr_end, pr_start = pr_start, pr_end

        if pr_end == pr_start or pr_end >= pr_perm.shape[0] or \
                pr_start < 0:
            print('Error, reflection start, end indices are incorrect!')
            print(f'Wasted choice of reflection: start={pr_start},'
                  f' end={pr_end}')
            return

        pr_mid = (1 + pr_start + pr_end) >> 1

        for i in range(pr_start, pr_mid):
            k = pr_end - i + pr_start
            pr_perm[i], pr_perm[k] = pr_perm[k], pr_perm[i]

        return


    @staticmethod
    def function_perm_jump(pj_perm, pj_start, pj_count, pj_advance):
        '''
        from pj_start up to pj_start+pj_count cyclically, advance pj_advance
        '''
        if pj_count < 1 or pj_advance < 1:
            print('Error: jump parameter too small.')
            print(f'Wasted choice of jump: count={pj_count},'
                  f' from={pj_start}')
            return

        pj_n = pj_perm.shape[0]

        pj_count2 = pj_n - pj_count - pj_advance

        if 0 == pj_count2:
            print('Error: pj_n = pj_count + pj_advance.')
            print(f'Wasted choice of jump: '
                  f'count={pj_count}, from={pj_start}, jump={pj_advance}')
            return

        if pj_count2 < 0:
            print('Error: pj_count + pj_advance must be smaller'
                  ' than the length.')
            print(f'Wasted choice of jump: '
                  f'count={pj_count}, from={pj_start}, jump={pj_advance}')


        pj_arr = NP.zeros(pj_n, int)

        pj_idx0 = (pj_start + pj_count) % pj_n

        for i in range(pj_advance):

            pj_arr[i] = pj_perm[pj_idx0]

            pj_idx0 += 1

            if pj_idx0 >= pj_n:
                pj_idx0 = 0

        pj_idx1 = pj_start

        for k in range(pj_count):

            # In the previous look i does not reac pj_advance.
            # That is why i has to be incremented first.
            i += 1

            if i >= pj_n:
                i = 0

            pj_arr[i] = pj_perm[pj_idx1]

            pj_idx1 += 1

            if pj_idx1 >= pj_n:
                pj_idx1 = 0

        pj_idx2 = pj_idx0

        for k in range(pj_count2):

            i += 1

            if i >= pj_n:
                i = 0

            pj_arr[i] = pj_perm[pj_idx2]

            pj_idx2 += 1

            if pj_idx2 >= pj_n:
                pj_idx2 = 0

        for i in range(pj_n):
            pj_perm[i] = pj_arr[i]

        return

    # ********************************************************
    # End: Crossing-over, Lin-Kernighan, and transpositions.
    # ********************************************************


    def function_fitness(self, f_generation: int, f_validate=False) -> \
            (NP.float64, NP.ndarray):

        assert self.member_graph1_matrix is not None, \
            "Initialization error!"

        f_ordinary_fitness = NP.zeros(self.member_population, 
                                      dtype=NP.float64)

        if self.member_supervised_selection and \
                self.member_stagnancy_counter > 300:
            f_supervised_selection_on = True
            self.member_lowest_power *= 0.99
            if self.member_lowest_power < self.member_end_power:
                self.member_lowest_power = self.member_end_power

        else:
            f_supervised_selection_on = False
            self.member_lowest_power = self.member_start_power

        if f_supervised_selection_on:
            # Start: For evolutionary stagnation, enhance diversity.
            f_sixteenth_population = self.member_population >> 4
            f_leading_population = f_sixteenth_population
            f_special_population1 = f_sixteenth_population
            f_special_population2 = f_sixteenth_population
            f_weak_population = f_sixteenth_population
        else:
            f_eighth_population = self.member_population >> 3
            f_leading_population = f_eighth_population
            f_special_population1 = 0
            f_special_population2 = 0
            f_weak_population = f_eighth_population


        # A quarter of the population survives and is further
        # divided into 4 subsets.

        f_weak_population_offset = \
            f_leading_population + f_special_population1 + \
            f_special_population2
        f_surviving_population = \
            f_leading_population + f_special_population1 + \
            f_special_population2 + f_weak_population

        # f_ones_arr = NP.ones(self.member_n, dtype=NP.int32)
        # f_ordered_arr = NP.array([i for i in range(self.member_n)],
        #                          dtype=NP.int32)

        # -----------------------------------------------------
        # Start: sort by ordinary fitness with best ones first.
        # -----------------------------------------------------

        for i in range(self.member_population):

            # The smaller delta is the better delta.
            f_ordinary_fitness[i] = \
                self.function_score(self.member_perm_matrix[i, :])

        f_sorted_indices = NP.argsort(f_ordinary_fitness)

        f_best_index = f_sorted_indices[0]
        f_leading_index = f_best_index
        f_best = f_ordinary_fitness[f_best_index]
        f_leading_score = f_best

        if self.member_last_best is None:
            self.member_stagnancy_counter = 0
            self.member_last_best = f_best
        elif (f_best < self.member_last_best - 0.1):
            # Reset evolutionary stagnation counter.
            self.member_stagnancy_counter = 0
            self.member_last_best = f_best
        else:
            # Increment evolutionary stagnation counter.
            self.member_stagnancy_counter += 1

        f_leading_perm = self.member_perm_matrix[f_best_index, :]
        f_matrix = \
            self.member_graph2_matrix[f_leading_perm, :][:, f_leading_perm]

        if f_supervised_selection_on:
            f_leading_bad_delta_matrix = \
                NP.where(self.member_graph1_matrix < f_matrix, 1.0, 0.0)
        else:
            f_leading_bad_delta_matrix = None

        f_perm_matrix = NP.zeros((f_surviving_population, self.member_n),
                                 dtype=int)

        for i in range(f_leading_population):
            k = f_sorted_indices[i]
            f_perm_matrix[i, :] = self.member_perm_matrix[k, :]
            print(f'Gen {f_generation},  ordinary distance({i} <- '
                  f'{k}) {f_ordinary_fitness[k]}')

        # -----------------------------------------------------
        # End: sort by ordinary fitness with best ones first.
        # -----------------------------------------------------

        # -------------------------------------------------------
        # Start: Supervised evolution part 1.
        #        Sort by special fitness.
        #        It slows down the convergence of the first
        #        generations but is necessary for gene diversity.
        # -------------------------------------------------------

        if f_supervised_selection_on:
            # For evolutionary stagnation.
            f_cosine_array = NP.zeros(self.member_population,
                                      dtype=NP.float64)

            for i in range(self.member_population):
                f_cosine_array[i] =\
                    self.function_cosine2(f_leading_bad_delta_matrix,
                                          self.member_perm_matrix[i, :])

            # f_rate = NP.power(0.00390625, 1/f_special_population1)
            f_rate = NP.power(self.member_lowest_power,
                              1 / f_special_population1)

            f_power1 = 1
        else:
            f_cosine_array, f_rate, f_power1 = None, None, None


        for f_special in range(f_special_population1):
            f_power1 *= f_rate
            f_power2 = 1 - f_power1

            f_best_index = 0
            f_best_fitness = None
            f_best_similarity = 0

            for i in range(self.member_population):

                f_score = f_ordinary_fitness[i]
                f_similarity = f_cosine_array[i]

                # The first value of f_power2 is very small so,
                # f_score will be almost multiplied by 1.
                # As f_power2 grows, the score is punished for similarity.
                # The objective here is a smaller, not a bigger score.
                # It is a supervised selection algorithm that slows down
                # evolution but keeps gene diversity.
                f_score *= NP.power(f_similarity, f_power2)

                if f_best_fitness is None:
                    f_best_fitness = f_score
                    f_best_index = i
                    f_best_similarity = f_similarity
                elif f_best_fitness > f_score:
                    f_best_fitness = f_score
                    f_best_index = i
                    f_best_similarity = f_similarity

            f_cur_index = f_special + f_leading_population

            f_perm_matrix[f_cur_index, :] = \
                self.member_perm_matrix[f_best_index, :]

            print(f'Gen {f_generation}, '
                  f'enhanced distance 1 ({f_cur_index} <- {f_best_index}) '
                  f'similarity {f_best_similarity}, {f_best_fitness},'
                  f' best={f_best}, stagnancy '
                  f'{self.member_stagnancy_counter}')

        # -------------------------------------------------------
        # End: Supervised evolution part 1.
        #      Sort by special fitness.
        #      It slows down the convergence of the first
        #      generations but is necessary for gene diversity.
        # -------------------------------------------------------

        # -------------------------------------------------------
        # Start: Supervised evolution part 2.
        #        Sort by special fitness.
        #        It slows down the convergence of the first
        #        generations but is necessary for gene diversity.
        # -------------------------------------------------------

        if f_supervised_selection_on:
            # For evolutionary stagnation.
            f_difference_array = NP.zeros(self.member_population,
                                          dtype=NP.int32)

            for i in range(self.member_population):
                f_difference_array[i] =\
                    self.function_delta(self.member_perm_matrix[i, :],
                                        self.member_perm_matrix
                                        [f_leading_index, :])

            f_power = 1
        else:
            f_difference_array = None
            f_power = None

        for f_special in range(f_special_population2):
            f_power *= f_rate

            f_best_index = 0
            f_best_fitness = None
            f_best_delta = 0

            for i in range(self.member_population):

                f_difference1 = f_difference_array[i]
                f_difference = NP.power(f_difference1, 1 - f_power)

                f_score = f_ordinary_fitness[i]

                f_score /= (1 + f_difference)

                if f_best_fitness is None:
                    f_best_fitness = f_score
                    f_best_index = i
                    f_best_delta = f_difference1
                elif f_best_fitness > f_score:
                    f_best_fitness = f_score
                    f_best_index = i
                    f_best_delta = f_difference1

            f_cur_index = \
                f_special + f_special_population1 + \
                f_leading_population
            f_perm_matrix[f_cur_index, :] = \
                self.member_perm_matrix[f_best_index, :]

            print(f'Gen {f_generation}, '
                  f'enhanced distance 2 ({f_cur_index} <- '
                  f'{f_best_index}) '
                  f'{f_best_fitness}, delta {f_best_delta}, '
                  f'best={f_best}, '
                  f'stagnancy {self.member_stagnancy_counter}')

        # -----------------------------------------------------
        # End: sort by special fitness with best ones first.
        # -----------------------------------------------------

        # ---------------------------------------------------------------
        # Start: fill-in some weak population to avoid semi-local minima.
        #        Slowing down convergence but necessary.
        # ---------------------------------------------------------------

        for i in range(f_weak_population):
            k = NP.random.randint(f_leading_population,
                                  self.member_population)
            k = f_sorted_indices[k]
            f_perm_matrix[f_weak_population_offset + i, :] = \
                self.member_perm_matrix[k, :]

            print(f'Gen {f_generation}, '
                  f'ordinary weak ({f_weak_population_offset + i}'
                  f' <- {k}) '
                  f'{f_ordinary_fitness[k]}, best {f_best}, '
                  f'stagnancy {self.member_stagnancy_counter}')

        # ---------------------------------------------------------------
        # End: fill-in some weak population to avoid semi-local minima.
        # ---------------------------------------------------------------

        # ---------------------------
        # ---------------------------
        # Start: generate offspring.
        # Survive 25%. Offspring 75%.
        # ---------------------------
        # ---------------------------

        self.member_perm_matrix[0:f_surviving_population, :] = \
            f_perm_matrix

        for i in range(f_surviving_population, self.member_population):
            f_idx1 = NP.random.randint(0, f_surviving_population)
            f_idx2 = NP.random.randint(0, f_surviving_population)

            # Crossover permutations.
            self.member_perm_matrix[i, :] = \
                (GRAPH_MATCH_CLASS.
                 function_cross_perm(self.member_perm_matrix[f_idx1, :],
                                     self.member_perm_matrix[f_idx2, :]))

            if f_validate:
                if not (GRAPH_MATCH_CLASS.
                        function_check_validity(self.member_perm_matrix[i, :])):
                    print('ERROR after crossing over.')
                    raise Exception(f'ERROR after crossing over at index {i}')

            if NP.random.uniform() >= \
                    self.member_lin_kernighan_mutation_probability:

                f_n = self.member_n

                if NP.random.randint(0, 3) == 2:
                    f_start = NP.random.randint(0, f_n)
                    f_count = NP.random.randint(1, f_n - 1)
                    f_advance = NP.random.randint(1, f_n - f_count)
                    # Vertex zero is the station and it stays zero.
                    # That is the reason for the -= 1 and then += 1.
                    (GRAPH_MATCH_CLASS.
                     function_perm_jump(self.member_perm_matrix[i, :],
                                        f_start, f_count, f_advance))
                else:
                    f_start = NP.random.randint(0, f_n)
                    f_end = (f_start + 1 + NP.random.randint(0, f_n-1)) % f_n

                    (GRAPH_MATCH_CLASS.
                     function_perm_reflect(self.member_perm_matrix[i, :],
                                           f_start, f_end))

            else:
                # Vertex zero is the station and it stays zero.
                # That is the reason for the -= 1 and then += 1.
                (GRAPH_MATCH_CLASS.
                 function_transpositions(self.member_perm_matrix[i, :],
                                         t_perm_probability=
                                         self.member_transposition_probability))

        # --------------------------
        # --------------------------
        # End: generate offspring.
        # --------------------------
        # --------------------------

        return (f_leading_score,
                self.member_perm_matrix[0, :])


def main_check_operators():
    ma_perm1 = NP.array([1, 7, 3, 6, 2, 0, 5, 4])
    ma_perm2 = NP.array([2, 5, 1, 7, 3, 4, 6, 0])

    print(f'Permutation 1:\n{ma_perm1}')
    print(f'Permutation 2:\n{ma_perm2}')
    print('Cross-over test:')

    for _ in range(10):
        ma_perm = (GRAPH_MATCH_CLASS.
                   function_cross_perm(ma_perm1, ma_perm2))
        print(ma_perm)


    print(f'Before reflection: {ma_perm1}')
    GRAPH_MATCH_CLASS.function_perm_reflect(ma_perm1,0, ma_perm1.shape[0]-1)
    print(f'After reflection: {ma_perm1}')

    ma_perm3 = NP.array([0, 1, 2, 3, 4, 5, 6, 7])

    print(f'Before move: {ma_perm3}')
    #function_perm_move(ma_perm3, 5, 3, 2)
    # Move 3 numbers starting position 5 (cyclic), and move them 2 places forward cyclic.
    (GRAPH_MATCH_CLASS.
     function_perm_jump(ma_perm3, pj_start=5, pj_count=3, pj_advance=2))
    print(f'After move: {ma_perm3}')

    print(f'Before transpositions: {ma_perm3}')

    (GRAPH_MATCH_CLASS.
     function_transpositions(ma_perm3,
                             t_perm_probability=0.5))
    print(f'After transpositions: {ma_perm3}')


def main_check_gen_al():

    ma_n = 32
    ma_graph1 = NP.random.randint(low=0, high=2, size=(ma_n, ma_n))
    ma_perm = NP.random.permutation(ma_n)
    ma_graph2 = ma_graph1[ma_perm, :][:, ma_perm]

    ma_alg = GRAPH_MATCH_CLASS(i_graph1_matrix=ma_graph1,
                               i_graph2_matrix=ma_graph2,
                               i_population_multiple_of_16=480,
                               # If true, slows down evolution but helps
                               # even after convergence is hard to
                               # reverse.
                               i_supervised_selection=True)

    ma_found = None
    ma_d = None

    for ma_generation in range(8000):

        ma_d, ma_found = ma_alg.function_fitness(ma_generation+1)

        if ma_d < 1:
            break

    if ma_d is not None:
        print(f'Original: {ma_perm}')
        print(f'Found: {ma_found}')
        ma_graph3 = ma_graph2[ma_found, :][:, ma_found] - ma_graph1
        print('Delta between the reverse-permutated graph2 and graph1:')
        print(ma_graph3)

# if __name__ == '__main__':
#     main()
#     #main_check_operators()


if __name__ == '__main__':
    # main_check_operators()
    main_check_gen_al()

