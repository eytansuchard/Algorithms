import numpy as NP

class GENAL_HARD_CASE_CLASS(object):
    def __init__(self, i_n_bits: int = 32,
                 i_n_population: int = 480,
                 i_mutation_prob:float = 0.005,
                 i_mix: bool = True):

        assert 8 <= i_n_bits <= 63, "n needs to be between 8 and 63"

        assert i_n_population & 15 == 0, \
            "population number must be disvisble by 16"

        self.member_n_bits = i_n_bits
        self.member_n_population = i_n_population
        self.mutation_prob = i_mutation_prob

        # i_list = [i & 1 for i in range(i_n_bits)]

        i_list = [i & 1 for i in range(i_n_bits)]
        i_correct_bits_arr = NP.array(i_list, dtype=int)

        self.member_wrong_bits_arr = \
            i_correct_bits_arr ^ 1

        i_list = [NP.int64(1)<<i for i in range(i_n_bits)]
        self.member_powers_of_two = NP.array(i_list)

        i_mask = i_correct_bits_arr == 1

        self.member_target = self.member_powers_of_two[i_mask].sum()

        # Initialize the population.
        self.member_population_arr = \
            NP.random.randint(low=0, high=2,
                              size=(i_n_population, i_n_bits),
                              dtype=int)

    def function_crossover(self, c_arr1: NP.ndarray[int],
                           c_arr2: NP.ndarray[int]) -> \
            NP.ndarray[int]:

        c_perm = NP.random.permutation(self.member_n_bits)
        c_arr = NP.empty(self.member_n_bits, dtype=int)
        c_mid = self.member_n_bits >> 1
        c_arr[c_perm[:c_mid]] = c_arr1[c_perm[:c_mid]]
        c_arr[c_perm[c_mid:]] = c_arr2[c_perm[c_mid:]]
        return c_arr

    def function_mutation(self, m_arr) -> None:
        m_prob = NP.random.uniform(low=0.0, high=1.0, size=None)
        m_mask = m_prob <= self.mutation_prob
        m_arr[m_mask] ^= 1
        return None

    def function_score(self, s_arr: NP.ndarray[int]):
        # The smaller score the better in this case.
        s_mask = s_arr == 1

        s_sum_powers_of_two = \
            self.member_powers_of_two[s_mask].sum()

        s_mask = (self.member_wrong_bits_arr & s_arr) == 1

        s_denom = max(1, self.member_powers_of_two[s_mask].sum())

        return NP.abs(s_sum_powers_of_two - self.member_target) / s_denom

    # The selection algorithm.
    def function_fitness(self):

        f_quarter = self.member_n_population >> 2

        f_new_population_arr = \
            NP.zeros((self.member_n_population,
                      self.member_n_bits), dtype=int)

        f_scores_arr = \
            NP.zeros(self.member_n_population, dtype=NP.float64)

        # ---------------------------
        # Start: Sort the population.
        # ---------------------------

        # Sort the indices of the scores of the population.
        # The lower, the better. The goal is to minimize function_score.
        for i in range(self.member_n_population):
            f_scores_arr[i] = \
                self.function_score(self.member_population_arr[i, :])

        f_sorted_indices = NP.argsort(f_scores_arr)
        f_best_score = f_scores_arr[f_sorted_indices[0]]

        f_new_population_arr[:, :] = \
            self.member_population_arr[f_sorted_indices, :]

        # ---------------------------
        # End: Sort the population.
        # ---------------------------

        # -------------------------------
        # Start: Create a new population.
        # -------------------------------
        # ---------------------------------------------------------
        # Start: Use the best population to generate new offspring.
        #        Results are stored in the second and third
        #        quarters of the new population array.
        # ---------------------------------------------------------

        for i in range(f_quarter, self.member_n_population - f_quarter):

            # Start: Randomly select two indices from the best population.
            j = NP.random.randint(f_quarter - 1)
            k = j + 1 + NP.random.randint(f_quarter - j - 1)

            j = f_sorted_indices[j]
            k = f_sorted_indices[k]
            # End: Randomly select two indices from the best population.

            # Perform crossover.
            f_crossed = \
                self.function_crossover(self.member_population_arr[j, :],
                                        self.member_population_arr[k, :])

            # Perform mutations.
            self.function_mutation(f_crossed)

            f_new_population_arr[i, :] = f_crossed

        # ---------------------------------------------------------
        # End: Use the best population to generate new offspring.
        #      Results are stored in the second and third
        #      quarters of the new population array.
        # ---------------------------------------------------------

        # ------------------------------------------------------
        # Start: Use other population to generate new offspring.
        #        Some weak solutions are needed for diversity.
        #        This will be only a quarter of the new
        #        population. Results are stored as the last
        #        quarter of the new population array.
        # ------------------------------------------------------

        f_three_quarters = f_quarter * 3

        for i in range(f_three_quarters,
                       self.member_n_population):

            # Start: Randomly select two indices from the weaker 3
            #        quarters of the population.
            j = NP.random.randint(0, f_three_quarters - 1)
            k = j + 1 + \
                NP.random.randint(f_three_quarters - j - 1)

            j = f_sorted_indices[j + f_quarter]
            k = f_sorted_indices[k + f_quarter]

            # End: Randomly select two indices from the weaker 3
            #      quarters of the population.

            # Perform crossover.
            f_crossed = \
                self.function_crossover(self.member_population_arr[j, :],
                                        self.member_population_arr[k, :])

            # Perform mutations.
            self.function_mutation(f_crossed)

            f_new_population_arr[i, :] = f_crossed

        # ------------------------------------------------------
        # End: Use other population to generate new offspring.
        #      Some weak solutions are needed for diversity.
        #      This will be only a quarter of the new
        #      population. Results are stored as the last
        #      quarter of the new population array.
        # ------------------------------------------------------

        self.member_population_arr[:, :] = f_new_population_arr[:, :]

        return f_best_score, self.member_population_arr[0, :]

def main():
    ma_genal = GENAL_HARD_CASE_CLASS(i_n_bits=32)
    ma_three_quarters = ma_genal.member_n_population * 3 // 4

    for i in range(1000):
        ma_score, ma_bits = ma_genal.function_fitness()

        print(f'Generation {i}, leading gene ', end='')
        for k in range(ma_genal.member_n_bits):
            print(f'{ma_bits[k]}', end='')
        print(f', {ma_score:.6f}')
        print(f'Generation {i}, weaker population gene n=population*3/4: ',
              end='')
        for k in range(ma_genal.member_n_bits):
             print(f'{ma_genal.member_population_arr[ma_three_quarters, k]}',
                   end='')
        print('\n-------------')

        if ma_score < 0.001:
            break

    print('End.')

if __name__ == '__main__':
    main()
