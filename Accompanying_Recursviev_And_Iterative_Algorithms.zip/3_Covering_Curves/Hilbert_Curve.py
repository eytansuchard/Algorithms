import numpy as NP
from enum import Enum as ENUM_Enum

from PIL import Image as PIL_Image, ImageDraw as PIL_ImageDraw

class HILBERT_ORIENTATION(ENUM_Enum):
    USUAL = 0
    CLOCKWISE = 1
    ANTICLOCKWISE = 2

class HILBERT_CURVE_CLASS:

    def __init__(self, i_power_of_two: int = 5):

        i_w = 1 << i_power_of_two

        self.member_w = i_w # Maximal included.

        self.member_list = []

        self.member_list = self.function_hilbert(h_w = i_w)

        self.member_image_w = (self.member_w << 1) * 10 + 10

        self.member_image = \
            PIL_Image.new("RGB", (self.member_image_w, self.member_image_w), color="white")

        self.member_draw = PIL_ImageDraw.Draw(self.member_image)

        i_list = self.member_list.copy()

        while(len(i_list) > 0):
            i_x1, i_y1 = i_list.pop(0)
            i_x2, i_y2 = i_list.pop(0)

            if i_y2 < i_y1:
                i_y1, i_y2 = i_y2, i_y1

            if i_x2 < i_x1:
                i_x1, i_x2 = i_x2, i_x1

            i_x1 = ((i_x1 << 1) + 1) * 10
            i_y1 = ((i_y1 << 1) + 1) * 10
            i_x2 = ((i_x2 << 1) + 1) * 10 + 10
            i_y2 = ((i_y2 << 1) + 1) * 10 + 10

            self.member_draw.rectangle((i_x1, i_y1, i_x2, i_y2), fill="black")

        self.member_image.save('Hilbert_Fractal_Cover.png')

        return

    def function_rotate(self,
                        r_list: list[[int, int]],
                        r_x: int,
                        r_y: int,
                        r_w: int,
                        r_orientation: HILBERT_ORIENTATION):

        if r_orientation == HILBERT_ORIENTATION.CLOCKWISE:
            # Also flip up and down.
            r_rotation_matrix = \
                NP.array([[0, -1], [-1, 0]], dtype=int)

        elif r_orientation == HILBERT_ORIENTATION.ANTICLOCKWISE:
            # Also flip up and down.
            r_rotation_matrix = \
                NP.array([[0, 1], [1, 0]], dtype=int)
        else:
            r_rotation_matrix = None

        r_input_array = NP.array(r_list, dtype=int)

        if r_rotation_matrix is None:
            r_output_array = r_input_array
        else:
            # Can be written more efficiently. Clue, transfer more arguments.
            r_input_array = (r_input_array << 1) - r_w

            r_output_array = \
                ((r_rotation_matrix @ r_input_array.T).T + r_w) >> 1

        r_output_array[:, 0] += r_x
        r_output_array[:, 1] += r_y

        return r_output_array.tolist()


    def function_hilbert(self, h_w: int=32, h_x: int = 0, h_y: int = 0,
                         h_orientation: HILBERT_ORIENTATION = HILBERT_ORIENTATION.USUAL) -> list:
        if 1 == h_w:
            return []

        h_w >>= 1

        h_list1 = self.function_hilbert(h_w, 0, 0,
                                        HILBERT_ORIENTATION.ANTICLOCKWISE)

        h_list1.append((0, h_w - 1))
        h_list1.append((0, h_w))

        h_list2 = self.function_hilbert(h_w, 0, h_w)

        h_list2.append((h_w - 1, h_w))
        h_list2.append((h_w, h_w))

        h_list3 = self.function_hilbert(h_w, h_w, h_w)

        h_list3.append(((h_w << 1) - 1, h_w))
        h_list3.append(((h_w << 1) - 1, h_w - 1))

        h_list4 = self.function_hilbert(h_w, h_w, 0,
                                        HILBERT_ORIENTATION.CLOCKWISE)

        h_list = h_list1 + h_list2 + h_list3 + h_list4

        h_list = self.function_rotate(h_list, h_x, h_y,
                                      (h_w << 1) - 1, h_orientation)

        return h_list

def main():

    ma_hilbert = HILBERT_CURVE_CLASS(5)

    print('See: Hilbert_Fractal_Cover.png')

if __name__ == '__main__':
    main()

