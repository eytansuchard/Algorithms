'''
Fractals Vol. 13, No. 01, pp. 43-55 (2005)
SQUARE FRACTAL ALGORITHM
EYTAN H. SUCHARD
https://doi.org/10.1142/S0218348X05002763
'''

#import numpy as NP
from PIL import Image as PIL_Image, ImageDraw as PIL_ImageDraw


'''
This is the chosen orientation.
   ^
   |   
-> 0, 1
   3, 2
'''

SFA_FRACTAL_image_file_name = 'Suchard_Fractal_Cover.png'

class SFA_FRACTAL_CLASS:


    def __init__(self, i_power_of_two: int = 5):

        i_w = 1 << i_power_of_two

        self.member_w = i_w # Maximal included.

        self.member_deltas = ((0, -1), (1, 0), (0, 1), (-1, 0))

        self.member_out_dict = {(0, -1): (0, 0), (1, 0): (1, 0),
                                (0, 1): (1, 1), (-1, 0): (0, 1)}

        self.member_in_dict = {(0, -1): (1, 0), (1, 0): (1, 1),
                               (0, 1): (0, 1), (-1, 0): (0, 0)}

        self.member_cutoff_dict = {(0, -1): ((0, 0), (1, 0)),
                                   (1,  0): ((1, 0), (1, 1)),
                                   (0,  1): ((1, 1), (0, 1)),
                                   (-1, 0): ((0, 1), (0, 0))}

        self.member_list = []

        self.function_generate()

        self.member_image_w = ((self.member_w + 1) << 1) * 20 + 10

        self.member_image = \
            PIL_Image.new("RGB", (self.member_image_w, self.member_image_w),
                          color="white")

        self.member_draw = PIL_ImageDraw.Draw(self.member_image)

        for (i_x1, i_y1), (i_x2, i_y2) in self.member_list:
            if i_y2 < i_y1:
                i_y1, i_y2 = i_y2, i_y1

            if i_x2 < i_x1:
                i_x1, i_x2 = i_x2, i_x1

            i_x1 = ((i_x1 << 1) + 1) * 10
            i_y1 = ((i_y1 << 1) + 1) * 10
            i_x2 = ((i_x2 << 1) + 1) * 10 + 10
            i_y2 = ((i_y2 << 1) + 1) * 10 + 10

            self.member_draw.rectangle((i_x1, i_y1, i_x2, i_y2),
                                       fill="black")

        self.member_image.save(SFA_FRACTAL_image_file_name)

    def function_is_in_fractal1(self, iif_x: int, iif_y: int):
        iif_a = 1

        iif_max = max(iif_x, iif_y)

        while iif_a <= iif_max:
            iif_rx = iif_x & iif_a
            iif_ry = iif_y & iif_a

            if iif_rx == iif_ry and iif_rx > 0:
                return False
            elif iif_rx != iif_ry:
                return True

            iif_a <<= 1

        return True  # Will account for (0,0).


    def function_generate(self, g_in_x: int = 0, g_in_y: int = 0,
                          g_in_dx: int = 0, g_in_dy: int = 0):

        for g_dx, g_dy in self.member_deltas:

            if g_dx != -g_in_dx or g_dy != -g_in_dy:
                g_ok = True

                g_next_x = g_in_x + g_dx
                g_next_y = g_in_y + g_dy

                if g_next_x < 0 or g_next_x > self.member_w:
                    g_ok = False
                elif g_next_y < 0 or g_next_y > self.member_w:
                     g_ok = False
                elif not self.function_is_in_fractal1(g_next_x, g_next_y):
                     g_ok = False

                g_base_x = g_in_x << 1
                g_base_y = g_in_y << 1

                if not g_ok:

                    if g_dy == 1 and g_next_y < (self.member_w+1):

                        # ----------------------------------------------
                        # Start: special case, cover a node of the other
                        #        type.
                        # ----------------------------------------------

                        g_key = (g_dx, g_dy)

                        g_offset_x, g_offset_y = self.member_out_dict[g_key]
                        g_from_x = g_offset_x + g_base_x
                        g_from_y = g_offset_y + g_base_y
                        g_to_x = g_from_x + g_dx
                        g_to_y = g_from_y + g_dy

                        g_two_points = \
                            ((g_from_x, g_from_y), (g_to_x, g_to_y))

                        self.member_list. \
                            append(g_two_points)

                        g_next_base_x = g_next_x << 1
                        g_next_base_y = g_next_y << 1

                        g_two_points = \
                            ((g_next_base_x + 1, g_next_base_y),
                             (g_next_base_x + 1, g_next_base_y + 1))

                        self.member_list. \
                            append(g_two_points)

                        g_two_points = \
                            ((g_next_base_x + 1, g_next_base_y + 1),
                             (g_next_base_x, g_next_base_y + 1))

                        self.member_list. \
                            append(g_two_points)

                        g_two_points = \
                            ((g_next_base_x, g_next_base_y + 1),
                             (g_next_base_x, g_next_base_y))

                        self.member_list. \
                            append(g_two_points)

                        g_offset_x, g_offset_y = self.member_in_dict[g_key]
                        g_to_x = g_offset_x + g_base_x
                        g_to_y = g_offset_y + g_base_y
                        g_from_x = g_to_x + g_dx
                        g_from_y = g_to_y + g_dy
                        g_two_points = \
                            ((g_from_x, g_from_y),(g_to_x, g_to_y))

                        self.member_list.append(g_two_points)

                        # ----------------------------------------------
                        # End: special case, cover a node of the other
                        #      type.
                        # ----------------------------------------------

                    else:
                        (g_x1, g_y1), (g_x2, g_y2) =\
                            self.member_cutoff_dict[(g_dx, g_dy)]

                        g_two_points = \
                            ((g_base_x + g_x1, g_base_y + g_y1),
                             (g_base_x + g_x2, g_base_y + g_y2))

                        self.member_list.append(g_two_points)
                    # continue
                else:
                    g_key = (g_dx, g_dy)

                    g_offset_x, g_offset_y = self.member_out_dict[g_key]
                    g_from_x = g_offset_x + g_base_x
                    g_from_y = g_offset_y + g_base_y
                    g_to_x = g_from_x + g_dx
                    g_to_y = g_from_y + g_dy

                    g_two_points = \
                        ((g_from_x, g_from_y),(g_to_x, g_to_y))

                    self.member_list.\
                        append(g_two_points)

                    self.function_generate(g_next_x, g_next_y, g_dx, g_dy)

                    g_offset_x, g_offset_y = self.member_in_dict[g_key]
                    g_to_x = g_offset_x + g_base_x
                    g_to_y = g_offset_y + g_base_y
                    g_from_x = g_to_x + g_dx
                    g_from_y = g_to_y + g_dy

                    g_two_points = ((g_from_x, g_from_y),(g_to_x, g_to_y))

                    self.member_list.append(g_two_points)

        return


def main():
    ma_sfa = SFA_FRACTAL_CLASS()
    print('See: ' + SFA_FRACTAL_image_file_name)
    print('https://doi.org/10.1142/S0218348X05002763')

if __name__ == '__main__':
    main()

