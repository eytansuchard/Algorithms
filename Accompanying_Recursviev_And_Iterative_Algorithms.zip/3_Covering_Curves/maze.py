import numpy as NP
import random as RANDOM
from PIL import Image as PIL_Image, ImageDraw as PIL_ImageDraw
import bisect as BISECT

from typing import Union as TYPING_Union

# Maze code: Written by Eytan H. Suchard.
# Can be used and redistributed as is.

class GRAPH_SORTED_LIST:
    def __init__(self, i_list: TYPING_Union[list, None] = None):
        if i_list is None:
            self.member_list = []
        else:
            self.member_list = i_list.copy()

        self.member_list.sort()

    def function_add(self, a_item):
        BISECT.insort(self.member_list, a_item)

    def function_discard(self, d_item):
        # Find insertion point for the item
        i = BISECT.bisect_left(self.member_list, d_item)
        # Check if the item actually exists at that index.
        if i != len(self.member_list) and \
                self.member_list[i] == d_item:
            del self.member_list[i]  # Remove it safely.

    def function_remove(self, r_item):
        """Remove item, raise ValueError if not found."""
        i = BISECT.bisect_left(self.member_list, r_item)
        if i != len(self.member_list) and \
                self.member_list[i] == r_item:
            del self.member_list[i]
        else:
            raise ValueError(f"{r_item!r} not in GRAPH_SORTED_LIST")

    def function_index(self, i_item):
        """Return the index of item. Raise ValueError if not found."""
        i = BISECT.bisect_left(self.member_list, i_item)
        if i != len(self.member_list) and \
                self.member_list[i] == i_item:
            return i
        raise ValueError(f"{i_item!r} not in GRAPH_SORTED_LIST")

    def __contains__(self, c_item):
        # binary search for the item
        i = BISECT.bisect_left(self.member_list, c_item)
        return i != len(self.member_list) and \
            self.member_list[i] == c_item

    def __len__(self):
        return len(self.member_list)

    def __getitem__(self, g_index):
        return self.member_list[g_index]

    def __repr__(self):
        return f"SortedList({self.member_list})"


class GRAPH_CLASS:
    def __init__(self, i_height: int = 65, i_width: int = 65):

        if i_height > 2 and i_width > 2:
            self.member_array = NP.zeros(shape=(i_height, i_width), 
                                         dtype=bool)
            self.member_array[0, 0] = True
            self.member_edges = list()
            self.member_wave_front_list = GRAPH_SORTED_LIST([(0, 0)])
            self.member_n = i_height * i_width
            self.member_count_of_visited_nodes = 1

            self.member_image_width = ((i_width << 1) + 1) * 10
            self.member_image_height = ((i_height << 1) + 1) * 10

            self.member_start_y = 5
            self.member_start_x = 15
            self.member_end_y = self.member_image_height - 5
            self.member_end_x = self.member_image_width - 15
        else:
            self.member_array = None
            self.member_edges = None
            self.member_wave_front_list = None
            self.member_n = 0
            self.member_count_of_visited_nodes = 0
            self.member_image = None

            self.member_start_y = 0
            self.member_start_x = 0
            self.member_end_y = 0
            self.member_end_x = 0

            self.member_image_width = 0
            self.member_image_height = 0

        self.member_height = i_height
        self.member_width = i_width

        self.member_up_threshold = 0.8
        self.member_down_threshold = 0.8

        if self.member_edges is not None:

            self.function_fill()

            self.function_draw(d_is_enhanced=False)

            # ************************
            # Start: Enhance the maze.
            # ************************

            i_enhancements = 48
            i_max = 0
            i_best_edges = None

            for i in range(i_enhancements):
                print(f'Enhancement {i}')
                i_last_edges = self.member_edges.copy()
                i_prev_path_len = self.function_enhance()

                if i_max < i_prev_path_len:
                    i_max = i_prev_path_len
                    i_best_edges = i_last_edges

            i_path = []
            i_edges = GRAPH_SORTED_LIST(self.member_edges)
            i_ret = self.function_get_solution(i_edges, i_path)
            if i_ret:
                i_prev_path_len = len(i_path)
                if i_max < i_prev_path_len:
                    i_max = i_prev_path_len
                    i_best_edges = self.member_edges

            self.member_edges = i_best_edges

            # ************************
            # End: Enhance the maze.
            # ************************

            self.function_draw(d_is_enhanced=True)


    def function_draw(self, d_is_enhanced: bool):
        self.member_image = \
            PIL_Image.new("RGB", (self.member_image_width,
                                  self.member_image_height), 
                          color="white")

        self.member_draw = PIL_ImageDraw.Draw(self.member_image)

        self.member_draw.rectangle((10, 0, 20, 10), fill="black")
        self.member_draw.rectangle((self.member_image_width - 20,
                                    self.member_image_height - 20,
                                    self.member_image_width - 10,
                                    self.member_image_height),
                                   fill="black")

        for (d_y1, d_y2, d_x1, d_x2) in self.member_edges:
            if d_y2 < d_y1:
                d_y1, d_y2 = d_y2, d_y1

            if d_x2 < d_x1:
                d_x1, d_x2 = d_x2, d_x1

            d_x1 = ((d_x1 << 1) + 1) * 10
            d_y1 = ((d_y1 << 1) + 1) * 10
            d_x2 = ((d_x2 << 1) + 1) * 10 + 10
            d_y2 = ((d_y2 << 1) + 1) * 10 + 10

            self.member_draw.rectangle((d_x1, d_y1, d_x2, d_y2),
                                       fill="black")
        if d_is_enhanced:
            self.member_image.save('Maze_enhanced.png')

            self.function_solve()

            self.member_image.save('Solved_Maze_enhanced.png')
        else:
            self.member_image.save('Maze.png')

            self.function_solve()

            self.member_image.save('Solved_Maze.png')

    def function_solve(self, s_base_y: int = 5, 
                       s_base_x: int = 15) -> \
            bool:

        s_pixel = self.member_image.getpixel((s_base_x, s_base_y))

        if s_pixel[0] != 0:
            return False

        if s_base_y == self.member_end_y and \
                s_base_x == self.member_end_x:
            return True

        self.member_image.putpixel((s_base_x, s_base_y), (255, 0, 0))

        for s_dy, s_dx in ((-10, 0), (10, 0), (0, -10), (0, 10)):
            s_y = s_base_y + s_dy
            s_x = s_base_x + s_dx

            if s_y < 0 or s_y >= self.member_image_height:
                continue

            if s_x < 0 or s_x >= self.member_image_width:
                continue

            if self.function_solve(s_y, s_x):
                self.member_draw.line((s_base_x, s_base_y, s_x, s_y), 
                                      fill="red", width=3)

                return True

        self.member_image.putpixel((s_base_x, s_base_y), (0, 0, 0))

        return False


    def function_fill(self):

        f_indices = [0, 1, 2, 3]
        f_steps = ((-1, 0), (0, 1), (0, -1), (1, 0))

        while self.member_count_of_visited_nodes < self.member_n:

            # --------------------------------------------------------
            # Start: perform BFS loop for all the reachable points
            #        until this recursive step.
            # --------------------------------------------------------

            f_removal_list = []

            for (f_base_y, f_base_x) in self.member_wave_front_list:

                f_perm = RANDOM.sample(f_indices, k=4)
                f_all_neighbors_treated = True

                for i in range(4):
                    f_dy, f_dx = f_steps[f_perm[i]]

                    f_y = f_base_y + f_dy

                    if f_y < 0 or f_y >= self.member_height:
                        continue

                    f_x = f_base_x + f_dx

                    if f_x < 0 or f_x >= self.member_width:
                        continue

                    if self.member_array[f_y, f_x]:
                        continue

                    f_bfs = False

                    if f_dx < 0 or f_dy < 0:
                        if RANDOM.uniform(0, 1) > \
                                self.member_up_threshold:
                            f_bfs = True
                    else:
                        if RANDOM.uniform(0, 1) > \
                                self.member_down_threshold:
                            f_bfs = True

                    if f_bfs:
                        self.member_array[f_y, f_x] = True
                        self.member_wave_front_list.function_add((f_y,
                                                                  f_x))
                        self.member_edges.append((f_base_y, f_y,
                                                  f_base_x, f_x))
                        self.member_count_of_visited_nodes += 1
                        print(f'{self.member_count_of_visited_nodes}/'
                              f'{self.member_n}')
                    else:
                        f_all_neighbors_treated = False

                if f_all_neighbors_treated:
                    f_removal_list.append((f_base_y, f_base_x))

            for (f_base_y, f_base_x) in f_removal_list:
                self.member_wave_front_list.function_discard((f_base_y,
                                                              f_base_x))

            # --------------------------------------------------------
            # End: perform BFS loop for all the reachable points
            #      until this recursive step.
            # --------------------------------------------------------


    def function_get_solution(self, gs_edges: GRAPH_SORTED_LIST,
                              gs_path: list,
                              gs_y: int = 0, gs_x: int = 0,
                              gs_last_dy: int = 0 , 
                              gs_last_dx: int = 0,
                              gs_depth: int = 0) -> bool:

        if gs_y == self.member_height - 1 and \
                gs_x == self.member_width -1:
            return True

        if gs_depth > 900:
            return False

        gs_steps = ((-1, 0), (0, 1), (0, -1), (1, 0))

        # ----------------------------------------------------
        # Start: Search for the end of the maze.
        # ----------------------------------------------------

        for i in range(4):
            gs_dy, gs_dx = gs_steps[i]

            if gs_dy == -gs_last_dy and gs_dx == -gs_last_dx:
                continue

            gs_next_y = gs_y + gs_dy

            if gs_next_y < 0 or gs_next_y >= self.member_height:
                continue

            gs_next_x = gs_x + gs_dx

            if gs_next_x < 0 or gs_next_x >= self.member_width:
                continue

            gs_key = (gs_y, gs_next_y, gs_x, gs_next_x)
            gs_key1 = (gs_next_y, gs_y, gs_next_x, gs_x)

            if gs_key in gs_edges or gs_key1 in gs_edges:
                gs_path.append((gs_y, gs_next_y, gs_x, gs_next_x))

                gs_result = \
                    self.function_get_solution(gs_edges,
                                               gs_path,
                                               gs_next_y, gs_next_x,
                                               gs_dy, gs_dx, 
                                               gs_depth + 1)

                if gs_result:
                    return True

                gs_path.pop()

        # ----------------------------------------------------
        # End: Search for the end of the maze.
        # ----------------------------------------------------

        return False


    def function_find_alternative_edge(self, 
                                       fae_edges:
                                       GRAPH_SORTED_LIST,
                                       fae_removed_edge:
                                       tuple[int, int, int, int]):

        # This function is used to discover all reachable points
        # after an edge was removed from a spanning tree and to
        # return an alternative edge.

        fae_array = \
            NP.zeros(shape=(self.member_height,
                            self.member_width), dtype=bool)

        fae_next_list = [(0, 0)]
        fae_array[:, :] = False
        fae_unreachable_border = \
            NP.zeros(shape=fae_array.shape, dtype=int)
        fae_array[0, 0] = True

        fae_steps = ((-1, 0), (0, 1), (0, -1), (1, 0))

        # ----------------------------------------------------
        # Start: perform BFS loop for all the reachable points
        #        until this recursive step.
        # ----------------------------------------------------

        while len(fae_next_list) > 0:

            fae_wave_front_list = fae_next_list
            fae_next_list = []

            for (fae_base_y, fae_base_x) in fae_wave_front_list:

                for i in range(4):
                    fae_dy, fae_dx = fae_steps[i]

                    fae_y = fae_base_y + fae_dy

                    if fae_y < 0 or fae_y >= self.member_height:
                        continue

                    fae_x = fae_base_x + fae_dx

                    if fae_x < 0 or fae_x >= self.member_width:
                        continue

                    if fae_array[fae_y, fae_x]:
                        continue

                    fae_key = (fae_base_y, fae_y,
                               fae_base_x, fae_x)
                    fae_key1 = (fae_y, fae_base_y,
                                fae_x, fae_base_x)

                    # The following if statement is a fast search
                    # in SortedList.
                    if fae_key in fae_edges or \
                            fae_key1 in fae_edges:
                        fae_array[fae_y, fae_x] = True
                        fae_unreachable_border[fae_y, fae_x] = 1
                        fae_next_list.append((fae_y, fae_x))
                    else:
                        if fae_unreachable_border[fae_y,
                                                  fae_x] != 1:
                            fae_unreachable_border[fae_y,
                                                   fae_x] = 2

            # ----------------------------------------------------
            # End: perform BFS loop for all the reachable points
            #      until this recursive step.
            # ----------------------------------------------------

        # -----------------------------------------------
        # Start: Find a potential new edge to replace the
        #        removed one.
        # -----------------------------------------------

        fae_coords = NP.where(fae_unreachable_border == 2)

        fae_zip = zip(fae_coords[0], fae_coords[1])
        fae_max_d = 0.0
        fae_best_edge = None
        fae_removed_y, fae_removed_x = \
            fae_removed_edge[0],\
                fae_removed_edge[2]

        for fae_base_y, fae_base_x in fae_zip:

            for i in range(4):
                fae_dy, fae_dx = fae_steps[i]

                fae_y = fae_base_y + fae_dy

                if fae_y < 0 or fae_y >= self.member_height:
                    continue

                fae_x = fae_base_x + fae_dx

                if fae_x < 0 or fae_x >= self.member_width:
                    continue

                assert fae_array[fae_base_y, fae_base_x] == \
                       False, "Error, point not a border."

                if fae_unreachable_border[fae_y, fae_x] == 1:
                    fae_edge = \
                        (fae_y, fae_base_y, fae_x, fae_base_x)
                    if fae_edge != fae_removed_edge:
                        # fae_d2 = \
                        #     (fae_removed_y - fae_y) ** 2 + \
                        #     (fae_removed_x - fae_x) ** 2

                        fae_d1 = \
                            NP.sqrt(min(abs(fae_y),
                                        abs(fae_y -
                                            self.member_height +
                                            1)) * \
                                    min(abs(fae_x),
                                        abs(fae_x -
                                            self.member_width +
                                            1)))

                        fae_d2 = \
                            abs(fae_removed_y - fae_y) * \
                            abs(fae_removed_x - fae_x)

                        fae_d = fae_d1 * fae_d2

                        if fae_max_d < fae_d:
                            fae_best_edge = fae_edge
                            fae_max_d = fae_d

        # -----------------------------------------------
        # End: Find a potential new edge to replace the
        #      removed one.
        # -----------------------------------------------

        return fae_best_edge


    def function_enhance(self) -> int:

        e_path = []

        # In large lists SortedList has a bug when the
        # initialization is a list of tuples!
        # e_edges = SORTEDCONTAINERS_SortedList(self.member_edges)
        e_edges = GRAPH_SORTED_LIST(self.member_edges)

        # for e_edge in self.member_edges:
        #     e_edges.add(list(e_edge))

        e_ret = self.function_get_solution(e_edges, e_path)

        if not e_ret:
            print('\33[91mError: no solution path was found.'
                  '\33[00m')
            return 0

        e_n = len(e_path)

        # -------------------
        # Start: remove edge.
        # -------------------

        e_split = RANDOM.randint(e_n>>4, 15 * (e_n>>4))

        # e_removed_edge is a tuple (y1, y2, x1, x2).
        # e_removed_edge = self.member_edges[e_split]
        e_removed_edge = e_path[e_split]

        try:
            e_split = self.member_edges.index(e_removed_edge)
        except ValueError:
            e_removed_edge = (e_removed_edge[1],
                              e_removed_edge[0],
                              e_removed_edge[3],
                              e_removed_edge[2])
            e_split = self.member_edges.index(e_removed_edge)

        e_edges.function_remove(e_removed_edge)

        # -------------------
        # End: remove edge.
        # -------------------

        # ------------------------------
        # Start: add a replacement edge.
        # ------------------------------

        e_replacement_edge = \
            self.function_find_alternative_edge(e_edges,
                                                e_removed_edge)

        self.member_edges = \
            self.member_edges[:e_split] + [e_replacement_edge] + \
            self.member_edges[e_split + 1:]

        # ------------------------------
        # End: add a replacement edge.
        # ------------------------------

        return e_n

def main():
    ma_graph = GRAPH_CLASS()
    print('See: Maze_enhanced.png, Solved_Maze_enhanced.png, Maze.png, Solved_Maze.png .')

if __name__ == '__main__':
    main()
