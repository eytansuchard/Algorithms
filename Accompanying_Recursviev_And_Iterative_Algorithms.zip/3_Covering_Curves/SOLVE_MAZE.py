import numpy as NP
from PIL import Image as PIL_Image, ImageDraw as PIL_ImageDraw
import argparse as ARGSPARSE
from sortedcontainers import SortedList as SORTEDCONTAINERS_SortedList

def SOLVE_MAZE_load(l_input_name: str, l_output_name: str,
                    l_start_x: int = 0, l_start_y: int = 0):

    try:
        l_img = PIL_Image.open(l_input_name)
        if l_img.mode != 'RGB':
            l_img = l_img.convert('RGB')
    except Exception as l_ex:
        print(l_ex)
        l_img = None

    if l_img is None:
        print(f'\33[31mERROR: {l_input_name} '
              f'could not be found!\33[00m')
        return

    # ********************************************************
    # Start: Step 1, create a spanning tree to the maze graph.
    # ********************************************************

    l_depth_array = NP.empty((l_img.height, l_img.width), dtype=int)
    l_depth_array[:] = l_img.width * l_img.height
    l_pixels = NP.array(l_img)

    l_pixels[l_start_y, l_start_x, :] = (255, 255, 255)
    l_depth_array[l_start_y, l_start_x] = 0
    l_dest_x, l_dest_y = \
        l_img.width - 1 - l_start_x, l_img.height - 1 - l_start_y
    l_wave = SORTEDCONTAINERS_SortedList([(l_start_x, l_start_y)])

    l_max_depth = 0
    l_count = 1
    l_last_count = 0

    while True:

        l_addition_list = SORTEDCONTAINERS_SortedList()
        l_removal_list = []

        for l_x, l_y in l_wave:

            if (l_pixels[l_y, l_x, :] == (255, 255, 255)).all():
                l_pixels[l_y, l_x, :] = (0, 255, 0)
                l_count += 1

            if l_x == l_dest_x and l_y == l_dest_y:
                l_dest_x, l_dest_y = l_x, l_y

            l_ok = False

            for l_dx, l_dy in ((1, 0), (0, 1), (-1, 0), (0, -1)):
                l_x2 = l_x + l_dx

                if l_x2 < 0 or l_x2 >= l_img.width:
                    continue

                l_y2 = l_y + l_dy

                if l_y2 < 0 or l_y2 >= l_img.height:
                    continue

                if (l_pixels[l_y2, l_x2, :] != (255, 255, 255)).any():

                    continue

                l_ok = True
                # l_pixels[l_y2, l_x2, :] = (0, 255, 0)
                l_depth_array[l_y2, l_x2] = l_depth_array[l_y, l_x] + 1

                l_point = (l_x2, l_y2)

                if not l_point in l_wave and not l_point in l_addition_list:
                    l_addition_list.add((l_x2, l_y2))

            if not l_ok:
                l_point = (l_x, l_y)

                while l_point in l_addition_list:
                    l_addition_list.remove(l_point)

                if l_point in l_wave:
                    l_removal_list.append(l_point)

        for l_point in l_removal_list:
            while l_point in l_wave:
                l_wave.remove(l_point)

        l_wave = l_wave + l_addition_list

        l_max_depth += 1

        if len(l_wave) == 0:
            break

        print(f'Depth {l_max_depth}, len {len(l_wave)}, count {l_count}')

        if l_last_count == l_count:
            break

        l_last_count = l_count

    # Start: cleanup.
    l_mask = (l_pixels[:, :, 0] == 0) & \
             (l_pixels[:, :, 1] == 255) & \
             (l_pixels[:, :, 2] == 0)
    l_pixels[l_mask, :] = (255, 255, 255)

    l_img = PIL_Image.fromarray(l_pixels)
    # End: cleanup.

    # ********************************************************
    # End: Step 1, create a spanning tree to the maze graph.
    # ********************************************************

    # ****************************************************************
    # Start: Step 2, look for the path from the destination backwards. 
    # ****************************************************************

    l_x, l_y = l_dest_x, l_dest_y
    l_solution_list = []

    l_ok = True

    while l_ok:

        l_ok = False
        l_depth = l_depth_array[l_y, l_x]
        l_solution_list.append((l_x, l_y))
        if l_y == l_start_y and l_x == l_start_x:
            break

        for l_dx, l_dy in ((0, 0), (1, 0), (0, 1), (-1, 0), (0, -1)):

            l_x2 = l_x + l_dx

            if l_x2 < 0 or l_x2 >= l_img.width:
                continue

            l_y2 = l_y + l_dy

            if l_y2 < 0 or l_y2 >= l_img.height:
                continue

            if l_x2 == 0 and l_y2 == 0:
                break

            if l_depth_array[l_y2, l_x2] < l_depth:
                l_y, l_x = l_y2, l_x2
                l_ok = True
                break

        if not l_ok:
            # For low quality mazes where paths are blocked.
            print('Cannot continue!')

    l_solution_list.reverse()

    # ****************************************************************
    # Start: Step 2, look for the path from the destination backwards. 
    # ****************************************************************

    # *********************************
    # Start: Step 3, draw the solution. 
    # *********************************

    l_draw = PIL_ImageDraw.Draw(l_img)
    l_last_x, l_last_y = l_start_x, l_start_y

    for l_x, l_y in l_solution_list:
        l_double_point = (l_last_x, l_last_y, l_x, l_y)
        l_last_x, l_last_y = l_x, l_y
        l_draw.line(l_double_point, fill="red", width=2)  # Draw a red line.

    l_img.save(l_output_name)

    # *********************************
    # End: Step 3, draw the solution. 
    # *********************************

def main():
    ma_parser = ARGSPARSE.ArgumentParser()

    ma_parser.add_argument('-i', '--input',
                           default='Corrected_Aviad_Maze.png',
                           # default='Maze.png',
                           help='Input image file name.')

    ma_parser.add_argument('-o', '--output',
                           default='Output.png',
                           help='Output image file name.')

    ma_parser.add_argument('-dx', '--start_x', default=0,
                           type=int, choices=range(0, 15),
                           help="An integer between 0 and 15")

    ma_parser.add_argument('-dy', '--start_y', default=0,
                           type=int, choices=range(0, 15),
                           help="An integer between 0 and 15")

    ma_args = ma_parser.parse_args()

    ma_input_image_file_name = ma_args.input
    ma_output_image_file_name = ma_args.output
    ma_start_x = ma_args.start_x
    ma_start_y = ma_args.start_y

    SOLVE_MAZE_load(ma_input_image_file_name,
                    ma_output_image_file_name,
                    l_start_x=ma_start_x, l_start_y=ma_start_y)

if __name__ == '__main__':
    main()
