import numpy as NP
from enum import Enum as ENUM_Enum

from PIL import Image as PIL_Image, ImageDraw as PIL_ImageDraw

class SIMPLE_FILLING_CURVE_ACTION(ENUM_Enum):
    VERTICAL = 1
    HORIZONTAL = 2

SIMPLE_FILLING_CURVE_file_name = 'Simple_Filling_Cover.png'

class SIMPLE_FILLING_CURVE_CLASS:
    def __init__(self, i_power_of_2: int =6):
        self.member_w = 0

        if i_power_of_2 > 9 or i_power_of_2 < 2:
            return

        i_w = (1 << i_power_of_2) - 1

        self.member_w = i_w
        self.member_arr = NP.zeros((i_w, i_w), dtype=bool)

        self.function_generate(0, 0, i_w, 0, 0)

        self.member_image_w = self.member_w * 10

        self.member_image = \
            PIL_Image.new("RGB", (self.member_image_w, self.member_image_w),
                          color="white")

        self.member_draw = PIL_ImageDraw.Draw(self.member_image)

        for i_x1 in range(i_w):
            for i_y1 in range(i_w):
                if self.member_arr[i_y1, i_x1]:
                    i_x1a = i_x1 * 10
                    i_y1a = i_y1 * 10
                    i_x2a = i_x1a + 10 + 2
                    i_y2a = i_y1a + 10 + 2
                    self.member_draw.rectangle((i_x1a, i_y1a, i_x2a, i_y2a),
                                               fill="black")

        self.member_image.save(SIMPLE_FILLING_CURVE_file_name)

    def function_attach_detach(self, ad_x, ad_y,
                               ad_action: SIMPLE_FILLING_CURVE_ACTION):

        if ad_action == SIMPLE_FILLING_CURVE_ACTION.HORIZONTAL:

            if not self.member_arr[ad_y + 1, ad_x] or not \
                self.member_arr[ad_y + 1, ad_x + 2]:
                print('\33[91mNodes already disconnected\33[00m')
                # return

            # Detach vertical edge on the left.
            self.member_arr[ad_y + 1, ad_x] = False
            # Detach vertical edge on the right.
            self.member_arr[ad_y + 1, ad_x + 2] = False
            # Attach horizontal edge at the top.
            self.member_arr[ad_y, ad_x + 1] = True
            # Attach horizontal edge at the bottom.
            self.member_arr[ad_y + 2, ad_x + 1] = True
        elif ad_action == SIMPLE_FILLING_CURVE_ACTION.VERTICAL:

            if not self.member_arr[ad_y, ad_x + 1] or not \
                self.member_arr[ad_y + 2, ad_x + 1]:
                print('\33[91mNodes already disconnected\33[00m')
                # return

            # Detach horizontal edge at the top.
            self.member_arr[ad_y, ad_x + 1] = False
            # Detach horizontal edge at the bottom.
            self.member_arr[ad_y + 2, ad_x + 1] = False
            # Attach horizontal edge on the left.
            self.member_arr[ad_y + 1, ad_x] = True
            # Attach horizontal edge on the right.
            self.member_arr[ad_y + 1, ad_x + 2] = True


    def function_generate(self, g_x=0, g_y=0,
                          g_w: int=31, # 2^n - 1.
                          g_branch: int = 0,
                          g_depth: int=0):

        if (g_w & 1) == 0:
            print('\33[91mEdge length must be an odd number.\33[00m')
            return

        if g_w == 3:
            self.member_arr[g_y: g_y + 3, g_x: g_x + 3] = True
            self.member_arr[g_y+1, g_x+1] = False
            return
        else:
            g_w = g_w >> 1

            if (g_depth & 1) == 0:
                g_symmetry = (1, 0, 2, 3)
            else:
                g_symmetry = (3, 2, 0, 1)

            self.function_generate(g_x, g_y, g_w, g_symmetry[0], g_depth+1)
            self.function_generate(g_x + g_w + 1, g_y, g_w, g_symmetry[1],
                                   g_depth+1)
            self.function_generate(g_x, g_y + g_w + 1, g_w, g_symmetry[2],
                                   g_depth+1)
            self.function_generate(g_x + g_w + 1, g_y + g_w + 1,
                                   g_w, g_symmetry[3], g_depth + 1)

            if 1 != g_branch:
                g_offset_x = g_x + g_w - 1
                g_offset_y = g_y + g_w - 3
                self.function_attach_detach(g_offset_x, g_offset_y,
                                            SIMPLE_FILLING_CURVE_ACTION.
                                            HORIZONTAL)
            if 0 != g_branch:
                g_offset_x = g_x + g_w - 3
                g_offset_y = g_y + g_w - 1
                self.function_attach_detach(g_offset_x, g_offset_y,
                                            SIMPLE_FILLING_CURVE_ACTION.
                                            VERTICAL)

            if 3 != g_branch:
                g_offset_x = g_x + g_w - 1
                g_offset_y = g_y + g_w + 1
                self.function_attach_detach(g_offset_x, g_offset_y,
                                            SIMPLE_FILLING_CURVE_ACTION.
                                            HORIZONTAL)

            if 2 != g_branch:
                g_offset_x = g_x + g_w + 1
                g_offset_y = g_y + g_w - 1
                self.function_attach_detach(g_offset_x, g_offset_y,
                                            SIMPLE_FILLING_CURVE_ACTION.
                                            VERTICAL)


def main():
    ma_curve = SIMPLE_FILLING_CURVE_CLASS(6)
    print('Check ' + SIMPLE_FILLING_CURVE_file_name)

if __name__ == '__main__':
    main()
