import numpy as NP

# Vectorization of GCD is an example of maintaining a state vector
# in iterative processes and is often overlooked.
def function_gcd(g_a: int, g_b: int):

    if g_a < g_b:
        g_a, g_b = g_b, g_a
        g_a_vector, g_b_vector = \
            NP.array([0, 1], dtype=int), NP.array([1, 0], dtype=int)
    else:
        g_a_vector, g_b_vector = \
            NP.array([1, 0], dtype=int), NP.array([0, 1], dtype=int)

    while True:
        g_quotient = g_a // g_b
        g_remainder = g_a - g_quotient * g_b
        if 0 == g_remainder:
            break

        g_remainder_vector = g_a_vector - g_quotient * g_b_vector
        g_a = g_b
        g_b = g_remainder
        g_a_vector[:] = g_b_vector[:]
        g_b_vector[:] = g_remainder_vector[:]

    return g_b, g_b_vector

def main():
    ma_a = 88
    ma_b = 33
    ma_gcd, ma_gcd_vector = function_gcd(ma_a, ma_b)
    ma_gcd2 = ma_gcd_vector[0] * ma_a +  ma_gcd_vector[1] * ma_b
    print(f'GCD: {ma_gcd}, GCD from state vector {ma_gcd2}')
    print(f'State vector[0]={ma_gcd_vector[0]}, vector[1]={ma_gcd_vector[1]}')

if __name__ == '__main__':
    main()
