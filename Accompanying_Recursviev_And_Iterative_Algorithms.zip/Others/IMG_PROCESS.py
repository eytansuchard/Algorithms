import numpy as NP
from PIL import Image as PIL_Image
import argparse as ARGSPARSE

def IMG_PROCESS_process(p_input_name: str, p_output_name: str):
    try:
        p_img = PIL_Image.open(p_input_name)
        if p_img.mode != 'RGB':
            p_img = p_img.convert('RGB')
    except Exception as p_ex:
        print(p_ex)
        p_img = None

    if p_img is None:
        print(f'\33[31mERROR: {p_input_name} could not be found!\33[00m')
        return

    p_arr = NP.array(p_img)
    p_mask = NP.logical_and(p_arr[:, :, 0] > p_arr[:, :, 1], p_arr[:, :, 0] > p_arr[:, :, 2])
    p_arr[p_mask] = 255
    if p_input_name != p_output_name:
        p_median = int(NP.median(p_arr))
        p_threshold = p_median // 2
        p_mask = p_arr < p_threshold
        p_arr[p_mask] = 0
        p_mask = p_arr > (2 * p_median) // 3
        p_arr[p_mask] = 255
    p_img = PIL_Image.fromarray(p_arr)
    p_img.save(p_output_name)

def main():
    ma_parser = ARGSPARSE.ArgumentParser()

    ma_parser.add_argument('-i', '--input',
                           default='AviadMaze.png',
                           help='Input image file name.')

    ma_parser.add_argument('-o', '--output',
                           default='Output.png',
                           help='Output image file name.')

    ma_args = ma_parser.parse_args()

    ma_input_image_file_name = ma_args.input
    ma_output_image_file_name = ma_args.output

    IMG_PROCESS_process(ma_input_image_file_name, ma_output_image_file_name)

if __name__ == '__main__':
    main()



