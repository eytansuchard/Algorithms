import copy

import numpy as NP
from numpy import random as NP_RND
from scipy.sparse import csr_matrix as SCIPY_SPARSE_csr_matrix

class VRP_CLASS(object):

    def __init__(self,
                 i_distance_matrix: NP.array,
                 i_vehicles: int,
                 i_population_multiple_of_16: int,
                 i_lin_kernighan_mutation_probability: NP.float64 = 0.005,
                 i_simple_transposition_mutation_probability: NP.float64 = 0.005,
                 i_simple_vehicle_mutation_probability: NP.float64 = 0.005):

        super(VRP_CLASS, self).__init__()
        # The first column is the station. It is not included in the permutations.

        if self.function_load():
            print('VRP_GEN_AL.npz exists, skipping initialization from scratch.')
            return

        if i_population_multiple_of_16 & 15 > 0:

            self.member_distance_matrix = None
            self.member_vehicles = 0
            self.member_n = 0
            self.member_population = 0

            self.member_lin_kernighan_mutation_probability = 0
            self.member_simple_transposition_mutation_probability = 0
            self.member_simple_vehicle_mutation_probability = 0

            self.member_perm_matrix = None
            self.member_routes_matrix = None

            print('Error: i_population_multiple_of_16 must be a multiple of 16.')

            return

        self.member_distance_matrix = copy.deepcopy(i_distance_matrix)
        self.member_vehicles = i_vehicles
        self.member_n = i_distance_matrix.shape[1]
        self.member_population = i_population_multiple_of_16

        self.member_lin_kernighan_mutation_probability = \
            i_lin_kernighan_mutation_probability
        self.member_simple_transposition_mutation_probability = \
            i_simple_transposition_mutation_probability
        self.member_simple_vehicle_mutation_probability = \
            i_simple_vehicle_mutation_probability

        self.member_perm_matrix = \
            NP.zeros((i_population_multiple_of_16, self.member_n), dtype=int)

        for i in range(self.member_population):
            # Acrobatics to leave vertex 0 as the vehicle station.
            # Can be designed better such that each vehicle will have
            # an array of distances to and from each destination.
            self.member_perm_matrix[i, 1:] = \
                NP.random.permutation(self.member_n-1) + 1

        self.member_routes_matrix = \
            NP.zeros((i_population_multiple_of_16, self.member_n), dtype=int)

        for i in range(self.member_population):
            # Acrobatics to leave vertex 0 as the vehicle station.
            # Can be designed better such that each vehicle will have
            # an array of distances to and from each destination.
            self.member_routes_matrix[i, 1:] = \
                NP.random.randint(low=0, high=i_vehicles, size=self.member_n-1)


    def function_load(self):

        l_ok = True

        try:
            l_data = NP.load('VRP_GEN_AL.npz')
            self.member_perm_matrix = l_data['matrix_of_permutations']
            self.member_routes_matrix = l_data['matrix_of_vehicles']
            self.member_distance_matrix = l_data['matrix_of_distances']
            self.member_population = l_data['population_n']
            self.member_vehicles = l_data['vehicles_n']
            self.member_n = l_data['vertices_n']
            self.member_lin_kernighan_mutation_probability = \
                l_data['lin_kernighan_mutation_probability']
            self.member_simple_transposition_mutation_probability = \
                l_data['simple_transposition_mutation_probability']
            self.member_simple_vehicle_mutation_probability = \
                l_data['simple_vehicle_mutation_probability']
        except:
            l_ok = False

        return l_ok


    def function_save(self):
        NP.savez('VRP_GEN_AL.npz',
                 matrix_of_permutations=self.member_perm_matrix,
                 matrix_of_vehicles=self.member_routes_matrix,
                 matrix_of_distances=self.member_distance_matrix,
                 population_n=self.member_population,
                 vehicles_n=self.member_vehicles,
                 vertices_n=self.member_n,
                 lin_kernighan_mutation_probability=
                 self.member_lin_kernighan_mutation_probability,
                 simple_transposition_mutation_probability=
                 self.member_simple_transposition_mutation_probability,
                 simple_vehicle_mutation_probability=
                 self.member_simple_vehicle_mutation_probability)
        return

    # ********************************************************
    # Start: Crossing-over, Lin-Kernighan, and transpositions.
    # ********************************************************

    # @staticmethod
    # def function_perm_matrix(pm_perm_arr: NP.array,
    #                          # 1,1,...,1 n times.
    #                          pm_ones_arr: NP.array,
    #                          # 0,1,2,...,n-1.
    #                          pm_ordered_arr: NP.array):
    # 
    #     return SCIPY_SPARSE_csr_matrix((pm_ones_arr, (pm_ordered_arr, pm_perm_arr))).toarray()


    @staticmethod
    def function_cover_matrix(cm_perm_arr:NP.array,
                              cm_vehicles_arr:NP.array,
                              # 1,1,...,1 n times.
                              cm_ones_arr:NP.array,
                              # 0,1,2,...,n-1.
                              cm_ordered_row_arr:NP.array):
        
        # Returns a graph matrix based on vehicle cover.
        # If two vertices are covered by the same vehicle, 1, otherwise 0.

        if cm_ones_arr is None:
            cm_ones_arr = [1] * cm_perm_arr.shape[0]
            cm_ones_arr = NP.array(cm_ones_arr, dtype=NP.int32)
            
        if cm_ordered_row_arr is None:
            cm_ordered_row_arr = [i for i in range(cm_perm_arr.shape[0])]
            cm_ordered_row_arr = NP.array(cm_ordered_row_arr, dtype=NP.int32)

        # Make a permutation matrix from a permutation vector.
        cm_perm_matrix = \
            SCIPY_SPARSE_csr_matrix((cm_ones_arr,
                                     (cm_ordered_row_arr, cm_perm_arr))).toarray()

        # Cancel the permutation and show which vertex is covered by which vehicle.
        cm_ordered_vehicles = cm_perm_matrix.T @ cm_vehicles_arr

        # ----------------------------------------------------------------------------
        # Start: If two vertices are covered by the same vehicle, then 1, otherwise 0.
        # ----------------------------------------------------------------------------

        cm_cover_matrix = \
            SCIPY_SPARSE_csr_matrix((cm_ones_arr,
                                     (cm_ordered_row_arr,
                                      cm_ordered_vehicles))).toarray()

        cm_cover_matrix = cm_cover_matrix @ cm_cover_matrix.T

        # ----------------------------------------------------------------------------
        # End: If two vertices are covered by the same vehicle, then 1, otherwise 0.
        # ----------------------------------------------------------------------------

        return cm_cover_matrix


    @staticmethod
    def function_check_validity(cv_perm: NP.array):

        cv_n = cv_perm.shape[0]

        if cv_perm.max() >= cv_n:
            return False

        cv_counts = NP.zeros(cv_n, dtype=int)

        for i in range(cv_n):
            cv_counts[cv_perm[i]] += 1

        return cv_counts.min() == cv_counts.max() == 1

    @staticmethod
    def function_cross_perm(cp_perm1: NP.array, cp_perm2: NP.array,
                            cp_route1: NP.array, cp_route2: NP.array):

        # --------------------------------
        # Start: check arguments validity.
        # --------------------------------

        if cp_perm1.ndim != cp_perm2.ndim or cp_perm1.ndim != 1:
            return None

        if cp_route1.ndim != cp_route2.ndim or cp_route1.ndim != 1:
            return None

        if cp_perm1.shape[0] != cp_perm2.shape[0] or cp_perm1.shape[0] < 1:
            return None

        if cp_perm1.shape[0] != cp_route1.shape[0] or \
                cp_perm1.shape[0] != cp_route2.shape[0]:
            return None

        if 1 == cp_perm1.shape[0]:
            if cp_perm1[0] == cp_perm2[0]:
                return cp_perm1
            else:
                return None

        cp_n = cp_perm1.shape[0]

        if cp_perm1.max() >= cp_n or cp_perm2.max() >= cp_n:
            return None

        # --------------------------------
        # End: check arguments validity.
        # --------------------------------

        cp_inverse2 = NP.zeros(cp_n, dtype=NP.int32)
        cp_new_perm = NP.zeros(cp_n, dtype=NP.int32)
        cp_new_route = NP.zeros(cp_n, dtype=NP.int32)

        for i in range(cp_n):
            cp_inverse2[cp_perm2[i]] = i

        cp_cycles_arr = -1 * NP.ones(cp_n, dtype=NP.int32)

        cp_cycle_count = 0

        # -------------------------------------------------------
        # Start: deconstruct the permutations into common cycles.
        # -------------------------------------------------------

        for i in range(cp_n):
            cp_scan_idx = i

            if cp_cycles_arr[cp_scan_idx] > -1:
                continue

            while -1 == cp_cycles_arr[cp_scan_idx]:
                cp_cycles_arr[cp_scan_idx] = cp_cycle_count
                cp_in_perm1 = cp_perm1[cp_scan_idx]
                cp_scan_idx = cp_inverse2[cp_in_perm1]

            cp_cycle_count += 1

        # -------------------------------------------------------
        # End: deconstruct the permutations into common cycles.
        # -------------------------------------------------------

        # ----------------------------------------------------------------------
        # Start: from each matching cycle choose from cp_perm1 or from cp_perm2.
        # ----------------------------------------------------------------------

        cp_chosen_cycle = NP.zeros(cp_cycle_count, dtype=bool)

        for cp_cycle in range(cp_cycle_count):
            cp_chosen_cycle[cp_cycle] = bool(NP_RND.randint(2))

        for i in range(cp_n):
            cp_cycle = cp_cycles_arr[i]
            if cp_chosen_cycle[cp_cycle]:
                cp_new_perm[i] = cp_perm1[i]
                cp_new_route[i] = cp_route1[i]
            else:
                cp_new_perm[i] = cp_perm2[i]
                cp_new_route[i] = cp_route2[i]

        # ----------------------------------------------------------------------
        # End: from each matching cycle choose from cp_perm1 or from cp_perm2.
        # ----------------------------------------------------------------------

        return cp_new_perm, cp_new_route

    @staticmethod
    def function_transpositions(t_perm, t_routes, t_vehicles,
                                t_perm_probability=0.005,
                                t_routes_probability=0.001):

        t_n = t_perm.shape[0]

        for i in range(t_n-1):
            if NP.random.uniform() < t_perm_probability:
                continue

            k = NP.random.randint(i, t_n)

            t_aux = t_perm[i]
            t_perm[i] = t_perm[k]
            t_perm[k] = t_aux

        for i in range(t_n):

            if NP.random.uniform() < t_routes_probability:
                continue

            t_routes[i] = NP.random.randint(t_vehicles)

        return

    @staticmethod
    def function_perm_reflect(pr_perm, pr_route, pr_start, pr_end):

        # There is no need to reflect a subsequence where the
        # end is before the start because such a Lin - Kernighan
        # mutation is equivalent to starting from pr_end and ending
        # in pr_start, regarding the TSP/TSA problem.

        if pr_end < pr_start:
            pr_aux = pr_start
            pr_start = pr_end
            pr_end = pr_aux

        if pr_end == pr_start or pr_end >= pr_perm.shape[0] or \
                pr_start < 0:
            print('Error, reflection start, end indices are incorrect!')
            print(f'Wasted choice of reflection: start={pr_start}, end={pr_end}')
            return

        if pr_perm.shape[0] != pr_route.shape[0]:
            print('Error, permutation does not match routes!')
            return

        pr_mid = (1 + pr_start + pr_end) >> 1

        for i in range(pr_start, pr_mid):
            pr_aux = pr_route[i]
            k = pr_end - i + pr_start
            pr_route[i] = pr_route[k]
            pr_route[k] = pr_aux

        return


    @staticmethod
    def function_perm_jump(pj_perm, pj_route, pj_start, pj_count, pj_advance):
        '''
        from pj_start up to pj_start+pj_count cyclically, advance pj_advance
        '''
        if pj_count < 1 or pj_advance < 1:
            print('Error: jump parameter too small.')
            print(f'Wasted choice of jump: count={pj_count}, from={pj_start}')
            return

        pj_n = pj_perm.shape[0]

        if pj_n != pj_route.shape[0]:
            print('Error: permutation and routes length mismatch.')
            return

        pj_count2 = pj_n - pj_count - pj_advance

        if 0 == pj_count2:
            print('Error: pj_n = pj_count + pj_advance.')
            print(f'Wasted choice of jump: '
                  f'count={pj_count}, from={pj_start}, jump={pj_advance}')
            return

        if pj_count2 < 0:
            print('Error: pj_count + pj_advance must be smaller than the length.')
            print(f'Wasted choice of jump: '
                  f'count={pj_count}, from={pj_start}, jump={pj_advance}')


        pj_arr = NP.zeros(pj_n, int)
        pj_arr2 = NP.zeros(pj_n, int)

        pj_idx0 = (pj_start + pj_count) % pj_n

        for i in range(pj_advance):

            pj_arr[i] = pj_perm[pj_idx0]
            pj_arr2[i] = pj_route[pj_idx0]

            pj_idx0 += 1

            if pj_idx0 >= pj_n:
                pj_idx0 = 0

        pj_idx1 = pj_start

        for k in range(pj_count):

            # In the previous look i does not reac pj_advance.
            # That is why i has to be incremented first.
            i += 1

            if i >= pj_n:
                i = 0

            pj_arr[i] = pj_perm[pj_idx1]
            pj_arr2[i] = pj_route[pj_idx1]

            pj_idx1 += 1

            if pj_idx1 >= pj_n:
                pj_idx1 = 0

        pj_idx2 = pj_idx0

        for k in range(pj_count2):

            i += 1

            if i >= pj_n:
                i = 0

            pj_arr[i] = pj_perm[pj_idx2]
            pj_arr2[i] = pj_route[pj_idx2]

            pj_idx2 += 1

            if pj_idx2 >= pj_n:
                pj_idx2 = 0

        for i in range(pj_n):
            pj_perm[i] = pj_arr[i]
            pj_route[i] = pj_arr2[i]

        return

    # ********************************************************
    # End: Crossing-over, Lin-Kernighan, and transpositions.
    # ********************************************************

    def function_get_leading(self, gl_verbose=True):

        gl_perm = self.member_perm_matrix[0, :]
        gl_routes = self.member_routes_matrix[0, :]
        gl_vehicles_array = NP.empty(self.member_vehicles, dtype=list)
        gl_vehicles_array[:] = [list() for _ in range(self.member_vehicles)]
        gl_scores_array = NP.zeros(self.member_vehicles, dtype=NP.float64)

        for k in range(1, self.member_n):
            gl_vehicles_array[gl_routes[k]].append(gl_perm[k])

        gl_sum = 0

        for k in range(self.member_vehicles):

            gl_prev = None

            gl_vehicle_sum = 0

            for gl_vertex in gl_vehicles_array[k]:

                if gl_prev is None:
                    # Add the distance form the station to the first vertex.
                    gl_vehicle_sum += self.member_distance_matrix[0, gl_vertex]
                else:
                    gl_vehicle_sum += self.member_distance_matrix[gl_prev, gl_vertex]
                gl_prev = gl_vertex

            # Add the distance form the last vertex to the station.
            if gl_prev is not None:
                gl_vehicle_sum += self.member_distance_matrix[gl_prev, 0]

            gl_scores_array[k] = gl_vehicle_sum

            gl_sum += gl_vehicle_sum

            gl_vehicles_array[k] = [0] + gl_vehicles_array[k] + [0]

        if gl_verbose:

            for i in range(self.member_vehicles):
                if len(gl_vehicles_array[i]) > 0:
                    print(f'Vehicle({i})`s route:')
                    print(",".join(str(k) for k in gl_vehicles_array[i]))
                    print(f'Vehicle({i})`s distance: {gl_scores_array[i]}')

            print(f'Sum: {gl_sum}')

        return gl_vehicles_array, gl_scores_array


    def function_fitness(self, f_generation: int, f_validate=False):

        f_ordinary_fitness = NP.zeros(self.member_population, dtype=NP.float64)
        f_leading_population = self.member_population >> 4
        f_special_population1 = self.member_population >> 4
        f_special_population2 = self.member_population >> 4
        f_weak_population = self.member_population >> 4
        f_weak_population_offset = \
            f_leading_population + f_special_population1 +  f_special_population2
        f_surviving_population = \
            f_leading_population + f_special_population1 + \
            f_special_population2 + f_weak_population

        f_ones_arr = NP.ones(self.member_n, dtype=NP.int32)
        f_ordered_arr = NP.array([i for i in range(self.member_n)], dtype=NP.int32)

        # -----------------------------------------------------
        # Start: sort by ordinary fitness with best ones first.
        # -----------------------------------------------------

        for i in range(self.member_population):

            f_routes = NP.empty(self.member_vehicles, dtype=list)
            f_routes[:] = [list() for _ in range(self.member_vehicles)]

            for k in range(1, self.member_n):
                f_routes[self.member_routes_matrix[i, k]].\
                    append(self.member_perm_matrix[i, k])

            f_sum = 0

            for k in range(self.member_vehicles):

                f_vehicle_sum = 0
                f_prev = None

                for f_vertex in f_routes[k]:
                    if f_prev is None:
                        # Add the distance form the station to the first vertex.
                        f_vehicle_sum += self.member_distance_matrix[0, f_vertex]
                    else:
                        f_vehicle_sum += self.member_distance_matrix[f_prev, f_vertex]
                    f_prev = f_vertex

                # Add the distance form the last vertex to the station.
                if f_prev is not None:
                    f_vehicle_sum += self.member_distance_matrix[f_prev, 0]
                    f_sum += f_vehicle_sum

            f_ordinary_fitness[i] = f_sum

        f_sorted_indices = NP.argsort(f_ordinary_fitness)

        f_best_index = f_sorted_indices[0]
        f_best = f_ordinary_fitness[f_best_index]

        # If two vertices are covered by the same vehicle, 1, otherwise 0.
        f_cover_matrix1 = \
            VRP_CLASS.function_cover_matrix(cm_perm_arr=
                                            self.member_perm_matrix[f_best_index,:],
                                            cm_vehicles_arr=
                                            self.member_routes_matrix[f_best_index,:],
                                            cm_ones_arr=f_ones_arr,
                                            cm_ordered_row_arr=f_ordered_arr)

        # -----------------------------------------------------
        # End: sort by ordinary fitness with best ones first.
        # -----------------------------------------------------

        f_perm_matrix = NP.zeros((f_surviving_population, self.member_n), dtype=int)
        f_routes_matrix = NP.zeros((f_surviving_population, self.member_n), dtype=int)

        for i in range(f_leading_population):
            k = f_sorted_indices[i]
            f_perm_matrix[i, :] = self.member_perm_matrix[k, :]
            f_routes_matrix[i, :] = self.member_routes_matrix[k, :]
            print(f'Gen {f_generation},  ordianry distance({i} <- {k}) {f_ordinary_fitness[k]}')

        # -----------------------------------------------------
        # Start: sort by special fitness with best ones first.
        #        Slowing down convergence but necessary.
        #        It enhances diversity.
        # -----------------------------------------------------

        f_rate = NP.power(0.00390625, 1/f_special_population1)
        #f_rate = NP.power(0.0009765625, 1/f_special_population)

        f_power = 1

        for f_special in range(f_special_population1):
            f_power *= f_rate

            f_best_index = 0
            f_best_fitness = None

            for i in range(self.member_population):

                f_routes = NP.empty(self.member_vehicles, dtype=list)
                f_routes[:] = [list() for _ in range(self.member_vehicles)]

                for k in range(1, self.member_n):
                    f_routes[self.member_routes_matrix[i, k]].\
                        append(self.member_perm_matrix[i, k])

                f_sum = 0
                f_vehicle_sum = 0

                for k in range(self.member_vehicles):

                    f_vehicle_sum = 0
                    f_prev = None

                    for f_vertex in f_routes[k]:
                        if f_prev is None:
                            f_vehicle_sum += \
                                NP.power(self.member_distance_matrix[0, f_vertex], f_power)
                        else:
                            f_vehicle_sum += \
                                NP.power(self.member_distance_matrix[f_prev, f_vertex], f_power)
                        f_prev = f_vertex

                    if f_prev is not None:
                        f_vehicle_sum += NP.power(self.member_distance_matrix[f_prev, 0], f_power)

                    f_sum += f_vehicle_sum

                if f_best_fitness is None:
                    f_best_fitness = f_sum
                    f_best_index = i
                elif f_best_fitness > f_sum:
                    f_best_fitness = f_sum
                    f_best_index = i

                # try:
                #     if f_best_fitness is None:
                #         f_best_fitness = f_sum
                #         f_best_index = i
                #     elif f_best_fitness > f_sum:
                #         f_best_fitness = f_sum
                #         f_best_index = i
                # except ValueError:
                #     print('Strange error in f_sum and f_best_fitness !')
                #     print('f_best_fitness, f_sum should be a single float64 each.')
                #     print(f'Their types are {type(f_best_fitness)}, {type(f_sum)}')
                #     print(f'f_best_fitness: {f_best_fitness}')
                #     print(f'f_sum: {f_sum}')
                #     print(f'f_vehicle_sum: {f_vehicle_sum}')
                #     print(f'i/population: {i}/{self.member_population}')
                #     raise ValueError('Strange array instead of single float64')

            f_cur_index = f_special + f_leading_population

            f_perm_matrix[f_cur_index, :] = \
                self.member_perm_matrix[f_best_index, :]
            f_routes_matrix[f_cur_index, :] = \
                self.member_routes_matrix[f_best_index, :]

            print(f'Gen {f_generation}, '
                  f'enhanced distance({f_cur_index} <- {f_best_index}) '
                  f'{f_best_fitness}, best={f_best}')

        # -----------------------------------------------------
        # End: sort by special fitness with best ones first.
        # -----------------------------------------------------

        # -----------------------------------------------------
        # Start: sort by special fitness with best ones first.
        #        Slowing down convergence but necessary.
        #        It enhances diversity.
        # -----------------------------------------------------

        f_difference_array = NP.zeros(self.member_population, dtype=NP.int32)

        for i in range(self.member_population):

            # If two vertices are covered by the same vehicle, 1, otherwise 0.
            f_cover_matrix2 = \
                VRP_CLASS.function_cover_matrix(cm_perm_arr=
                                                self.member_perm_matrix[i, :],
                                                cm_vehicles_arr=
                                                self.member_routes_matrix[i, :],
                                                cm_ones_arr=f_ones_arr,
                                                cm_ordered_row_arr=f_ordered_arr)

            f_difference_array[i] = (f_cover_matrix2 != f_cover_matrix1).sum()

        f_power = 1

        for f_special in range(f_special_population2):
            f_power *= f_rate

            f_best_index = 0
            f_best_fitness = None
            f_best_delta = 0

            for i in range(self.member_population):

                # If two vertices are covered by the same vehicle, 1, otherwise 0.
                f_difference1 = f_difference_array[i]
                f_difference = NP.power(f_difference1, 1 - f_power)

                f_routes = NP.empty(self.member_vehicles, dtype=list)
                f_routes[:] = [list() for _ in range(self.member_vehicles)]

                for k in range(1, self.member_n):
                    f_routes[self.member_routes_matrix[i, k]].\
                        append(self.member_perm_matrix[i, k])

                f_sum = 0

                for k in range(self.member_vehicles):

                    f_vehicle_sum = 0
                    f_prev = None

                    for f_vertex in f_routes[k]:
                        if f_prev is None:
                            f_vehicle_sum += NP.power(self.member_distance_matrix[0, f_vertex], f_power)
                        else:
                            f_vehicle_sum += NP.power(self.member_distance_matrix[f_prev, f_vertex], f_power)
                        f_prev = f_vertex

                    if f_prev is not None:
                        f_vehicle_sum += NP.power(self.member_distance_matrix[f_prev, 0], f_power)

                    f_sum += f_vehicle_sum

                f_sum /= (1 + f_difference)

                if f_best_fitness is None:
                    f_best_fitness = f_sum
                    f_best_index = i
                    f_best_delta = f_difference1
                elif f_best_fitness > f_sum:
                    f_best_fitness = f_sum
                    f_best_index = i
                    f_best_delta = f_difference1

            f_cur_index = f_special + f_special_population1 + f_leading_population
            f_perm_matrix[f_cur_index, :] = \
                self.member_perm_matrix[f_best_index, :]
            f_routes_matrix[f_cur_index, :] = \
                self.member_routes_matrix[f_best_index, :]

            print(f'Gen {f_generation}, '
                  f'enhanced distance({f_cur_index} <- {f_best_index}) '
                  f'{f_best_fitness}, delta {f_best_delta}, best={f_best}')

        # -----------------------------------------------------
        # End: sort by special fitness with best ones first.
        # -----------------------------------------------------

        # ---------------------------------------------------------------
        # Start: fill-in some weak population to avoid semi-local minima.
        #        Slowing down convergence but necessary.
        # ---------------------------------------------------------------

        for i in range(f_weak_population):
            k = NP.random.randint(f_leading_population, self.member_population)
            k = f_sorted_indices[k]
            f_perm_matrix[f_weak_population_offset + i, :] = self.member_perm_matrix[k, :]
            f_routes_matrix[f_weak_population_offset + i, :] = self.member_routes_matrix[k, :]

            print(f'Gen {f_generation}, '
                  f'ordinary weak ({f_weak_population_offset + i} <- {k}) '
                  f'{f_ordinary_fitness[k]}')

        # ---------------------------------------------------------------
        # End: fill-in some weak population to avoid semi-local minima.
        # ---------------------------------------------------------------

        # ---------------------------
        # ---------------------------
        # Start: generate offspring.
        # Survive 25%. Offspring 75%.
        # ---------------------------
        # ---------------------------

        self.member_perm_matrix[0:f_surviving_population, :] = f_perm_matrix
        self.member_routes_matrix[0:f_surviving_population, :] = f_routes_matrix

        for i in range(f_surviving_population, self.member_population):
            f_idx1 = NP.random.randint(0, f_surviving_population)
            f_idx2 = NP.random.randint(0, f_surviving_population)

            # Vertex zero is the station and it stays zero.
            # That is the reason for the -= 1 and then += 1.
            # Cross over permutations.
            self.member_perm_matrix[i, 1:], self.member_routes_matrix[i, 1:] = \
                VRP_CLASS.function_cross_perm(self.member_perm_matrix[f_idx1, 1:]-1,
                                              self.member_perm_matrix[f_idx2, 1:]-1,
                                              self.member_routes_matrix[f_idx1, 1:],
                                              self.member_routes_matrix[f_idx2, 1:])

            self.member_perm_matrix[i, 1:] += 1

            if f_validate:
                if not VRP_CLASS.function_check_validity(self.member_perm_matrix[i, :]):
                    print('ERROR after crossing over.')
                    raise Exception(f'ERROR after crossing over at index {i}')

            if NP.random.uniform() >= self.member_lin_kernighan_mutation_probability:

                f_n_min_1 = self.member_n - 1

                if NP.random.randint(0, 3) == 2:
                    f_start = NP.random.randint(0, f_n_min_1)
                    f_count = NP.random.randint(1, f_n_min_1 - 1)
                    f_advance = NP.random.randint(1, f_n_min_1 - f_count)
                    # Vertex zero is the station and it stays zero.
                    # That is the reason for the -= 1 and then += 1.
                    self.member_perm_matrix[i, 1:] -= 1
                    VRP_CLASS.function_perm_jump(self.member_perm_matrix[i, 1:],
                                                 self.member_routes_matrix[i, 1:],
                                                 f_start, f_count, f_advance)
                    self.member_perm_matrix[i, 1:] += 1
                else:
                    f_start = NP.random.randint(0, f_n_min_1)
                    f_end = (f_start + 1 + NP.random.randint(0, f_n_min_1-1)) % (f_n_min_1)
                    # Vertex zero is the station and it stays zero.
                    # That is the reason for the -= 1 and then += 1.
                    self.member_perm_matrix[i, 1:] -= 1
                    VRP_CLASS.function_perm_reflect(self.member_perm_matrix[i, 1:],
                                                    self.member_routes_matrix[i, 1:],
                                                    f_start, f_end)
                    self.member_perm_matrix[i, 1:] += 1

            else:
                # Vertex zero is the station and it stays zero.
                # That is the reason for the -= 1 and then += 1.
                self.member_perm_matrix[i, 1:] -= 1
                VRP_CLASS.function_transpositions(self.member_perm_matrix[i, 1:],
                                                  self.member_routes_matrix[i, 1:],
                                                  t_vehicles=self.member_vehicles,
                                                  t_perm_probability=
                                                  self.member_simple_transposition_mutation_probability,
                                                  t_routes_probability=
                                                  self.member_simple_vehicle_mutation_probability)
                self.member_perm_matrix[i, 1:] += 1

        # --------------------------
        # --------------------------
        # End: generate offspring.
        # --------------------------
        # --------------------------

def main_check_operators():
    ma_perm1 = NP.array([1, 7, 3, 6, 2, 0, 5, 4])
    ma_perm2 = NP.array([2, 5, 1, 7, 3, 4, 6, 0])
    ma_route1 = NP.array([1, 1, 1, 2, 2, 2, 0, 0])
    ma_route2 = NP.array([2, 2, 2, 0, 0, 0, 1, 1])

    for _ in range(10):
        ma_perm, _ = VRP_CLASS.function_cross_perm(ma_perm1, ma_perm2, ma_route1, ma_route2)
        print(ma_perm)

    print(f'Permutation 1:\n{ma_perm1}')
    print(f'Permutation 2:\n{ma_perm2}')

    print(f'Before reflection: {ma_perm1}')
    VRP_CLASS.function_perm_reflect(ma_perm1, ma_route2, 0, ma_perm1.shape[0]-1)
    print(f'After reflection: {ma_perm1}')

    ma_perm3 = NP.array([0, 1, 2, 3, 4, 5, 6, 7])

    print(f'Before move: {ma_perm3}')
    #function_perm_move(ma_perm3, 5, 3, 2)
    # Move 3 numbers starting position 5 (cyclic), and move them 2 places forward cyclic.
    VRP_CLASS.function_perm_jump(ma_perm3, ma_route2, pj_start=5, pj_count=3, pj_advance=2)
    print(f'After move: {ma_perm3}')

    print(f'Before transpositions: {ma_perm3}')
    print(f'Before mutation: {ma_route2}')

    VRP_CLASS.function_transpositions(ma_perm3, ma_route2, 3,
                                      t_perm_probability=0.5,
                                      t_routes_probability=0.5)
    print(f'After transpositions: {ma_perm3}')
    print(f'After mutation: {ma_route2}')

def main_check_gen_al():

    ma_distances = NP.random.randint(low=20, high=200, size=(100, 100))
    ma_distances[NP.eye(100, dtype=int)] = 0

    ma_vrp = VRP_CLASS(i_distance_matrix = ma_distances,
                       i_vehicles = 5,
                       i_population_multiple_of_16 = 160)

    for ma_generation in range(128):
        ma_vrp.function_fitness(ma_generation+1)
        if (ma_generation & 31) == 31:
            ma_vrp.function_save()

    # rnjf_matrix = rnjf_data['matrix_of_sequences']
    # rnjf_severities = rnjf_data['vector_of_severities']

    ma_vrp.function_get_leading()

# if __name__ == '__main__':
#     main()
#     #main_check_operators()

from scipy.sparse import csr_matrix as SCIPY_SPARSE_csr_matrix

def function_perm_matrix(pm_perm_arr:NP.array,pm_ones_arr:NP.array, pm_ordered_arr:NP.array):

    return SCIPY_SPARSE_csr_matrix((pm_ones_arr, (pm_ordered_arr, pm_perm_arr))).toarray()

def main_check_linear_algebra_algorithm():
    ma_ones = NP.ones(4)
    ma_ordered_arr = NP.array([i for i in range(4)], dtype=int)
    ma_perm_arr = NP.array([3,1,0,2])
    ma_out = function_perm_matrix(ma_perm_arr, ma_ones, ma_ordered_arr)
    print(ma_out)
    print(f'Reversed permutation: {ma_out.T @ ma_perm_arr}')

    ma_ones = NP.ones(7)
    ma_ordered_arr = NP.array([i for i in range(7)], dtype=int)

    ma_perm_arr = NP.array([0, 1, 0, 1, 2, 2, 0])
    ma_out1 = function_perm_matrix(ma_perm_arr, ma_ones, ma_ordered_arr)
    print(ma_out1.sum())
    ma_out1 = ma_out1 @ ma_out1.T
    print(ma_out1)

    ma_perm_arr = NP.array([3, 2, 3, 2, 1, 1, 3])
    ma_out2 = function_perm_matrix(ma_perm_arr, ma_ones, ma_ordered_arr)
    print(ma_out2.sum())
    ma_out2 = ma_out2 @ ma_out2.T
    print(ma_out2)

    print(ma_out2 - ma_out1)


if __name__ == '__main__':
    #main_check_linear_algebra_algorithm()
    main_check_gen_al()

