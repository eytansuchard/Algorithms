import numpy as NP

def function_inefficient_derangement(id_n: NP.int32):
    if id_n <= 1:
        return 0
    if 2 == id_n:
        return 1

    id_r1 = function_inefficient_derangement(id_n - 1)
    id_r2 = function_inefficient_derangement(id_n - 2)

    return (id_n-1) * (id_r1 + id_r2)

def main():

    for i in range(10):
        ma_n = NP.int32(i)
        ma_result = function_inefficient_derangement(ma_n)
        print(f'Derangement({ma_n}) = {ma_result}')

if __name__ == '__main__':
    main()
