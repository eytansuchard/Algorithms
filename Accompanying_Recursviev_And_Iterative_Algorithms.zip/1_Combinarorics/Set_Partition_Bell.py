import numpy as NP

SET_PARTITION_BELL_array = NP.zeros((26, 26), dtype=NP.int64)

# Bell triangle.
def function_set_partition(sp_n: NP.int32, sp_m: NP.int32 = 0) -> NP.int64:

    if sp_n >= 26:
        # Overflow error for this method.
        return 0

    if sp_n <= 0:
        return 1

    if SET_PARTITION_BELL_array[sp_n, sp_m] > 0:
        return SET_PARTITION_BELL_array[sp_n, sp_m]

    if 0 == sp_m:
        sp_ret = function_set_partition(sp_n-1, sp_n-1)
        SET_PARTITION_BELL_array[sp_n, sp_m] = sp_ret
        return sp_ret

    sp_ret = function_set_partition(sp_n-1, sp_m-1) + \
             function_set_partition(sp_n, sp_m-1)

    SET_PARTITION_BELL_array[sp_n, sp_m] = sp_ret

    return sp_ret

def main():
    for i in range(1, 11):
        print(f'Set partition({i})={function_set_partition(i)}')

if __name__ == '__main__':
    main()