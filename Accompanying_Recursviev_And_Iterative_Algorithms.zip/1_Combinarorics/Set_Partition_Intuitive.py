import numpy as NP
import math as MATH

SET_PARTITION_INTUITIVE_array = NP.zeros(26, dtype=NP.int64)

def function_set_partition2(sp_n: NP.int32) -> NP.int64:

    if sp_n >= 26:
        # Overflow error for this method.
        return 0

    if SET_PARTITION_INTUITIVE_array[sp_n] > 0:
        return SET_PARTITION_INTUITIVE_array[sp_n]

    if sp_n <= 1:
        return NP.int64(1)

    sp_sum = NP.int64(0)

    for i in range(1, sp_n+1):
        sp_r = MATH.comb(sp_n-1, i-1) * \
               function_set_partition2(NP.uint32(sp_n-i))
        sp_sum += sp_r

    SET_PARTITION_INTUITIVE_array[sp_n] = sp_sum

    return sp_sum

def main():
    for i in range(1, 11):
        print(f'Set partition({i})={function_set_partition2(i)}')

if __name__ == '__main__':
    main()