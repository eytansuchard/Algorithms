import numpy as NP

def generator_select(s_n: int, s_m: int) -> list[int]:

    s_indices_array = NP.zeros(s_m, dtype=int)

    s_top_array = NP.array(range(s_n - s_m, s_n), dtype=int)

    s_last_depth = -1
    s_depth = 0

    while True:

        # ------------------------------------------------------
        # Start: When moving to the next depth, restart the next
        #        number counter.
        # ------------------------------------------------------

        if s_depth > s_last_depth:
            if s_depth > 0:
                # Restart counting.
                s_indices_array[s_depth] = s_indices_array[s_depth - 1]
            else:
                s_indices_array[s_depth] = -1

        # ------------------------------------------------------
        # End: When moving to the next depth, restart the next
        #      number counter.
        # ------------------------------------------------------

        s_indices_array[s_depth] += 1

        # ------------------------------------------------------
        # Start: When reaching the top number for a given depth
        #        decrease the depth.
        # ------------------------------------------------------

        if s_indices_array[s_depth] > s_top_array[s_depth]:
            s_last_depth = s_depth
            s_depth -= 1
            if s_depth < 0:
                break
            else:
                continue
        # ------------------------------------------------------
        # End: When reaching the top number for a given depth
        #      decrease the depth.
        # ------------------------------------------------------

        # -----------------------------------------------------------------
        # Start: Either increase depth or generate an m out of n selection.
        # -----------------------------------------------------------------

        if (s_depth + 1) < s_m:
            s_last_depth = s_depth
            s_depth += 1
        else:
            s_last_depth = s_depth
            s_list = []
            for i in range(s_m):
                s_list.append(s_indices_array[i])

            yield s_list

        # -----------------------------------------------------------------
        # End: Either increase depth or generate an m out of n selection.
        # -----------------------------------------------------------------

def main():

    ma_n = 5
    ma_m = 3

    for i, ma_list in enumerate(generator_select(ma_n, ma_m)):
        print(f'({i})\t', end='')
        for ma_idx in ma_list:
            print(f'{ma_idx}\t', end='')
        print('')

if __name__ == '__main__':
    main()