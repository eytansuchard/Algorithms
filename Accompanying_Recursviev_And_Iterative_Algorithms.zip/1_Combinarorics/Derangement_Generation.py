import numpy as NP
from typing import Union as TYPING_Union

global MAIN_count

def function_generate_derangement(gd_n: int,
                                  gd_start: int = 0,
                                  gd_perm_arr:
                                  TYPING_Union[NP.ndarray[int], None] = None,
                                  gd_bool_arr:
                                  TYPING_Union[NP.ndarray[bool], None] =
                                  None):

    if gd_n <= 1:
        return

    if gd_perm_arr is None:
        gd_perm_arr = NP.array([i for i in range(gd_n)], dtype=int)
        gd_bool_arr = NP.ones(gd_n, dtype=bool)

    if gd_start + 2 == gd_n:

        global MAIN_count

        # --------------------------------------------------------------
        # Start: Treat the stopping condition where only two numbers are
        #        left.
        #        This is a tricky stopping condition because
        #        Derangement(3) = 2 (Derangement(2) + Derangement(1).
        #        Derangement(1) = 0 is reached but is a wasted stopping
        #        condition.
        # --------------------------------------------------------------

        if (gd_bool_arr[gd_start + 1] and gd_bool_arr[gd_start]):
            gd_perm_arr[gd_start], gd_perm_arr[gd_start + 1] = \
                gd_perm_arr[gd_start + 1], gd_perm_arr[gd_start]

            MAIN_count += 1

            print(f'({MAIN_count})\t', end='')

            for i in range(gd_n):
                print(f'{gd_perm_arr[i] + 1}\t', end='')

            print('')

            gd_perm_arr[gd_start], gd_perm_arr[gd_start + 1] = \
                gd_perm_arr[gd_start + 1], gd_perm_arr[gd_start]

        elif (not gd_bool_arr[gd_start + 1] and not gd_bool_arr[gd_start]):

            MAIN_count += 1

            print(f'({MAIN_count})\t', end='')

            for i in range(gd_n):
                print(f'{gd_perm_arr[i] + 1}\t', end='')

            print('')
        # else:
        #    print('Derangement(3) = 2 (Derangement(2) + Derangement(1)),
        #          where Derangement(1)=0 is wasted.')

        # --------------------------------------------------------------
        # End: Treat the stopping condition where only two numbers are
        #        left.
        # --------------------------------------------------------------

    else:
        if gd_bool_arr[gd_start]:
            for i in range(gd_start + 1, gd_n):
                if gd_bool_arr[i]:

                    # Swap the value at the starting position gd_start with
                    # the value at i > gd_start.
                    gd_perm_arr[gd_start], gd_perm_arr[i] = \
                        gd_perm_arr[i], gd_perm_arr[gd_start]

                    # ----------------------------------------------------
                    # Start: Perform recursive call that no longer touches
                    #        the swapped number.
                    # ----------------------------------------------------

                    gd_bool_arr[i] = False

                    function_generate_derangement(gd_n,
                                                  gd_start + 1,
                                                  gd_perm_arr,
                                                  gd_bool_arr)

                    gd_bool_arr[i] = True

                    # ----------------------------------------------------
                    # End: Perform recursive call that no longer touches
                    # the swapped number.
                    # ----------------------------------------------------

                    # ---------------------------------------------------
                    # Start: Perform recursive call that touches also the
                    #        swapped number.
                    # ---------------------------------------------------

                    function_generate_derangement(gd_n,
                                                  gd_start + 1,
                                                  gd_perm_arr,
                                                  gd_bool_arr)

                    # ---------------------------------------------------
                    # End: Perform recursive call that touches also the
                    #      swapped number.
                    # ---------------------------------------------------

                    # Swap the value at the starting position gd_start
                    # with the value at i > gd_start.
                    # This is a cleanup step after returning from a
                    # recursive call.
                    gd_perm_arr[gd_start], gd_perm_arr[i] = \
                        gd_perm_arr[i], gd_perm_arr[gd_start]
        else:
            function_generate_derangement(gd_n,
                                          gd_start + 1,
                                          gd_perm_arr,
                                          gd_bool_arr)

    return


def main():
    global MAIN_count
    MAIN_count = 0
    function_generate_derangement(4)


if __name__ == '__main__':
    main()
