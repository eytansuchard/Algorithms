import numpy as NP
from typing import Union as TYPING_Union

# ****************************************************
# Start: Simple combinatorial selection of m out of n,
# which is n! / ((n-m)! * m!) possible sets.
# ****************************************************

def generator_select(s_n: int, s_m: int) -> list[int]:

    s_indices_array = NP.zeros(s_m, dtype=int)

    s_top_array = NP.array(range(s_n - s_m, s_n), dtype=int)

    s_last_depth = -1
    s_depth = 0

    while True:

        # ------------------------------------------------------
        # Start: When moving to the next depth, restart the next
        #        number counter.
        # ------------------------------------------------------

        if s_depth > s_last_depth:
            if s_depth > 0:
                # Restart counting.
                s_indices_array[s_depth] = s_indices_array[s_depth - 1]
            else:
                s_indices_array[s_depth] = -1

        # ------------------------------------------------------
        # End: When moving to the next depth, restart the next
        #      number counter.
        # ------------------------------------------------------

        s_indices_array[s_depth] += 1

        # ------------------------------------------------------
        # Start: When reaching the top number for a given depth
        #        decrease the depth.
        # ------------------------------------------------------

        if s_indices_array[s_depth] > s_top_array[s_depth]:
            s_last_depth = s_depth
            s_depth -= 1
            if s_depth < 0:
                break
            else:
                continue
        # ------------------------------------------------------
        # End: When reaching the top number for a given depth
        #      decrease the depth.
        # ------------------------------------------------------

        # -----------------------------------------------------------------
        # Start: Either increase depth or generate an m out of n selection.
        # -----------------------------------------------------------------

        if (s_depth + 1) < s_m:
            s_last_depth = s_depth
            s_depth += 1
        else:
            s_last_depth = s_depth
            s_list = []
            for i in range(s_m):
                s_list.append(s_indices_array[i])

            yield s_list

        # -----------------------------------------------------------------
        # End: Either increase depth or generate an m out of n selection.
        # -----------------------------------------------------------------

# ****************************************************
# End: Simple combinatorial selection of m out of n,
# which is n! / ((n-m)! * m!) possible sets.
# ****************************************************

# ************************************************
# Start: Perform set partition.
# The stopping condition prints sp_list_of_arrays.
# ************************************************

def function_set_partition(sp_n: int,
                           sp_array: TYPING_Union[NP.ndarray[int], None] =
                           None,
                           sp_list_of_arrays:
                           TYPING_Union[list[NP.ndarray[int]], None] = None):

    # -----------------------------------------------------------
    # Start: Threat the stopping condition when all elements were
    #        accounted for.
    # -----------------------------------------------------------

    if sp_n < 1:
        sp_num_of_sets = len(sp_list_of_arrays)

        for sp_set_counter, sp_arr in enumerate(sp_list_of_arrays):
            for i in range(sp_arr.shape[0]):
                if 0 == i:
                    if sp_arr.shape[0] != 1:
                        print('{ ' + f'{sp_arr[i]}, ', end='')
                    else:
                        if sp_set_counter + 1 < sp_num_of_sets:
                            print('{ ' + f'{sp_arr[i]} ' + '}, ', end='')
                        else:
                            print('{ ' + f'{sp_arr[i]} ' + '}', end='')
                elif (i+1) < sp_arr.shape[0]:
                    print(f'{sp_arr[i]}, ', end='')
                else:
                    if sp_set_counter + 1 < sp_num_of_sets:
                        print(f'{sp_arr[i]}' + ' }, ', end='')
                    else:
                        print(f'{sp_arr[i]}' + ' }', end='')
        print('')
        return

    # -----------------------------------------------------------
    # End: Threat the stopping condition when all elements were
    #      accounted for.
    # -----------------------------------------------------------

    # Initialization of the array of elements.
    if sp_array is None:
        sp_array = NP.arange(0, sp_n, dtype=int)

    # Initialization of the list of arrays which makes the set partition.
    if sp_list_of_arrays is None:
        sp_list_of_arrays = []

    # -----------------------------------------------------
    # Start: select the first element in a one element set.
    # -----------------------------------------------------

    sp_cur_array = sp_array[[0]]
    sp_next_array = NP.delete(sp_array, [0])
    sp_list_of_arrays.append(sp_cur_array)

    # Recursive call to treat the remaining elements.
    function_set_partition(sp_n - 1, sp_next_array,
                           sp_list_of_arrays)

    # After the recursive call remove the last set from the list of sets.
    sp_list_of_arrays.pop()

    # -----------------------------------------------------
    # End: select the first element in a one element set.
    # -----------------------------------------------------

    for i in range(1, sp_n):

        for sp_select_m_from_n_list in generator_select(sp_n-1, i):

            # -----------------------------------------------------------
            # Start: select the first element with additional i elements.
            # -----------------------------------------------------------

            sp_list_of_current_selection = \
                [0] + [i+1 for i in sp_select_m_from_n_list]

            sp_cur_array = sp_array[sp_list_of_current_selection]
            sp_next_array = NP.delete(sp_array, sp_list_of_current_selection)
            sp_list_of_arrays.append(sp_cur_array)

            # Recursive call to treat the remaining elements.
            function_set_partition(sp_n-len(sp_list_of_current_selection),
                                   sp_next_array,
                                   sp_list_of_arrays)

            # After the recursive call remove the last set from the list of
            # sets.
            sp_list_of_arrays.pop()

            # -----------------------------------------------------------
            # End: select the first element with additional i elements.
            # -----------------------------------------------------------

    return # return can be skipped buy is here for clarity.

# ************************************************
# End: Perform set partition.
# The stopping condition prints sp_list_of_arrays.
# ************************************************

def main():

    ma_n = 5
    print(f'Set partition of n={ma_n}')
    function_set_partition(ma_n)

if __name__ == '__main__':
    main()