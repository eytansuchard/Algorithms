import numpy as NP
import math as MATH

SET_PARTITION_INTUITIVE_array = NP.zeros((26, 26), dtype=NP.int64)

def function_set_partition_n_to_m(sp_n: NP.int32, sp_m: NP.int32) -> NP.int64:

    if sp_n >= 27:
        # Overflow error for this method.
        return 0

    if sp_n < sp_m or sp_n < 1:
        # Should not get here.
        return 0
    elif sp_n == sp_m:
        return 1
    elif sp_m == 1:
        return 1

    sp_m_minus_1 = sp_m - 1
    sp_n_minus_1 = sp_n - 1

    if SET_PARTITION_INTUITIVE_array[sp_n_minus_1, sp_m_minus_1] > 0:
        return SET_PARTITION_INTUITIVE_array[sp_n, sp_m]

    sp_sum = NP.int64(0)

    for i in range(sp_m_minus_1, sp_n):
        sp_r = MATH.comb(sp_n_minus_1, sp_n_minus_1 - i) * \
               function_set_partition_n_to_m(NP.uint32(i), sp_m_minus_1)
        sp_sum += sp_r

    SET_PARTITION_INTUITIVE_array[sp_n_minus_1, sp_m_minus_1] = sp_sum

    return sp_sum

def main():

    ma_n = 13
    ma_m = 5

    print(f'Set partition({ma_n}, {ma_m})={function_set_partition_n_to_m(ma_n, ma_m)}')

if __name__ == '__main__':
    main()