import numpy as NP

def function_efficient_derangement(ed_n: NP.int32):

    if ed_n <= 1:
        return 0, 0

    if 2 == ed_n:
        return 1, 0

    ed_r1, ed_r2 = function_efficient_derangement(ed_n - 1)

    return (ed_n-1) * (ed_r1 + ed_r2), ed_r1

def main():

    for i in range(10):
        ma_n = NP.int32(i)
        ma_result, _ = function_efficient_derangement(ma_n)
        print(f'Derangement({ma_n}) = {ma_result}')

if __name__ == '__main__':
    main()
