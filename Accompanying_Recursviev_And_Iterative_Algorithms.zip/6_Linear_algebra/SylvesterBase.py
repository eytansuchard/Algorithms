import numpy as NP

def function_Sylvester_base(Sb_n:int):

    if Sb_n == 1:
        return NP.ones(1, dtype=NP.int32)
    elif Sb_n < 1 or Sb_n > 12:
        print('\033[31mn must be between 1 and 12\033[00m')
        return None # Error.

    Sb_B = function_Sylvester_base(Sb_n-1)
    Sb_A = NP.tile(Sb_B, (2, 2))
    Sb_half = 1 << (Sb_n - 2) # 2 ** (Sb_n - 2)
    Sb_A[Sb_half:, Sb_half:] = -Sb_A[Sb_half:, Sb_half:]
    return Sb_A

def main():
    ma_n = 4
    print(f'James Sylvester\'s matrix for n = {ma_n},')
    ma_A = function_Sylvester_base(ma_n)
    print(ma_A)

if __name__ == '__main__':
    main()
