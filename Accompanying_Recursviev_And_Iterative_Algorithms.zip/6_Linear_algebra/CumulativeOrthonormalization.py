import numpy as NP

class CUMULATIVE_ORTHONORMALIZATION_CLASS:
    def __init__(self, i_dimension: int, i_limit_on_n: bool = True):

        if i_dimension < 1:
            self.member_n = None
            self.member_dimension = None
            self.member_average = None
            self.member_eigen_vectors = None
            self.member_unit_vectors = None
            return

        self.member_n = 1
        self.member_dimension = i_dimension
        self.member_average = NP.zeros(i_dimension, dtype=NP.float64)
        self.member_sum = NP.zeros(i_dimension, dtype=NP.float64)
        self.member_eigen_vectors = NP.eye(i_dimension, dtype=NP.float64)
        self.member_unit_vectors = NP.eye(i_dimension, dtype=NP.float64)
        self.member_eigen_values = NP.ones(i_dimension, dtype=NP.float64)
        self.member_limit_on_n = i_limit_on_n

    def function_update(self, u_v_in: NP.ndarray):
        # --------------------------------------
        # Start: Cumulative ortho-normalization.
        # --------------------------------------

        u_v = u_v_in - self.member_average

        # -----------------------------------------
        # Start: Update principal variance vectors.
        # -----------------------------------------

        for i in range(self.member_dimension):

            if i > 0:
                u_dot = NP.dot(u_v, self.member_unit_vectors[:, i - 1])
                u_v -= u_dot * self.member_unit_vectors[:, i - 1]

            u_dot = NP.dot(u_v, self.member_unit_vectors[:, i])

            self.member_eigen_vectors[:, i] += \
                NP.sign(u_dot) * NP.linalg.norm(u_v) * u_v

            for k in range(i):
                u_dot = NP.dot(self.member_eigen_vectors[:, i],
                               self.member_unit_vectors[:, k])

                self.member_eigen_vectors[:, i] -= \
                    u_dot * self.member_unit_vectors[:, k]

            u_aux = self.member_eigen_vectors[:, i] / self.member_n
            self.member_unit_vectors[:, i] = \
                u_aux / NP.linalg.norm(u_aux)

            self.member_eigen_values[i] = \
                NP.dot(self.member_unit_vectors[:, i],
                       self.member_eigen_vectors[:, i]) / self.member_n


        # -----------------------------------------
        # End: Update principal variance vectors.
        # -----------------------------------------

        self.member_sum += u_v_in
        self.member_n += 1
        self.member_average = self.member_sum / self.member_n

        # --------------------------------------
        # End: Cumulative ortho-normalization.
        # --------------------------------------

        # -----------------------------------------------
        # Start: Implement numerical stability algorithm.
        # -----------------------------------------------

        if self.member_limit_on_n:
            if self.member_n >= 500000:
                self.member_sum /= 2
                self.member_eigen_vectors /= 2
                self.member_n >>= 1
        # -----------------------------------------------
        # End: Implement numerical stability algorithm.
        # -----------------------------------------------

    # Usually useful is the statistical distance function.
    # If the eigenvalues are 1 it reduced to an ordinary
    # Euclidean distance.
    def function_distance(self, d_v_in):

        d_v = d_v_in - self.member_average

        d_projector = (self.member_unit_vectors.T @ d_v) ** 2 / \
                      NP.clip(self.member_eigen_values,
                              a_min=0.000000000001,
                              a_max=None)

        return NP.sqrt(d_projector.sum())


def main():

    # *****************************************************
    # Start: Create multivariate Gauss distribution params.
    # *****************************************************

    ma_cumulative_class = CUMULATIVE_ORTHONORMALIZATION_CLASS(3)
    ma_mean = NP.array([4, 2, 8], dtype=NP.float64)

    # -----------------------------------------------------------
    # Start: Choose non-trivial principal directions by rotation.
    # -----------------------------------------------------------

    ma_phi = NP.pi / 4
    ma_theta = -ma_phi

    ma_cos, ma_sin = NP.cos(ma_theta), -NP.sin(ma_theta)

    ma_R1 = NP.array([[ma_cos, -ma_sin, 0], [ma_sin, ma_cos, 0],
                      [0, 0, 1]],
                     dtype=NP.float64)

    ma_cos, ma_sin = NP.cos(ma_phi), -NP.sin(ma_phi)

    ma_R2 = NP.array([[0, ma_cos, -ma_sin], [0, ma_sin, ma_cos],
                      [1, 0, 0]],
                     dtype=NP.float64)
    ma_R = ma_R2 @ ma_R1

    # -----------------------------------------------------------
    # End: Choose non-trivial principal directions by rotation.
    # -----------------------------------------------------------

    ma_D = NP.eye(3, dtype=NP.float64)
    ma_D[0, 0] = 9
    ma_D[1, 1] = 3
    ma_D[2, 2] = 2
    ma_ground_truth_eigs = NP.diag(ma_D, k=0) ** 2

    ma_A = ma_D @ ma_R
    ma_cov = ma_A @ ma_A.T

    # *****************************************************
    # End: Create multivariate Gauss distribution params.
    # *****************************************************

    # Generate 1000 samples
    ma_samples = NP.random.multivariate_normal(ma_mean, ma_cov, 5000)

    ma_cov2 = NP.zeros((3, 3), dtype=NP.float64)

    for i in range(ma_samples.shape[0]):
        ma_cumulative_class.function_update(ma_samples[i])

        # This calculation uses the known average, so it gives
        # an advantage to the standard PCA.
        ma_sample = ma_samples[i] - ma_mean
        ma_cov2 += NP.outer(ma_sample, ma_sample)

        #ma_d = ma_cumulative_class.function_distance(ma_samples[i])
        #print(f'Iteration {i}, '
        #      f'Distance {ma_d}')
        print(f'Iteration {i}')

        for k in range(3):
            print(f'{ma_cumulative_class.member_eigen_values[k]:.5f}/'
                  f'{ma_ground_truth_eigs[k]}, ', end='')
        print('\n---------------')

    ma_eigenvalues, _ = NP.linalg.eig(ma_cov2/ma_samples.shape[0])
    print('The ground truth average is used in the standard PCA'
          ' calculation, not really fair!')
    print(ma_eigenvalues)

if __name__ == '__main__':
    main()
