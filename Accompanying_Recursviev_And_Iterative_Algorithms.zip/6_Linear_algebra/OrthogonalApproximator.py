import numpy as NP

def function_approximate_orthogonal(ao_matrix: NP.ndarray,
                                    ao_iterations: int = 32,
                                    ao_epsilon:NP.float64= 1e-20):

    if ao_matrix.ndim != 2:
        return None

    if ao_matrix.shape[0] < 2:
        return None

    ao_a = ao_matrix.copy()

    ao_det = NP.linalg.det(ao_a)
    ao_a /= ao_det

    for ao_iter in range(ao_iterations):

        ao_delta = NP.linalg.inv(ao_a.T) - ao_a

        if NP.isnan(ao_delta).any():
            ao_a = None
            break

        ao_a += ao_delta * 0.6

        ao_err = NP.abs((ao_a @ ao_a.T - NP.eye(ao_a.shape[0],
                                                dtype=NP.float64))).max()
        print('{:3d}, Max error {:.8f}'.format(ao_iter, ao_err))

        if ao_err < ao_epsilon:
            break

    return ao_a

def function_approximate_ortogonal_using_SVD(aouS_matrix):
    aouS_U, aouS_S, aouS_Vt = NP.linalg.svd(aouS_matrix)
    aou_err = NP.abs(aouS_S - NP.eye(aouS_matrix.shape[0],
                                     dtype=NP.float64)).max()
    aouS_a = aouS_U @ aouS_Vt
    print('SVD eigenvalue error estimation: {:.10f}'.format(aou_err))
    return aouS_a

def main():
    ma_matrix = NP.array([[1, 0, 1], [1, -1, 0], [0, 1, -1]],
                         dtype=NP.float64)
    ma_matrix /= NP.linalg.det(ma_matrix)
    ma_a = function_approximate_orthogonal(ma_matrix)
    print("Initial matrix:")
    print(ma_matrix)
    print("Close orthogonal matrix by iterations:")
    print(ma_a)
    print("A * A^t - I:")
    print(ma_a @ ma_a.T)
    ma_b = function_approximate_ortogonal_using_SVD(ma_matrix)
    print("Close orthogonal matrix by SVD:")
    print(ma_a)
    print("B * B^t - I:")
    print(ma_b @ ma_b.T)


if __name__ == '__main__':
    main()



