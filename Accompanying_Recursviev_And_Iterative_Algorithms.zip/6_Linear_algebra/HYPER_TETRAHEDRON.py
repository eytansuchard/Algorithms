import numpy as NP

class HYPER_TETRAHEDRON_CLASS(object):

    def __init__(self, i_dim):
        super(HYPER_TETRAHEDRON_CLASS, self)

        if i_dim < 2:
            self.member_dim = 0
            self.member_vertices = None
            return

        self.member_dim = i_dim

        # -------------------------------------------
        # Start: create hyper tetrahedron's vertices.
        # -------------------------------------------

        i_eye = NP.eye(i_dim, dtype=NP.float64)
        i_array = NP.zeros(shape=(i_dim, i_dim+1), dtype=NP.float64)
        i_center = NP.zeros(i_dim, dtype=NP.float64)

        for i in range(1, i_dim + 1):

            i_center = i_array[:, :i].mean(axis=1)
            i_squared_norm = NP.dot(i_center, i_center)
            i_height = NP.sqrt(1 - i_squared_norm)
            # Column zero of i_eye is never used.
            i_array[:, i] = i_center + i_eye[:, i - 1] * i_height

        # Start, move the hyper tetrahedron around 0.
        i_center = i_array.mean(axis=1)
        self.member_vertices = i_array - NP.expand_dims(i_center, axis=1)
        # End, move the hyper tetrahedron around 0.

        # -------------------------------------------
        # End: create hyper tetrahedron's vertices.
        # -------------------------------------------

        # ----------------------------------------------
        # Start, Create more vectors from the vertices.
        # ---------------------------------------------

        self.member_vectors = \
            NP.zeros((i_dim,
                      (i_dim + 1) ** 2 + (i_dim + 1) *
                      (i_dim * (i_dim - 1))),
                      dtype=NP.float64)

        self.member_vectors[:, :i_dim + 1] = \
            self.member_vertices / NP.linalg.norm(self.member_vertices[:, 0])

        i_count = i_dim + 1

        for i in range(i_dim + 1):
            i_opposite = -self.member_vertices[:, i]
            for k in range(i_dim+1):
                if k != i:
                    i_mid_vector = \
                        (i_opposite + self.member_vertices[:, k]) / 2
                    i_mid_vector /= NP.linalg.norm(i_mid_vector)
                    self.member_vectors[:, i_count] = i_mid_vector
                    i_count += 1
                    for j in range(k + 1, i_dim + 1):
                        if j != i:
                            i_mid_vector1 = \
                                ( self.member_vertices[:, j] +
                                  self.member_vertices[:, k]) / 2
                            i_mid_vector2 = (i_opposite + i_mid_vector1) / 2
                            self.member_vectors[:, i_count] = i_mid_vector1
                            i_count += 1
                            self.member_vectors[:, i_count] = i_mid_vector2
                            i_count += 1

        print(f'Count = {i_count}')

        # ----------------------------------------------
        # End, Create more vectors from the vertices.
        # ---------------------------------------------

    def function_check_norms(self):
        for i in range(self.member_dim):
            for k in range(i+1, self.member_dim + 1):
                cn_norm = \
                    NP.linalg.norm(self.member_vertices[:, k] -
                                   self.member_vertices[:, i])
                print(f'Norms({i}, {k}) = {cn_norm}')

def main():

    ma_dim = 4
    ma_tetra = HYPER_TETRAHEDRON_CLASS(ma_dim)

    ma_tetra.function_check_norms()

if __name__ == '__main__':
    main()


