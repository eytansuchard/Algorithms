
from typing import Union as TYPING_Union
import numpy as NP

def function_merge_sort(ms_arr: NP.ndarray, ms_start: int=0,
                        ms_end: TYPING_Union[int, None] = None,
                        ms_auxiliary_arr:
                        TYPING_Union[NP.ndarray[int], None] = None):

    if ms_end is None:
        ms_end = ms_arr.shape[0]

    ms_n = ms_end - ms_start

    if 1 == ms_n:
        return

    if 2 == ms_n:
        if ms_arr[ms_start] > ms_arr[ms_end-1]:
            ms_swap = ms_arr[ms_start]
            ms_arr[ms_start] = ms_arr[ms_end-1]
            ms_arr[ms_end - 1] = ms_swap
        return

    ms_mid = (ms_start + ms_end) >> 1

    if ms_auxiliary_arr is None:
        ms_auxiliary_arr = NP.empty(ms_n, dtype=NP.int32)

    function_merge_sort(ms_arr, ms_start, ms_mid)
    function_merge_sort(ms_arr, ms_mid, ms_end)

    # ---------------------------------------------------
    # Start: Merge two parts of ms_arr, assuming that the
    # two parts are already sorted.
    # ---------------------------------------------------

    (ms_i, ms_i1, ms_i2) = (0, ms_start, ms_mid)

    while ms_i < ms_n:
        if ms_i1 < ms_mid and ms_i2 < ms_end:
            if ms_arr[ms_i1] <= ms_arr[ms_i2]:
                ms_auxiliary_arr[ms_i] = ms_arr[ms_i1]
                ms_i1 += 1
                ms_i += 1
            else:
                ms_auxiliary_arr[ms_i] = ms_arr[ms_i2]
                ms_i2 += 1
                ms_i += 1
        elif ms_i2 < ms_end:
            ms_auxiliary_arr[ms_i: ms_n] = ms_arr[ms_i2: ms_end]
            ms_i = ms_n
            ms_i2 = ms_end
        elif ms_i1 < ms_mid:
            ms_auxiliary_arr[ms_i: ms_n] = ms_arr[ms_i1: ms_mid]
            ms_i = ms_n
            ms_i1 = ms_mid
        else:
            if ms_i < ms_n:
                print('\033[92mError!\033[00m')

    ms_arr[ms_start: ms_end] = ms_auxiliary_arr[0: ms_n]

    # ---------------------------------------------------
    # End: Merge two parts of ms_arr, assuming that the
    # two parts are already sorted.
    # ---------------------------------------------------


def function_merge_sort_index(msi_arr: NP.ndarray,
                              msi_index_arr:
                              TYPING_Union[NP.ndarray[int], None] = None,
                              msi_start: int = 0,
                              msi_end: TYPING_Union[int, None] = None,
                              msi_auxiliary_arr:
                              TYPING_Union[NP.ndarray[int], None] = None):

    if msi_end is None:
        msi_end = msi_arr.shape[0]

    msi_n = msi_end - msi_start

    if msi_index_arr is None:
        msi_index_arr = \
            NP.arange(start=0, stop=msi_n, dtype=NP.int32)

    if 1 == msi_n:
        return

    if 2 == msi_n:
        if msi_arr[msi_index_arr[msi_start]] > \
                msi_arr[msi_index_arr[msi_end-1]]:
            msi_swap = msi_index_arr[msi_start]
            msi_index_arr[msi_start] = msi_index_arr[msi_end-1]
            msi_index_arr[msi_end - 1] = msi_swap
        return

    msi_mid = (msi_start + msi_end) >> 1

    if msi_auxiliary_arr is None:
        msi_auxiliary_arr = NP.empty(msi_n, dtype=NP.int32)

    function_merge_sort_index(msi_arr,
                              msi_index_arr, msi_start, msi_mid)
    function_merge_sort_index(msi_arr,
                              msi_index_arr, msi_mid, msi_end)

    # ------------------------------------------------------
    # Start: Merge two parts of msi_index_arr, assuming that
    #        the two parts are already sorted.
    #        Sorting of msi_index_arr is by msi_arr.
    # ------------------------------------------------------

    (msi_i, msi_i1, msi_i2) = (0, msi_start, msi_mid)

    while msi_i < msi_n:
        if msi_i1 < msi_mid and msi_i2 < msi_end:
            if msi_arr[msi_index_arr[msi_i1]] <= \
                    msi_arr[msi_index_arr[msi_i2]]:
                msi_auxiliary_arr[msi_i] = msi_index_arr[msi_i1]
                msi_i1 += 1
                msi_i += 1
            else:
                msi_auxiliary_arr[msi_i] = msi_index_arr[msi_i2]
                msi_i2 += 1
                msi_i += 1
        elif msi_i2 < msi_end:
            msi_auxiliary_arr[msi_i: msi_n] = \
                msi_index_arr[msi_i2: msi_end]
            msi_i = msi_n
            msi_i2 = msi_end
        elif msi_i1 < msi_mid:
            msi_auxiliary_arr[msi_i: msi_n] = \
                msi_index_arr[msi_i1: msi_mid]
            msi_i = msi_n
            msi_i1 = msi_mid
        else:
            if msi_i < msi_n:
                print('\033[92mError!\033[00m')

    msi_index_arr[msi_start: msi_end] = \
        msi_auxiliary_arr[0: msi_n]

    # ------------------------------------------------------
    # End: Merge two parts of msi_index_arr, assuming that
    #      the two parts are already sorted.
    #      Sorting of msi_index_arr is by msi_arr.
    # ------------------------------------------------------

    return msi_index_arr


def main():

    ma_size = 20
    ma_arr = NP.random.randint(low=0, high=100, size=ma_size, dtype=NP.int32)

    print('Original array, array by sorted index,'
          ' sorted array, reconstructed array:')

    for i in range(ma_size):
        print(f'{ma_arr[i]:2} ', end='')

    print('')

    # function_merge_sort_index does not change ma_arr
    # but returns sorting through the index.
    ma_index_arr = function_merge_sort_index(ma_arr)

    for i in range(ma_size):
        print(f'{ma_arr[ma_index_arr[i]]:2} ', end='')

    print('')

    # function_merge_sort sorts the array.
    function_merge_sort(ma_arr)

    for i in range(ma_size):
        print(f'{ma_arr[i]:2} ', end='')

    print('')

    ma_arr[ma_index_arr] = ma_arr.copy()

    for i in range(ma_size):
        print(f'{ma_arr[i]:2} ', end='')

    print('')

if __name__ == '__main__':
    main()
