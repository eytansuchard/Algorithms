# Balanced tree that also supports ordinal index.
# It is the most sophisticated balanced tree.
# Instead of a Balance Factor per each node,
# Depth left and depth right are used in a way in which the
# code is easier to understand.
# Usually nodes hold not only a key but also point to data,
# unlike this implementation.
# This implementation does not support duplicate keys and
# will print a "Duplicate key error" message whenever a
# duplicate key is inserted into the tree.
# Exercises:
# 1: Add data, e.g. random number between 1 and 1000000.
# 2: Add a function to get an equal or greater value than
#    a given key.
# 3: Add a function to get an equal or smaller value than
#    a given key.

from typing import Union as TYPING_Union
import random as RANDOM

class AVL_NODE_CLASS:
    def __init__(self, i_key: TYPING_Union[int, None]):
        self.member_left = None
        self.member_right = None
        self.member_left_count = 0
        self.member_right_count = 0
        self.member_left_depth = 0
        self.member_right_depth = 0
        self.member_key = i_key

class AVL_TREE_CLASS:

    def __init__(self):
        self.member_root = AVL_NODE_CLASS(None)

    def function_rotate_left(self, rl_x: AVL_NODE_CLASS) -> \
            AVL_NODE_CLASS:
        # For right - right balance violations.
        # This implementation maintains ordinal index
        # variables and depth variables.
        rl_z = rl_x.member_right
        rl_c1 = rl_x.member_left_count
        rl_d1 = rl_x.member_left_depth
        rl_t23 = rl_z.member_left
        rl_c23 = rl_z.member_left_count
        rl_d23 = rl_z.member_left_depth
        rl_z.member_left = rl_x
        rl_z.member_left_count = 1 + rl_c1 + rl_c23
        rl_z.member_left_depth = 1 + max(rl_d1, rl_d23)
        rl_x.member_right = rl_t23
        rl_x.member_right_count = rl_c23
        rl_x.member_right_depth = rl_d23
        return rl_z

    def function_rotate_right(self, rr_x: AVL_NODE_CLASS) -> \
            AVL_NODE_CLASS:
        # For left - left balance violations.
        # This implementation maintains ordinal index
        # variables and depth variables.
        rr_z = rr_x.member_left
        rr_c1 = rr_x.member_right_count
        rr_d1 = rr_x.member_right_depth
        rr_t23 = rr_z.member_right
        rr_c23 = rr_z.member_right_count
        rr_d23 = rr_z.member_right_depth
        rr_z.member_right = rr_x
        rr_z.member_right_count = 1 + rr_c1 + rr_c23
        rr_z.member_right_depth = 1 + max(rr_d1, rr_d23)
        rr_x.member_left = rr_t23
        rr_x.member_left_count = rr_c23
        rr_x.member_left_depth = rr_d23

        return rr_z

    def function_rotate_right_left(self, rrl_x: AVL_NODE_CLASS) ->\
            AVL_NODE_CLASS:
        # For right - left balance violations.
        # This implementation maintains ordinal index
        # variables and depth variables.
        rrl_z = rrl_x.member_right
        rrl_y = rrl_z.member_left
        rrl_c1 = rrl_x.member_left_count
        rrl_d1 = rrl_x.member_left_depth
        rrl_t2 = rrl_y.member_left
        rrl_c2 = rrl_y.member_left_count
        rrl_d2 = rrl_y.member_left_depth
        rrl_t3 = rrl_y.member_right
        rrl_c3 = rrl_y.member_right_count
        rrl_d3 = rrl_y.member_right_depth
        rrl_c4 = rrl_z.member_right_count
        rrl_d4 = rrl_z.member_right_depth
        rrl_y.member_left = rrl_x
        rrl_y.member_right = rrl_z
        rrl_y.member_left_count = 1 + rrl_c1 + rrl_c2
        rrl_y.member_left_depth = 1 + max(rrl_d1, rrl_d2)
        rrl_y.member_right_count = 1 + rrl_c3 + rrl_c4
        rrl_y.member_right_depth = 1 + max(rrl_d3, rrl_d4)
        rrl_x.member_right = rrl_t2
        rrl_x.member_right_count = rrl_c2
        rrl_x.member_right_depth = rrl_d2
        rrl_z.member_left = rrl_t3
        rrl_z.member_left_count = rrl_c3
        rrl_z.member_left_depth = rrl_d3

        return rrl_y

    def function_rotate_left_right(self, rlr_x: AVL_NODE_CLASS) -> \
            AVL_NODE_CLASS:
        # For left - right balance violations.
        # This implementation maintains ordinal index
        # variables and depth variables.
        rlr_z = rlr_x.member_left
        rlr_y = rlr_z.member_right
        rlr_c1 = rlr_x.member_right_count
        rlr_d1 = rlr_x.member_right_depth
        rlr_t2 = rlr_y.member_right
        rlr_c2 = rlr_y.member_right_count
        rlr_d2 = rlr_y.member_right_depth
        rlr_t3 = rlr_y.member_left
        rlr_c3 = rlr_y.member_left_count
        rlr_d3 = rlr_y.member_left_depth
        rlr_c4 = rlr_z.member_left_count
        rlr_d4 = rlr_z.member_left_depth
        rlr_y.member_right = rlr_x
        rlr_y.member_left = rlr_z
        rlr_y.member_right_count = 1 + rlr_c1 + rlr_c2
        rlr_y.member_right_depth = 1 + max(rlr_d1, rlr_d2)
        rlr_y.member_left_count = 1 + rlr_c3 + rlr_c4
        rlr_y.member_left_depth = 1 + max(rlr_d3, rlr_d4)
        rlr_x.member_left = rlr_t2
        rlr_x.member_left_count = rlr_c2
        rlr_x.member_left_depth = rlr_d2
        rlr_z.member_right = rlr_t3
        rlr_z.member_right_count = rlr_c3
        rlr_z.member_right_depth = rlr_d3

        return rlr_y


    def function_insert(self, i_node: AVL_NODE_CLASS,
                        i_parent: TYPING_Union[AVL_NODE_CLASS, None],
                        i_is_right: bool, i_key: int) -> (bool, int):

        if i_node is None:
            i_node = AVL_NODE_CLASS(i_key)
            if i_parent is not None:
                if i_is_right:
                    i_parent.member_right = i_node
                    # The parent counter will be incremented upon return.
                    i_parent.member_right_count = 0
                else:
                    i_parent.member_left = i_node
                    # The parent counter will be incremented upon return.
                    i_parent.member_left_count = 0
            return True, 1

        # Root case.
        if i_node.member_key is None:
            i_node.member_key = i_key
            return True, 0

        if i_key < i_node.member_key:

            i_ok, i_left_depth = \
                self.function_insert(i_node.member_left, i_node, False,
                                     i_key)

            if i_ok:
                i_node.member_left_count += 1
                i_node.member_left_depth = i_left_depth

                # -----------------------------------------------
                # Start: Checking for left-right or other balance
                #        violations.
                # -----------------------------------------------

                if i_node.member_left_depth >= \
                        i_node.member_right_depth + 2:
                    i_left = i_node.member_left

                    if i_left.member_left_depth < i_left.member_right_depth:
                        i_node = self.function_rotate_left_right(i_node)
                        if i_parent is not None:
                            if i_is_right:
                                i_parent.member_right = i_node
                            else:
                                i_parent.member_left = i_node
                        else:
                            self.member_root = i_node
                    else:
                        i_node = self.function_rotate_right(i_node)
                        if i_parent is not None:
                            if i_is_right:
                                i_parent.member_right = i_node
                            else:
                                i_parent.member_left = i_node
                        else:
                            self.member_root = i_node

                # -----------------------------------------------------------
                # End: Checking for left-right or other balance
                #      violations.
                # -----------------------------------------------------------

                return True, 1 + max(i_node.member_left_depth,
                                     i_node.member_right_depth)

        elif i_key > i_node.member_key:
            i_ok, i_right_depth =\
                self.function_insert(i_node.member_right, i_node, True,
                                     i_key)

            if i_ok:
                i_node.member_right_count += 1
                i_node.member_right_depth = i_right_depth

                # -----------------------------------------------
                # Start: Checking for right-left or other balance
                #        violations.
                # -----------------------------------------------

                if i_node.member_right_depth >= \
                        i_node.member_left_depth + 2:
                    i_right = i_node.member_right

                    if i_right.member_right_depth < \
                            i_right.member_left_depth:
                        i_node = self.function_rotate_right_left(i_node)
                        if i_parent is not None:
                            if i_is_right:
                                i_parent.member_right = i_node
                            else:
                                i_parent.member_left = i_node
                        else:
                            self.member_root = i_node
                    else:
                        i_node = self.function_rotate_left(i_node)
                        if i_parent is not None:
                            if i_is_right:
                                i_parent.member_right = i_node
                            else:
                                i_parent.member_left = i_node
                        else:
                            self.member_root = i_node

                # -----------------------------------------------
                # End: Checking for right-left or other balance
                #      violations.
                # -----------------------------------------------

                return True, 1 + max(i_node.member_left_depth,
                                     i_node.member_right_depth)

        if i_key == i_node.member_key:
            print(f'\33[91mDuplicate key error {i_key}, '
                  f'{i_node.member_key}.\33[00m')

        return False, 0 # Duplicate key error.


    def function_delete(self, d_node: AVL_NODE_CLASS,
                        d_parent: TYPING_Union[AVL_NODE_CLASS, None],
                        d_is_right: bool,
                        d_key: TYPING_Union[int, None]) -> \
            (bool, int, int):

        if d_node is None:
            return False, 0, 0

        if d_key is not None:

            # ----------------------
            # Start: In search mode.
            # ----------------------

            if d_key > d_node.member_key:
                d_result, d_next_key, d_right_depth = \
                    self.function_delete(d_node.member_right, d_node,
                                         True, d_key)

                if d_result:
                    d_node.member_right_count -= 1
                    d_node.member_right_depth = d_right_depth

                    # -----------------------------------------------
                    # Start: Checking for left-right or other balance
                    #        violations.
                    # -----------------------------------------------

                    if d_node.member_left_depth >= \
                            d_node.member_right_depth + 2:
                        d_left = d_node.member_left
                        if d_left.member_left_depth < \
                                d_left.member_right_depth:

                            d_node = self.function_rotate_left_right(d_node)
                            if d_parent is not None:
                                if d_is_right:
                                    d_parent.member_right = d_node
                                else:
                                    d_parent.member_left = d_node
                            else:
                                self.member_root = d_node
                        else:
                            d_node = self.function_rotate_right(d_node)
                            if d_parent is not None:
                                if d_is_right:
                                    d_parent.member_right = d_node
                                else:
                                    d_parent.member_left = d_node
                            else:
                                self.member_root = d_node

                    # -----------------------------------------------
                    # End: Checking for left-right or other balance
                    #      violations.
                    # -----------------------------------------------

                return d_result, d_next_key, \
                    1 + max(d_node.member_left_depth,
                            d_node.member_right_depth)

            elif d_key < d_node.member_key:
                d_result, d_next_key, d_left_depth = \
                    self.function_delete(d_node.member_left, d_node, False,
                                         d_key)

                if d_result:
                    d_node.member_left_count -= 1
                    d_node.member_left_depth = d_left_depth

                    # ---------------------------------------------
                    # Start: Check for right-left and other balance
                    #        violations.
                    # ---------------------------------------------

                    if d_node.member_right_depth >= \
                            d_node.member_left_depth + 2:
                        d_right = d_node.member_right
                        if d_right.member_right_depth < \
                                d_right.member_left_depth:
                            d_node = self.function_rotate_right_left(d_node)
                            if d_parent is not None:
                                if d_is_right:
                                    d_parent.member_right = d_node
                                else:
                                    d_parent.member_left = d_node
                            else:
                                self.member_root = d_node
                        else:
                            d_node = self.function_rotate_left(d_node)

                            if d_parent is not None:
                                if d_is_right:
                                    d_parent.member_right = d_node
                                else:
                                    d_parent.member_left = d_node
                            else:
                                self.member_root = d_node

                    # ---------------------------------------------
                    # End: Check for right-left and other balance
                    #      violations.
                    # ---------------------------------------------

                return d_result, d_next_key, \
                    1 + max(d_node.member_left_depth,
                            d_node.member_right_depth)

            else: # Value was found.

                # **********************************************
                # Start: Value was found, initiate the deletion.
                # **********************************************

                if d_node.member_right is not None:
                    # ------------------------------------------------------
                    # Start: initiate the search for the leftest right leaf.
                    # ------------------------------------------------------
                    _, d_next_key, d_right_depth = \
                        self.function_delete(d_node.member_right, d_node,
                                             True, None)
                    d_node.member_key = d_next_key
                    d_node.member_right_count -= 1
                    d_node.member_right_depth = d_right_depth

                    # ---------------------------------------------
                    # Start: Check for left-right and other balance
                    #        violations.
                    # ---------------------------------------------

                    if d_node.member_left_depth >= \
                            d_node.member_right_depth + 2:
                        d_left = d_node.member_left
                        if d_left.member_left_depth < \
                                d_left.member_right_depth:

                            d_node = self.function_rotate_left_right(d_node)
                            if d_parent is not None:
                                if d_is_right:
                                    d_parent.member_right = d_node
                                else:
                                    d_parent.member_left = d_node
                            else:
                                self.member_root = d_node
                        else:
                            d_node = self.function_rotate_right(d_node)
                            if d_parent is not None:
                                if d_is_right:
                                    d_parent.member_right = d_node
                                else:
                                    d_parent.member_left = d_node
                            else:
                                self.member_root = d_node

                    # ---------------------------------------------
                    # End: Check for left-right and other balance
                    #      violations.
                    # ---------------------------------------------

                    return True, None, \
                           1 + max(d_node.member_left_depth,
                                   d_node.member_right_depth)

                    # ------------------------------------------------------
                    # End: initiate the search for the leftest right leaf.
                    # ------------------------------------------------------

                elif d_node.member_left is not None:

                    # -------------------------------------------
                    # Start: if the node has only a left branch,
                    #        replace the node by the left child.
                    # -------------------------------------------

                    d_left = d_node.member_left
                    d_node.member_left = d_left.member_left
                    d_node.member_left_count = d_left.member_left_count
                    d_node.member_left_depth = d_left.member_left_depth
                    d_node.member_right = d_left.member_right
                    d_node.member_right_count = d_left.member_right_count
                    d_node.member_right_depth = d_left.member_right_depth
                    d_node.member_key = d_left.member_key

                    del d_left

                    return True, None, 1 + max(d_node.member_left_depth,
                                               d_node.member_right_depth)

                    # -------------------------------------------
                    # End: if the node has only a left branch,
                    #      replace the node by the left child.
                    # -------------------------------------------

                elif d_parent is not None:
                    if d_is_right:
                        d_parent.member_right = None
                        # The parent will decrement this value upon
                        # return.
                        d_parent.member_right_count = 1
                        # Depth will be updated upon return.
                    else:
                        d_parent.member_left = None
                        # The parent will decrement this value upon
                        # return.
                        d_parent.member_lef_count = 1
                        # Depth will be updated upon return.
                    del d_node
                else:
                    # Do not remove the root. Simply update its value
                    # to None.
                    d_node.member_key = None

                return True, None, 0

                # **********************************************
                # End: Value was found, initiate the deletion.
                # **********************************************

            # ----------------------
            # End: In search mode.
            # ----------------------
        else: # d_key is None.

            # ----------------------------------------------------------
            # Start: delete leftest right leaf and bring its value back.
            # ----------------------------------------------------------

            if d_node.member_left is not None:
                _, d_next_key, d_left_depth = \
                    self.function_delete(d_node.member_left, d_node,
                                         False, None)
                d_node.member_left_count -= 1
                d_node.member_left_depth = d_left_depth

                # ---------------------------------------------------------
                # Start: Check for right-left and other balance violations.
                # ---------------------------------------------------------

                if d_node.member_right_depth >= \
                        d_node.member_left_depth + 2:
                    d_right = d_node.member_right
                    if d_right.member_right_depth < \
                            d_right.member_left_depth:
                        d_node = self.function_rotate_right_left(d_node)
                        if d_parent is not None:
                            if d_is_right:
                                d_parent.member_right = d_node
                            else:
                                d_parent.member_left = d_node
                        else:
                            self.member_root = d_node
                    else:
                        d_node = self.function_rotate_left(d_node)

                        if d_parent is not None:
                            if d_is_right:
                                d_parent.member_right = d_node
                            else:
                                d_parent.member_left = d_node
                        else:
                            self.member_root = d_node

                # ---------------------------------------------------------
                # End: Check for right-left and other balance violations.
                # ---------------------------------------------------------

                return True, d_next_key, 1 + max(d_node.member_left_depth,
                                                 d_node.member_right_depth)

            elif d_parent is not None:
                if d_is_right:
                    d_parent.member_right = d_node.member_right
                    # The addition of 1 is because upon return the
                    # count is decremented.
                    d_parent.member_right_count = \
                        d_node.member_right_count + 1

                    d_next_key = d_node.member_key
                    d_right_depth = d_node.member_right_depth
                    # Depth will be updated after returning from this
                    # call.

                    del d_node

                    # No addition of 1 to d_right_depth!
                    # The reason: d_node was removed.
                    return True, d_next_key, d_right_depth
                else:
                    d_parent.member_left = d_node.member_right
                    # The addition of 1 is because upon return the count
                    # is decremented.
                    d_parent.member_left_count = \
                        d_node.member_right_count + 1
                    d_next_key = d_node.member_key
                    d_right_depth = d_node.member_right_depth
                    # Depth will be updated after returning from this call.

                    del d_node
                    # No addition of 1 to d_right_depth!
                    # The reason: d_node was removed.
                    return True, d_next_key, d_right_depth

            # ----------------------------------------------------------
            # End: delete leftest right leaf and bring its value back.
            # ----------------------------------------------------------

        return False, 0, 0

    def function_get_count(self):
        gc_count = \
            self.member_root.member_left_count + \
            self.member_root.member_right_count
        if self.member_root.member_key is not None:
            gc_count += 1
        return gc_count

    def function_get_key_by_index(self,
                                  gkbi_node: AVL_NODE_CLASS,
                                  gkbi_index: int,
                                  gkbi_sum: int = 0) -> int:

        gkbi_current_count = gkbi_sum + gkbi_node.member_left_count

        if gkbi_index < gkbi_current_count:

            if gkbi_node.member_left is None:
                return gkbi_node.member_key

            return self.function_get_key_by_index(gkbi_node.member_left,
                                                  gkbi_index, gkbi_sum)

        elif gkbi_index == gkbi_current_count:
            return gkbi_node.member_key

        # Current node is added.
        gkbi_sum = gkbi_current_count + 1

        return self.function_get_key_by_index(gkbi_node.member_right,
                                              gkbi_index, gkbi_sum)

    def function_print(self, p_node: AVL_NODE_CLASS,
                       p_count: int = 0, p_depth = 0):
        if p_node is None:
            return p_count, True

        p_count, p_ok = self.function_print(p_node.member_left,
                                            p_count, p_depth + 1)

        if not p_ok:
            return p_count, False

        if abs(p_node.member_left_depth -
               p_node.member_right_depth) > 1:
            print(f'\33[91mNode({p_count}) = '
                  f'Depth {p_depth}, key {p_node.member_key}, left'
                  f' {p_node.member_left_count}, '
                  f'right {p_node.member_right_count}, left depth'
                  f' {p_node.member_left_depth}, '
                  f'right depth {p_node.member_right_depth}\33[00m')
            p_ok = False
        else:
            print(f'Node({p_count}) = '
                  f'Depth {p_depth}, key {p_node.member_key}, left'
                  f' {p_node.member_left_count}, '
                  f'right {p_node.member_right_count}, left depth'
                  f' {p_node.member_left_depth}, '
                  f'right depth {p_node.member_right_depth}')

        if not p_ok:
            return p_count, False

        p_count += 1
        p_count, p_ok = \
            self.function_print(p_node.member_right, p_count,
                                p_depth + 1)

        return p_count, p_ok


def main():
    for k in range(1000):
        ma_tree = AVL_TREE_CLASS()
        ma_test_list = []
        ma_n = 32

        for i in range(ma_n):

            ma_r = RANDOM.randint(0, 9999)

            if ma_tree.function_insert(ma_tree.member_root, None,
                                       False, ma_r)[0]:
                ma_test_list.append(ma_r)
                print(ma_r)
            else:
                ma_n -= 1

        ma_m = ma_n
        for _ in range(ma_n>>1):
            ma_r = ma_test_list.pop(RANDOM.randint(0, ma_m - 1))
            ma_m -= 1
            print(f'Removing {ma_r}')
            ma_tree.function_delete(ma_tree.member_root, None,
                                    False, ma_r)

        ma_count = ma_tree.function_get_count()

        for i in range(ma_count):
            ma_key = \
                ma_tree.function_get_key_by_index(ma_tree.member_root, i)
            print(f'Key ({i}) = {ma_key}')

        if not ma_tree.function_print(ma_tree.member_root)[1]:
            break

        if ma_count != ma_m:
            print(f'\33[92mCount error {ma_count}\33[00m')
            break


if __name__ == '__main__':
    main()

