
#Binary tree that supports an ordinal index.
# As an execise add three functions,
# 1) function_get_next for a key greater than an input argument.
# 2) function_get_previous for a key smaller than an input argument.
# 3) function_get_key for a key that has a matching ordinal index
#    to an input index or None.

from typing import Union as TYPING_Union
import random as RANDOM

class BINARY_INDEXED_NODE_CLASS:
    def __init__(self, i_key: TYPING_Union[int, None]):
        self.member_left = None
        self.member_right = None
        self.member_left_count = 0
        self.member_right_count = 0
        self.member_key = i_key

class BINARY_INDEXED_TREE_CLASS:

    def __init__(self):
        self.member_root = BINARY_INDEXED_NODE_CLASS(None)

    def function_insert(self, i_node: BINARY_INDEXED_NODE_CLASS,
                        i_parent:
                        TYPING_Union[BINARY_INDEXED_NODE_CLASS, None],
                        i_is_right: bool, i_key: int) -> bool:

        if i_node is None:
            i_node = BINARY_INDEXED_NODE_CLASS(i_key)
            if i_parent is not None:
                if i_is_right:
                    i_parent.member_right = i_node
                    # The parent counter will be incremented upon return.
                    i_parent.member_right_count = 0
                else:
                    i_parent.member_left = i_node
                    # The parent counter will be incremented upon return.
                    i_parent.member_left_count = 0
            return True

        # Root case.
        if i_node.member_key is None:
            i_node.member_key = i_key
            return True

        if i_key < i_node.member_key:

            i_ok = self.function_insert(i_node.member_left, i_node, False,
                                        i_key)

            if i_ok:
                i_node.member_left_count += 1

                return True

        elif i_key > i_node.member_key:
            i_ok = self.function_insert(i_node.member_right, i_node, True,
                                        i_key)

            if i_ok:
                i_node.member_right_count += 1

                return True

        if i_key == i_node.member_key:
            print(f'\33[91mDuplicate key error {i_key}, '
                  f'{i_node.member_key}.\33[00m')

        return False # Duplicate key error.


    def function_delete(self, d_node: BINARY_INDEXED_NODE_CLASS,
                        d_parent:
                        TYPING_Union[BINARY_INDEXED_NODE_CLASS, None],
                        d_is_right: bool,
                        d_key: TYPING_Union[int, None]) -> (bool, int, int):

        if d_node is None:
            return False, 0

        if d_key is not None:

            # ----------------------
            # Start: In search mode.
            # ----------------------

            if d_key > d_node.member_key:
                d_result, d_next_key = \
                    self.function_delete(d_node.member_right, d_node, True,
                                         d_key)

                if d_result:
                    d_node.member_right_count -= 1

                return d_result, d_next_key

            elif d_key < d_node.member_key:
                d_result, d_next_key = \
                    self.function_delete(d_node.member_left, d_node, False,
                                         d_key)

                if d_result:
                    d_node.member_left_count -= 1

                return d_result, d_next_key

            else: # Value was found.

                # **********************************************
                # Start: Value was found, initiate the deletion.
                # **********************************************

                if d_node.member_right is not None:
                    # ------------------------------------------------------
                    # Start: initiate the search for the leftest right leaf.
                    # ------------------------------------------------------
                    _, d_next_key = \
                        self.function_delete(d_node.member_right, d_node,
                                             True, None)
                    
                    d_node.member_key = d_next_key
                    d_node.member_right_count -= 1

                    return True, None

                    # ------------------------------------------------------
                    # End: initiate the search for the leftest right leaf.
                    # ------------------------------------------------------

                elif d_node.member_left is not None:

                    # -------------------------------------------
                    # Start: if the node has only a left branch,
                    #        replace the node by the left child.
                    # -------------------------------------------

                    d_left = d_node.member_left
                    d_node.member_left = d_left.member_left
                    d_node.member_left_count = d_left.member_left_count
                    d_node.member_right = d_left.member_right
                    d_node.member_right_count = d_left.member_right_count
                    d_node.member_key = d_left.member_key

                    del d_left

                    return True, None

                    # -------------------------------------------
                    # End: if the node has only a left branch,
                    #      replace the node by the left child.
                    # -------------------------------------------

                elif d_parent is not None:
                    if d_is_right:
                        d_parent.member_right = None
                        # The parent will decrement this value upon return.
                        d_parent.member_right_count = 1
                    else:
                        d_parent.member_left = None
                        # The parent will decrement this value upon return.
                        d_parent.member_lef_count = 1
                    del d_node
                else:
                    # Do not remove the root. Simply update its value to
                    # None.
                    d_node.member_key = None

                return True, None

                # **********************************************
                # End: Value was found, initiate the deletion.
                # **********************************************

            # ----------------------
            # End: In search mode.
            # ----------------------
        else: # d_key is None.

            # ----------------------------------------------------------
            # Start: delete leftest right leaf and bring its value back.
            # ----------------------------------------------------------

            if d_node.member_left is not None:
                _, d_next_key = \
                    self.function_delete(d_node.member_left, d_node,
                                         False, None)
                d_node.member_left_count -= 1

                return True, d_next_key

            elif d_parent is not None:
                if d_is_right:
                    d_parent.member_right = d_node.member_right
                    # The addition of 1 is because upon return the count is
                    # decremented.
                    d_parent.member_right_count = \
                        d_node.member_right_count + 1

                    d_next_key = d_node.member_key

                    del d_node

                    return True, d_next_key
                else:
                    d_parent.member_left = d_node.member_right
                    # The addition of 1 is because upon return the count
                    # is decremented.
                    d_parent.member_left_count = \
                        d_node.member_right_count + 1
                    d_next_key = d_node.member_key

                    del d_node

                    return True, d_next_key

            # ----------------------------------------------------------
            # End: delete leftest right leaf and bring its value back.
            # ----------------------------------------------------------

        return False, 0

    def function_get_count(self):
        gc_count = \
            self.member_root.member_left_count + \
            self.member_root.member_right_count
        if self.member_root.member_key is not None:
            gc_count += 1
        return gc_count

    def function_get_key_by_index(self,
                                  gkbi_node: BINARY_INDEXED_NODE_CLASS,
                                  gkbi_index: int,
                                  gkbi_sum: int = 0) -> int:

        gkbi_current_count = gkbi_sum + gkbi_node.member_left_count

        if gkbi_index < gkbi_current_count:

            if gkbi_node.member_left is None:
                return gkbi_node.member_key

            return self.function_get_key_by_index(gkbi_node.member_left,
                                                  gkbi_index, gkbi_sum)

        elif gkbi_index == gkbi_current_count:
            return gkbi_node.member_key

        # Current node is added.
        gkbi_sum = gkbi_current_count + 1

        return self.function_get_key_by_index(gkbi_node.member_right,
                                              gkbi_index, gkbi_sum)

    def function_print(self, p_node: BINARY_INDEXED_NODE_CLASS,
                       p_count: int = 0, p_depth = 0):
        if p_node is None:
            return p_count, True

        p_count, p_ok = self.function_print(p_node.member_left,
                                            p_count, p_depth + 1)

        if not p_ok:
            return p_count, False

        print(f'Node({p_count}) = '
              f'Depth {p_depth}, key {p_node.member_key}, '
              f'left {p_node.member_left_count}, '
              f'right {p_node.member_right_count}')

        if not p_ok:
            return p_count, False

        p_count += 1
        p_count, p_ok = \
            self.function_print(p_node.member_right, p_count, p_depth + 1)

        return p_count, p_ok


def main():
    for k in range(1000):
        ma_tree = BINARY_INDEXED_TREE_CLASS()
        ma_test_list = []
        ma_n = 32

        for i in range(ma_n):

            ma_r = RANDOM.randint(0, 9999)

            if ma_tree.function_insert(ma_tree.member_root, None,
                                       False, ma_r):
                ma_test_list.append(ma_r)
                print(ma_r)
            else:
                ma_n -= 1

        ma_m = ma_n
        for _ in range(ma_n>>1):
            ma_r = ma_test_list.pop(RANDOM.randint(0, ma_m - 1))
            ma_m -= 1
            print(f'Removing {ma_r}')
            ma_tree.function_delete(ma_tree.member_root, None,
                                    False, ma_r)

        ma_count = ma_tree.function_get_count()

        for i in range(ma_count):
            ma_key = \
                ma_tree.function_get_key_by_index(ma_tree.member_root, i)
            print(f'Key ({i}) = {ma_key}')

        if not ma_tree.function_print(ma_tree.member_root)[1]:
            break

        if ma_count != ma_m:
            print(f'\33[92mCount error {ma_count}\33[00m')
            break


if __name__ == '__main__':
    main()

