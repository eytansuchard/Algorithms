# Binary tree.
# The tree is a toy tree.

from typing import Union as TYPING_Union
import random as RANDOM

class BINARY_NODE_CLASS:
    def __init__(self, i_key: TYPING_Union[int, None]):
        self.member_left = None
        self.member_right = None
        self.member_key = i_key

class AVL_TREE_CLASS:

    def __init__(self):
        self.member_root = BINARY_NODE_CLASS(None)

    def function_insert(self, i_node: BINARY_NODE_CLASS,
                        i_parent: TYPING_Union[BINARY_NODE_CLASS, None],
                        i_is_right: bool, i_key: int) -> bool:

        if i_node is None:
            i_node = BINARY_NODE_CLASS(i_key)
            if i_parent is not None:
                if i_is_right:
                    i_parent.member_right = i_node
                else:
                    i_parent.member_left = i_node
            return True

        # Root case.
        if i_node.member_key is None:
            i_node.member_key = i_key
            return True

        if i_key < i_node.member_key:
            return self.function_insert(i_node.member_left, i_node, False,
                                        i_key)

        elif i_key > i_node.member_key:
            return self.function_insert(i_node.member_right, i_node, True,
                                        i_key)

        if i_key == i_node.member_key:
            print(f'\33[91mDuplicate key error {i_key}, '
                  f'{i_node.member_key}.\33[00m')

        return False # Duplicate key error.


    def function_delete(self, d_node: BINARY_NODE_CLASS,
                        d_parent: TYPING_Union[BINARY_NODE_CLASS, None],
                        d_is_right: bool,
                        d_key: TYPING_Union[int, None]) -> (bool, int):

        if d_node is None:
            return False

        if d_key is not None:

            # ----------------------
            # Start: In search mode.
            # ----------------------

            if d_key > d_node.member_key:
                d_result, d_next_key  = \
                    self.function_delete(d_node.member_right, d_node, True,
                                         d_key)

                return d_result, d_next_key

            elif d_key < d_node.member_key:
                d_result, d_next_key = \
                    self.function_delete(d_node.member_left, d_node, False,
                                         d_key)

                return d_result, d_next_key

            else: # Value was found.

                # **********************************************
                # Start: Value was found, initiate the deletion.
                # **********************************************

                if d_node.member_right is not None:
                    # ------------------------------------------------------
                    # Start: initiate the search for the leftest right leaf.
                    # ------------------------------------------------------
                    _, d_next_key = \
                        self.function_delete(d_node.member_right, d_node,
                                             True,
                                             None)
                    d_node.member_key = d_next_key

                    return True, None

                    # ------------------------------------------------------
                    # End: initiate the search for the leftest right leaf.
                    # ------------------------------------------------------

                elif d_node.member_left is not None:

                    # -------------------------------------------
                    # Start: if the node has only a left branch,
                    #        replace the node by the left child.
                    # -------------------------------------------

                    d_left = d_node.member_left
                    d_node.member_left = d_left.member_left
                    d_node.member_right = d_left.member_right
                    d_node.member_key = d_left.member_key

                    del d_left

                    return True, None

                    # -------------------------------------------
                    # End: if the node has only a left branch,
                    #      replace the node by the left child.
                    # -------------------------------------------

                elif d_parent is not None:
                    if d_is_right:
                        d_parent.member_right = None
                    else:
                        d_parent.member_left = None
                    del d_node
                else:
                    # Do not remove the root. Simply update its value to
                    # None.
                    d_node.member_key = None

                return True, None

                # **********************************************
                # End: Value was found, initiate the deletion.
                # **********************************************

            # ----------------------
            # End: In search mode.
            # ----------------------
        else: # d_key is None.

            # ----------------------------------------------------------
            # Start: delete leftest right leaf and bring its value back.
            # ----------------------------------------------------------

            if d_node.member_left is not None:
                _, d_next_key = \
                    self.function_delete(d_node.member_left, d_node, False,
                                         None)

                return True, d_next_key

            elif d_parent is not None:
                if d_is_right:
                    d_parent.member_right = d_node.member_right

                    d_next_key = d_node.member_key

                    del d_node

                    return True, d_next_key
                else:
                    d_parent.member_left = d_node.member_right
                    d_next_key = d_node.member_key

                    del d_node

                    return True, d_next_key

            # ----------------------------------------------------------
            # End: delete leftest right leaf and bring its value back.
            # ----------------------------------------------------------

        return False, 0


    def function_get_previous(self, p_node: BINARY_NODE_CLASS,
                              p_val: int) -> \
            TYPING_Union[int, None]:

        if p_node is None:
            return None

        if p_val > p_node.member_key:
            p_next = self.function_get_previous(p_node.member_right, p_val)

            if p_next is not None:
                if p_next < p_val:
                    # There is a greater value than p_node.member_key
                    # which is still smaller than p_val.
                    return p_next

            # There is no greater value than p_node.member_key which
            # is still smaller than p_val.
            return p_node.member_key

        elif p_val <= p_node.member_key:
            return self.function_get_previous(p_node.member_left, p_val)


    def function_print(self, p_node: BINARY_NODE_CLASS, p_count: int = 0,
                       p_depth = 0) -> \
            (int, bool):

        if p_node is None:
            return p_count, True

        p_count, p_ok = self.function_print(p_node.member_left, p_count,
                                            p_depth + 1)

        if not p_ok:
            return p_count, False

        print(f'Node({p_count}) = '
              f'depth {p_depth}, key {p_node.member_key}')

        if not p_ok:
            return p_count, False

        p_count += 1
        p_count, p_ok = \
            self.function_print(p_node.member_right, p_count, p_depth + 1)

        return p_count, p_ok


def main():
    for k in range(1000):
        ma_tree = AVL_TREE_CLASS()
        ma_test_list = []
        ma_n = 32

        for i in range(ma_n):

            ma_r = RANDOM.randint(0, 9999)

            if ma_tree.function_insert(ma_tree.member_root, None,
                                       False, ma_r):
                ma_test_list.append(ma_r)
                print(ma_r)
            else:
                ma_n -= 1

        ma_m = ma_n
        for _ in range(ma_n>>1):
            ma_r = ma_test_list.pop(RANDOM.randint(0, ma_m - 1))
            ma_m -= 1
            print(f'Removing {ma_r}')
            ma_tree.function_delete(ma_tree.member_root, None, False, ma_r)

        ma_count, ma_ok = ma_tree.function_print(ma_tree.member_root)

        if not ma_ok:
            break

        if ma_count != ma_m:
            print(f'\33[92mCount error {ma_count}\33[00m')
            break

        ma_prev = RANDOM.randint(0, 9999)
        ma_fount_prev = \
            ma_tree.function_get_previous(ma_tree.member_root, ma_prev)

        print(f'Get previous {ma_prev}, {ma_fount_prev}')

        ma_prev = ma_tree.function_get_previous(ma_tree.member_root,
                                                100)
        if ma_prev is not None:
            ma_ret = \
                ma_tree.function_get_previous(ma_tree.member_root, 100)
            print(f'Get previous 100 '
                  f'{ma_ret}')
            break


if __name__ == '__main__':
    main()
