class GREEDY_SQUARES_CLASS:
    def __init__(self, i_n: int, i_m: int):

        print(f'N = {self.function_solve(i_n, i_m)}')

    def function_solve(self, s_n, s_m):

        if s_n < 1 or s_m < 1:
            return 0

        s_min = min(s_n, s_m)

        print(f'Square edge {s_min}')

        if s_min == s_n:
            s_r = self.function_solve(s_n, s_m - s_n)
        else:
            s_r = self.function_solve(s_n - s_m, s_m)

        return s_r + 1

def main():
    ma_squares = GREEDY_SQUARES_CLASS(9, 8)

if __name__ == '__main__':
    main()
