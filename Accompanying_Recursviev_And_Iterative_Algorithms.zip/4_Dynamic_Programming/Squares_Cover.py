import numpy as NP

class DYNAMIC_PROGRAMMING_SQUARES_CLASS:
    def __init__(self, i_n: int, i_m: int):
        i_n += 1
        i_m += 1
        self.member_n = i_n
        self.member_m = i_m
        self.member_matrix = -NP.ones((i_n, i_m), dtype=NP.int32)
        self.member_squares = NP.zeros((i_n, i_m), dtype=NP.int32)
        self.member_subs = NP.zeros((i_n, i_m, 2, 2), dtype=NP.int32)
        i_n -= 1
        i_m -= 1

        self.member_best = self.function_solve(i_n, i_m)
        self.function_print(i_n, i_m)
        print(f'N = {self.member_best}')

    def function_print(self, p_n, p_m):

        if 0 == p_n or 0 == p_m:
            return

        # Remove unnecessary symmetries.
        if p_m > p_n:
            p_n, p_m = p_m, p_n

        print(f'Square edge: {self.member_squares[p_n, p_m]}')

        p_next_n, p_next_m = \
            self.member_subs[p_n, p_m, 0, 0], \
                self.member_subs[p_n, p_m, 0, 1]

        self.function_print(p_next_n, p_next_m)

        p_next_n, p_next_m = \
            self.member_subs[p_n, p_m, 1, 0], \
                self.member_subs[p_n, p_m, 1, 1]

        self.function_print(p_next_n, p_next_m)


    def function_solve(self, s_n, s_m):

        if s_n < 1 or s_m < 1:
            return 0

        # Remove unnecessary symmetries.
        if s_m > s_n:
            s_n, s_m = s_m, s_n

        s_entry = self.member_matrix[s_n, s_m]

        if s_entry >= 0:
            return s_entry

        s_min = min(s_n, s_m)
        s_best = None
        s_subs = ((0, 0), (0, 0))
        s_best_i = 0

        for i in range(1, s_min + 1):
            # Recursive option B when s_n is the width.
            s_r1 = \
                self.function_solve(s_n - i, s_m) + \
                self.function_solve(i, s_m - i)
            # Recursive option A when s_n is the width.
            s_r2 = \
                self.function_solve(s_n, s_m - i) + \
                self.function_solve(s_n - i, i)

            if s_r1 < s_r2:
                if s_best is None:
                    s_best_i = i
                    s_best = s_r1
                    s_subs = ((s_n - i, s_m), (i, s_m - i))
                elif s_best > s_r1:
                    s_best_i = i
                    s_best = s_r1
                    s_subs = ((s_n - i, s_m), (i, s_m - i))
            else:
                if s_best is None:
                    s_best_i = i
                    s_best = s_r2
                    s_subs = ((s_n, s_m - i), (s_n - i, i))
                elif s_best > s_r2:
                    s_best_i = i
                    s_best = s_r2
                    s_subs = ((s_n, s_m - i), (s_n - i, i))

        if s_best is None:
            s_best = 1
        else:
            s_best += 1

        self.member_matrix[s_n, s_m] = s_best
        self.member_subs[s_n, s_m, :, :] = s_subs
        self.member_squares[s_n, s_m] = s_best_i

        return s_best

def main():
    ma_squares = DYNAMIC_PROGRAMMING_SQUARES_CLASS(9, 8)

if __name__ == '__main__':
    main()
