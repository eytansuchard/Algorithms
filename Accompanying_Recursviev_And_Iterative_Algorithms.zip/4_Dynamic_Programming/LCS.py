# **********************
# Longest common string.
# **********************

import numpy as NP

class LCS_CLASS:

    def __init__(self, i_str1, i_str2):

        self.member_str1 = i_str1
        self.member_str2 = i_str2
        self.member_len1 = len(i_str1)
        self.member_len2 = len(i_str2)

        self.member_grade_matrix = \
            -NP.ones((self.member_len1, self.member_len2),
                     dtype=NP.int32)

        self.member_next2 = - NP.ones((self.member_len1,
                                       self.member_len2),
                                      dtype=NP.int32)

        self.member_result = self.function_calculate_lcs()

        self.function_find_lcs()


    def function_calculate_lcs(self, cl_idx1: int = 0, cl_idx2: int = 0):

        if cl_idx1 >= self.member_len1:
            return 0

        if cl_idx2 >= self.member_len2:
            return 0

        if self.member_grade_matrix[cl_idx1, cl_idx2] > -1:
            return self.member_grade_matrix[cl_idx1, cl_idx2]

        # Start: For cl_idx1 in self.member_str1 find where the best
        #        matching the index of the next best matching subsequence
        #        in self.member_str2.

        cl_max = 0
        cl_next = -1

        for k in range(cl_idx2, self.member_len2):
            if self.member_str1[cl_idx1] == self.member_str2[k]:
                cl_r = 1
                cl_r += self.function_calculate_lcs(cl_idx1 + 1, k + 1)
            else:
                cl_r = 0
                cl_r += self.function_calculate_lcs(cl_idx1 + 1, k)

            if cl_max < cl_r:
                cl_max = cl_r
                cl_next = k

        self.member_next2[cl_idx1, cl_idx2] = cl_next
        self.member_grade_matrix[cl_idx1, cl_idx2] = cl_max

        # End: For cl_idx1 in self.member_str1 find where the best
        #      matching the index of the next best matching subsequence
        #      in self.member_str2.

        return cl_max


    def function_find_lcs(self):

        fl_best_str = ''

        fl_next = 0

        for i in range(self.member_len1):

            fl_next = self.member_next2[i, fl_next]

            if fl_next < 0:
                # No string found.
                break

            if self.member_str1[i] == self.member_str2[fl_next]:
                fl_best_str += self.member_str1[i]
                fl_next += 1

        # print(f'Found LCS: {fl_str}')

        return fl_best_str


def main():

    ma_str1 = 'abdbcwd'
    ma_str2 = 'k a s b s b c s d'

    ma_lcs = LCS_CLASS(ma_str1, ma_str2)
    print(f'LCS({ma_str1}, {ma_str2}) = {ma_lcs.member_result}')
    print(f'Found example: {ma_lcs.function_find_lcs()}')

    ma_str1 = 'xlywitvbebwaqeistmylhbqhfdfaxxseif' \
              'tuhraosnardlelwdihgeanvitsyaw!'
    ma_str2 = 'zqhlarbicavcecwzrfiutopporhwfzalmnb' \
              'miqtwehvawuknmsbdjjzdoiogizneiteyoxd'

    ma_lcs = LCS_CLASS(ma_str1, ma_str2)
    print(f'LCS({ma_str1}, {ma_str2}) = {ma_lcs.member_result}')
    print(f'Found example: {ma_lcs.function_find_lcs()}')

if __name__ == '__main__':
    main()