import numpy as NP
import pandas as PD
from typing import Union as TYPING_Union
from sklearn.utils import resample as SKLEARN_RESAMPLE
from XGBoost_Wrapper import XGBOOST_CLASS

class REGRESSION_TREE_NODE:
    def __init__(self, i_dim: int, i_depth: int,
                 i_min_n_for_split: int = 2,
                 i_overcomplete_basis_n_threshold: int = 256,
                 # Lower threshold is sometimes better for classes.
                 i_overcomplete_basis_is_threshold_lower: bool = True,
                 i_min_eigenvalue_ratio: float = 0.005,
                 # 1 is for discrete labels.
                 i_min_std_per_split: float = 0.2,
                 # range is usually worse than summation,
                 # but not in all regression problems.
                 i_range_instead_of_projection_sum: bool = False):

        if i_dim < 2 or i_dim > 1000 or \
                i_depth < 1 or i_depth > 32:
            self.member_dim = 0
            self.member_max_depth = 0
            return

        self.member_avg_x = NP.zeros(i_dim, dtype=NP.float64)
        # Kept for future applications.
        self.member_covariance_matrix = \
            NP.zeros((i_dim, i_dim), dtype=NP.float64)
        self.member_w = NP.zeros(i_dim, dtype=NP.float64)

        self.member_dim = i_dim
        self.member_max_depth = i_depth
        # Kept for future applications.
        self.member_n = 0
        self.member_avg_y = NP.float64(0.0)
        self.member_std_y = NP.float64(0.0)
        self.member_min_n_for_split = i_min_n_for_split
        self.member_overcomplete_basis_n_threshold = \
            i_overcomplete_basis_n_threshold

        self.member_overcomplete_basis_is_threshold_lower = \
            i_overcomplete_basis_is_threshold_lower

        self.member_min_eigenvalue_ratio = i_min_eigenvalue_ratio
        self.member_min_std_per_split = i_min_std_per_split
        self.member_range_instead_of_projection_sum = \
            i_range_instead_of_projection_sum
        self.member_left = None
        self.member_right = None

    # Reserved for trimming.
    def function_destroy(self):
        if self.member_left is not None:
            self.member_left.function_destroy()
            del self.member_left # Will be done by the Garbage Disposal.
            self.member_left = None

        if self.member_right is not None:
            self.member_right.function_destroy()
            del self.member_right # Will be done by the Garbage Disposal.
            self.member_right = None

    def function_fit(self, f_in_x: NP.ndarray[NP.float64],
                     f_in_y: NP.ndarray[NP.float64],
                     f_depth: int = 0) -> \
            TYPING_Union[None, NP.ndarray[NP.float64]]:

        if f_in_x.ndim != 2:
            print("\33[91mERROR: x is not two dimensional.\33[00m")
            return None

        if f_in_x.shape[0] < 1:
            return None

        self.member_avg_y = NP.mean(f_in_y)
        self.member_std_y = NP.std(f_in_y)
        self.member_avg_x = NP.mean(f_in_x, axis=0)
        self.member_n = f_in_x.shape[0]

        f_results = NP.empty(f_in_x.shape[0], dtype=NP.float64)
        f_results[:] = self.member_avg_y

        if f_in_x.shape[0] < self.member_min_n_for_split:
            return f_results

        f_y = f_in_y - self.member_avg_y
        f_x = f_in_x - self.member_avg_x

        # -------------------------------------------------
        # Start, choose the best y-splitting x eigenvector.
        # -------------------------------------------------

        self.member_covariance_matrix = \
            f_x.T @ f_x / f_x.shape[0]

        f_eigenvalues, f_eigenvectors = \
            NP.linalg.eig(self.member_covariance_matrix)
        # Sort and then order from big to small instead of
        # small to big.
        f_sorted_idx = \
            NP.argsort(f_eigenvalues, kind='mergesort')[::-1]
        f_eigenvalues, f_eigenvectors = \
            f_eigenvalues[f_sorted_idx], \
                f_eigenvectors[:, f_sorted_idx]

        # Mask not allowing eigenvectors with too small eigenvalues.
        f_mask = \
            f_eigenvalues > (f_eigenvalues[0] *
                             self.member_min_eigenvalue_ratio)

        if self.member_overcomplete_basis_is_threshold_lower:
            if f_in_x.shape[0] > \
                    self.member_overcomplete_basis_n_threshold:
                f_canonical_basis = NP.eye(self.member_dim, dtype=NP.float64)
                f_candidate_vectors = \
                    NP.hstack((f_eigenvectors[:, f_mask], f_canonical_basis))
            else:
                f_candidate_vectors = f_eigenvectors[:, f_mask]
        else:
            if f_in_x.shape[0] < \
                    self.member_overcomplete_basis_n_threshold:
                f_canonical_basis = NP.eye(self.member_dim, dtype=NP.float64)
                f_candidate_vectors = \
                    NP.hstack((f_eigenvectors[:, f_mask], f_canonical_basis))
            else:
                f_candidate_vectors = f_eigenvectors[:, f_mask]

        # Broadcasting on dimension with sample index.
        f_sample_norms = NP.clip(NP.linalg.norm(f_x, axis=1),
                                 a_min=0.000000000001, a_max=None)

        # w = (x - average_x) * (y - average_y) / Norm(x - average_x)
        # varies well along direction where one side has positive
        # delta_y = y - average_y and one side has negative delta_y.
        # We need to project the w vectors on the eigenvectors and
        # see which one splits the space best.
        # Alternatively, we can take a convex function f of
        # the norm of x - average_x if we do want also the geometry
        # of x to help.
        # w = (x - average_x) * (y - average_y) / Covex(x - average_x)

        f_weighted_samples = (f_x.T * f_y / f_sample_norms).T

        if self.member_range_instead_of_projection_sum:
            f_weights = \
                NP.abs(NP.ptp(f_weighted_samples @ f_candidate_vectors,
                              axis=0))
        else:
            f_weights = \
                NP.abs((f_weighted_samples @ f_candidate_vectors).
                       sum(axis=0))

        if f_weights.shape[0] == 0:
            return f_results

        f_best_idx = f_weights.argmax()
        # self.member_w  is the splitting vector.
        self.member_w = f_candidate_vectors[:, f_best_idx]

        # -------------------------------------------------
        # End, choose the best y-splitting x eigenvector.
        # -------------------------------------------------

        if f_depth < self.member_max_depth and \
                self.member_std_y > self.member_min_std_per_split:

            # -------------------------
            # Start, split the samples.
            # -------------------------

            f_mask = (f_x @ self.member_w) > 0
            f_not = NP.logical_not(f_mask)
            f_positive_samples_x = f_x[f_mask, :]
            f_positive_samples_y = f_y[f_mask]
            f_negative_samples_x = f_x[f_not, :]
            f_negative_samples_y = f_y[f_not]

            # -------------------------
            # End, split the samples.
            # -------------------------

            if f_positive_samples_x.shape[0] > 0:
                if self.member_right is None:
                    self.member_right = \
                        REGRESSION_TREE_NODE(self.member_dim,
                                             self.member_max_depth)
                f_results[f_mask] += \
                    self.member_right. \
                        function_fit(f_positive_samples_x,
                                      f_positive_samples_y, f_depth+1)

            if f_negative_samples_x.shape[0] > 0:
                if self.member_left is None:
                    self.member_left = \
                        REGRESSION_TREE_NODE(self.member_dim,
                                             self.member_max_depth)
                f_results[f_not] += \
                    self.member_left. \
                        function_fit(f_negative_samples_x,
                                      f_negative_samples_y, f_depth+1)

        return f_results

    def function_predict(self, p_in_x: NP.ndarray[NP.float64],
                         p_depth: int = 0) -> \
            TYPING_Union[None, NP.ndarray[NP.float64]]:

        if p_in_x.ndim != 2:
            print("\33[91mERROR: x is not two dimensional.\33[00m")
            return None

        if p_in_x.shape[0] < 1:
            return None

        p_results = NP.empty(p_in_x.shape[0], dtype=NP.float64)
        p_results[:] = self.member_avg_y

        if p_in_x.shape[0] < self.member_min_n_for_split:
            return p_results

        p_x = p_in_x - self.member_avg_x

        if p_depth < self.member_max_depth:

            # -------------------------
            # Start, split the samples.
            # -------------------------

            p_mask = (p_x @ self.member_w) > 0
            p_not = NP.logical_not(p_mask)

            p_positive_samples_x = p_x[p_mask, :]
            p_negative_samples_x = p_x[p_not, :]

            # -------------------------
            # End, split the samples.
            # -------------------------

            if p_positive_samples_x.shape[0] > 0:
                if self.member_right is not None:

                    p_results[p_mask] += \
                        self.member_right. \
                            function_predict(p_positive_samples_x,
                                             p_depth + 1)

            if p_negative_samples_x.shape[0] > 0:
                if self.member_left is not None:
                    p_results[p_not] += \
                        self.member_left. \
                            function_predict(p_negative_samples_x,
                                             p_depth + 1)

        return p_results

class REGRESSION_TREE:
    def __init__(self, i_dim: int, i_depth: int):

        if i_dim < 2 or i_dim > 1000 or i_depth < 1 or i_depth > 32:

            if i_dim < 2 or i_dim > 1000:
                print('\33[91mInitialization error. '
                      'The dimension must be'
                      ' between 2 and 1000 inclusive.\33[00m')

            if i_depth < 1 or i_depth > 32:
                print('\33[91mError, tree depth is between 1 '
                      'and 32 inclusive.\33[00m')

            self.member_root = None
            self.member_dim = 0
            self.member_max_depth = 0

            return

        self.member_dim = i_dim
        self.member_max_depth = i_depth
        self.member_root = REGRESSION_TREE_NODE(i_dim, i_depth)

    def function_fit(self, f_in_x: NP.ndarray[NP.float64],
                     f_in_y: NP.ndarray[NP.float64]) -> \
            TYPING_Union[None, NP.ndarray[NP.float64]]:

        if self.member_root is None:
            return None

        return self.member_root.function_fit(f_in_x, f_in_y)


    def function_predict(self, p_in_x: NP.ndarray[NP.float64]) -> \
            TYPING_Union[None, NP.ndarray[NP.float64]]:

        if self.member_root is None:
            return None

        return self.member_root.function_predict(p_in_x)

class REGRESSION_TREE_FOREST:
    def __init__(self, i_dim : int, i_depth: int = 9, i_n_trees:int = 10,
                 i_alpha: float=0.5):

        if i_dim < 2 or i_dim > 1000 or i_depth < 1 or i_depth > 32 or \
                i_n_trees < 1 or i_n_trees > 50:

            if i_depth < 1 or i_depth > 32:
                print('\33[91mError, tree depth is between 1 '
                      'and 32 inclusive.\33[00m')

            if i_dim < 2 or i_dim > 1000:
                print('\33[91mError, dimension is between 2 '
                      'and 1000 inclusive.\33[00m')

            if i_n_trees < 1 or i_n_trees > 50:
                print('\33[91mError, number of trees is between 1 '
                      'and 50 inclusive.\33[00m')

            self.member_dim = 0
            self.member_n_trees = 0
            self.member_max_depth = 0
            return

        self.member_n_trees = i_n_trees
        self.member_dim = i_dim
        self.member_max_depth = i_depth
        self.member_alpha = NP.float64(i_alpha)

        i_tree_list = []

        for i in range(i_n_trees):
            i_tree_list.append(REGRESSION_TREE(i_dim, i_depth))

        self.member_trees = NP.array(i_tree_list)


    def function_fit(self, f_in_x: NP.ndarray[NP.float64],
                     f_in_y: NP.ndarray[NP.float64]) -> \
            TYPING_Union[None, NP.ndarray[NP.float64]]:

        f_y = f_in_y.copy()

        f_sum_r = NP.zeros(f_in_x.shape[0], dtype=NP.float64)

        for i in range(self.member_n_trees):
            f_r = self.member_alpha * \
                  self.member_trees[i].function_fit(f_in_x, f_y)
            f_sum_r += f_r
            f_y -= f_r

        return f_sum_r

    def function_predict(self, p_in_x: NP.ndarray[NP.float64]) ->\
            TYPING_Union[None, NP.ndarray[NP.float64]]:

        p_sum_r = NP.zeros(p_in_x.shape[0], dtype=NP.float64)

        for i in range(self.member_n_trees):
            p_r = self.member_alpha *\
                  self.member_trees[i].function_predict(p_in_x)
            p_sum_r += p_r

        return p_sum_r


def function_str_col_to_numbers(sctn_df: PD.DataFrame, sctn_col_name: str,
                                sctn_default_as_zero:
                                TYPING_Union[str, None] = None) -> None:

    if sctn_default_as_zero is not None:
        sctn_mapping = {sctn_default_as_zero: 0}
        sctn_count = 1

        for sctn_value in sctn_df[sctn_col_name].unique():
            sctn_r = sctn_mapping.get(sctn_value, -1)
            if sctn_r == -1:
                sctn_mapping[sctn_value] = sctn_count
                sctn_count += 1
    else:
        sctn_mapping = \
            {value: i for i, value in
             enumerate(sctn_df[sctn_col_name].unique())}

    sctn_df[sctn_col_name] = sctn_df[sctn_col_name].map(sctn_mapping)

def function_load_maintenance_table(lmt_file_name:
                                    str = "predictive_maintenance.csv",
                                    lmt_training_portion: float=0.9) -> \
        (TYPING_Union[None, NP.ndarray], TYPING_Union[None, NP.ndarray]):
    # Load Kaggle dataset. Public but requires proper mentioning.
    try:
        lmt_df = PD.read_csv(lmt_file_name)
    except Exception as lmt_ex:
        lmt_df = None, None
        print(lmt_ex)

    if lmt_df is None:
        print(f'\33[31mERROR: Could not load {lmt_file_name}\33[00m')
        return None, None

    # --------------------------------
    # Start: Mapping words to numbers.
    # --------------------------------
    function_str_col_to_numbers(lmt_df, 'Type')
    function_str_col_to_numbers(lmt_df, 'Failure Type',
                                sctn_default_as_zero='No Failure')
    # --------------------------------
    # End: Mapping words to numbers.
    # --------------------------------

    lmt_failure_col_name = 'Failure Type'

    lmt_df = lmt_df.drop(columns=['UDI', 'Product ID', 'Target'])

    lmt_df_train = lmt_df.sample(frac=lmt_training_portion, random_state=42)
    lmt_df_test = lmt_df.drop(lmt_df_train.index)

    # ------------------------------------------
    # Start, balance the classes by up-sampling.
    # ------------------------------------------

    lmt_class_count_series = \
        lmt_df_train[lmt_failure_col_name].value_counts()
    lmt_majority_class = lmt_class_count_series.idxmax()
    lmt_max = lmt_class_count_series.max()
    lmt_class_count_list = list(lmt_class_count_series.items())
    lmt_threshold = max(1, lmt_max // 3)
    lmt_upsampled_df_list = \
        [lmt_df_train[lmt_df_train[lmt_failure_col_name] ==
                      lmt_majority_class]]

    for lmt_idx, lmt_count in lmt_class_count_list:
        if lmt_idx != lmt_majority_class and lmt_count < lmt_threshold:
            lmt_df_minority = \
                lmt_df_train[lmt_df_train[lmt_failure_col_name] == lmt_idx]
            if len(lmt_df_minority) > 0:
                lmt_df_minority_upsampled = \
                    SKLEARN_RESAMPLE(lmt_df_minority,
                                     replace=True,
                                     # Enhance the samples.
                                     n_samples=lmt_threshold,
                                     random_state=42)

                lmt_upsampled_df_list.append(lmt_df_minority_upsampled)

    lmt_df_train = \
        PD.concat(lmt_upsampled_df_list).sample(frac=1, random_state=42)

    # ------------------------------------------
    # End, balance the classes by up-sampling.
    # ------------------------------------------

    '''
    Columns:
    'UDI', 'Product ID', 'Type', 'Air temperature [K]', 
    'Process temperature [K]', 'Rotational speed [rpm]',
    'Torque [Nm]', 'Tool wear [min]', 'Target', 'Failure Type'
     '''

    lmt_train_array = lmt_df_train.to_numpy(dtype=NP.float64)
    lmt_test_array = lmt_df_test.to_numpy(dtype=NP.float64)

    return lmt_train_array, lmt_test_array

def main():

    ma_forest_on = True
    ma_normalize_data = False
    ma_depth = 12
    ma_n_trees = 6

    ma_train_arr, ma_test_arr = function_load_maintenance_table()

    if ma_train_arr is None:
        return

    ma_x_train_arr = ma_train_arr[:,:-1].copy()
    ma_y_train_arr = ma_train_arr[:, -1].copy() # Failure type.
    ma_x_test_arr = ma_test_arr[:,:-1].copy()
    ma_y_test_arr = ma_test_arr[:, -1].copy() # Failure type.

    if ma_normalize_data:
        # Normalize each column.
        ma_means = NP.mean(ma_x_train_arr, axis=0, keepdims=True)
        ma_stds = NP.std(ma_x_train_arr, axis=0, keepdims=True)
        ma_x_train_arr = (ma_x_train_arr - ma_means) / ma_stds  # Normalize.
        ma_means = NP.mean(ma_x_test_arr, axis=0, keepdims=True)
        ma_stds = NP.std(ma_x_test_arr, axis=0, keepdims=True)
        ma_x_test_arr = (ma_x_test_arr - ma_means) / ma_stds  # Normalize.

    if ma_forest_on:
        ma_forest = REGRESSION_TREE_FOREST(i_dim=ma_x_train_arr.shape[1],
                                           i_depth=ma_depth,
                                           i_n_trees=ma_n_trees,
                                           i_alpha=0.7)
        ma_tree = None

        ma_forest.function_fit(ma_x_train_arr, ma_y_train_arr)

        ma_r2 = ma_forest.function_predict(ma_x_test_arr)
    else:
        ma_tree = REGRESSION_TREE(i_dim=ma_x_train_arr.shape[1],
                                  i_depth=ma_depth)
        ma_forest = None

        ma_tree.function_fit(ma_x_train_arr,
                             ma_y_train_arr)

        ma_r2 = ma_tree.function_predict(ma_x_test_arr)

    ma_test_array = NP.hstack((ma_x_test_arr,
                              ma_r2.reshape(-1, 1)))

    ma_test_array = NP.hstack((ma_test_array,
                               ma_y_test_arr.reshape(-1, 1)))

    ma_column_names = ['Type', 'Air temperature [K]',
                       'Process temperature [K]', 'Rotational speed [rpm]',
                       'Torque [Nm]', 'Tool wear [min]',
                       'Predicted Failure Type', 'Failure Type']

    ma_out_df = PD.DataFrame(ma_test_array,
                             columns= ma_column_names)
    ma_out_df['Error'] = \
        ma_out_df['Predicted Failure Type'] - ma_out_df['Failure Type']

    ma_output_test_csv = 'MAINTENANCE_PREDICTION_TEST_OUTPUT.csv'

    ma_out_df.to_csv(ma_output_test_csv, sep= ',', index=False)
    print(f'Check {ma_output_test_csv}')

    ma_r2 = NP.round(ma_r2)
    ma_abs_error_sum = (abs(ma_r2 - ma_y_test_arr) > 0).sum()

    # ----------------------------------------------
    # Start, Look only for cases of machine failure.
    # ----------------------------------------------

    ma_mask = ma_y_test_arr > 0
    ma_positive_count = ma_mask.sum()
    ma_false_negative = \
        (abs(ma_r2[ma_mask] - ma_y_test_arr[ma_mask]) > 0).sum()

    print(f'Average of absolute error > 0.5 values: '
          f'{ma_abs_error_sum / ma_x_test_arr.shape[0]:.5f}')

    print(f'Average false negative: '
          f'{ma_false_negative / ma_positive_count:.5f}')

    ma_xgboost = XGBOOST_CLASS()
    '''
    function_train(self, t_train_x: NP.array, t_train_y: NP.array,
                       t_test_x: NP.array, t_test_y: NP.array,
                       t_n_iter: int = 14,
                       t_plot = True)
    '''

    ma_xgboost.function_train(ma_x_train_arr, ma_y_train_arr,
                              ma_x_test_arr, ma_y_test_arr)
    ma_r3 = ma_xgboost.function_predict(ma_x_test_arr)

    ma_r3 = NP.round(ma_r3)
    ma_abs_error_sum = (abs(ma_r3 - ma_y_test_arr) > 0).sum()

    ma_false_negative = \
        (abs(ma_r3[ma_mask] - ma_y_test_arr[ma_mask]) > 0).sum()

    print(f'XGBoost Average of absolute error > 0.5 values: '
          f'{ma_abs_error_sum / ma_x_test_arr.shape[0]:.5f}')

    print(f'XGBoost Average false negative: '
          f'{ma_false_negative / ma_positive_count:.5f}')


if __name__ == '__main__':
    main()
