#from bartpy.extensions.baseestimator import ResidualBART as BARTPY_ResidualBART
# pip install git+https://github.com/JakeColtman/bartpy.git --upgrade
from bartpy.sklearnmodel import SklearnModel as BARTPY_SklearnModel
import numpy as NP
import pandas as PD

BART_ABALONE_file_name = 'BART.pt'

class BART_CLASS():
    def __init__(self, i_base_file_name='ABALONE', i_n=2000):
        # Deep trees, alpha=0.99, beta=1.
        # Shallow trees, alpha=0.9, beta=3.
        # self.member_model = \
        #     BARTPY_SklearnModel(n_samples=i_n, n_burn=50, n_trees=4,
        #                         alpha=0.9, beta=3)
        # self.member_model = \
        #     BARTPY_SklearnModel(n_samples=i_n, n_burn=50, n_trees=4,
        #                         alpha=0.99, beta=1)
        self.member_model = \
            BARTPY_SklearnModel(n_samples=i_n, n_burn=50, n_trees=4,
                                alpha=0.95, beta=2)

    def function_fit(self, f_x, f_y):
        self.member_model.fit(X=f_x, y=f_y)

    def function_predict(self, p_x):
        return self.member_model.predict(X=p_x)

    def function_score(self, s_x, s_y):
        return self.member_model.score(X=s_x, y=s_y)

def function_load_abalone_table(lat_file_name: str = "abalone.csv"):
    try:
        lat_df = PD.read_csv(lat_file_name)
    except Exception as lat_ex:
        lat_df = None
        print(lat_ex)

    if lat_df is None:
        print(f'\33[31mERROR: Could not load {lat_file_name}\33[00m')
        return None

    # Mapping words to numbers.
    lat_map_dict = {'F': 1, 'M': 2, 'I': 3 }
    # Table columns are: ['Sex', 'Length', 'Diameter', 'Height',
    #                     'WholeWeight', 'ShuckedWeight',
    #                     'VisceraWeight', 'ShellWeight', 'Rings']

    lat_df['Sex'] = lat_df['Sex'].map(lat_map_dict)
    lat_array = lat_df.to_numpy(dtype=NP.float64)
    return lat_array

def main():

    ma_normalize_data = False

    ma_input_arr = function_load_abalone_table()

    if ma_input_arr is None:
        return

    ma_x_arr = ma_input_arr[:,:-1].copy()
    ma_y_arr = ma_input_arr[:, -1].copy() # Abalone rings.

    if ma_normalize_data:
        # Normalize each column.
        ma_means = NP.mean(ma_x_arr, axis=0, keepdims=True)
        ma_stds = NP.std(ma_x_arr, axis=0, keepdims=True)
        ma_x_arr = (ma_x_arr - ma_means) / ma_stds  # Normalize.

    ma_split = ma_x_arr.shape[0] - ma_x_arr.shape[0] // 10
    # ma_bart = BART_CLASS(i_n=500)
    # ma_bart = BART_CLASS(i_n=1000)
    # ma_bart = BART_CLASS(i_n=2000)
    ma_bart = BART_CLASS(i_n=ma_split)
    ma_bart.function_fit(ma_x_arr[:ma_split,:],
                         ma_y_arr[:ma_split])

    ma_r_bart = \
        ma_bart.function_predict(ma_x_arr[ma_split:,:])
    ma_abs_error_sum_bart = abs(ma_r_bart - ma_y_arr[ma_split:]).sum()

    print(f'Average of absolute BART error values: '
          f'{ma_abs_error_sum_bart / (ma_x_arr.shape[0] - ma_split):.5f}')

if __name__ == '__main__':
    main()
