
import numpy as NP
import pandas as PD
from typing import Union as TYPING_Union

class REGRESSION_TREE_NODE:
    def __init__(self, i_dim: int, i_depth: int,
                 i_min_n_for_split: int = 2,
                 i_min_eigenvalue_ratio: float = 0.005,
                 # 1 is for discrete labels.
                 i_min_std_per_split: float = 1.0,
                 # range is usually worse than summation,
                 # but not in all regression problems.
                 i_range_instead_of_projection_sum: bool = False):

        if i_dim < 2 or i_dim > 1000 or \
                i_depth < 1 or i_depth > 32:
            self.member_dim = 0
            self.member_max_depth = 0
            return

        self.member_avg_x = NP.zeros(i_dim, dtype=NP.float64)
        # Kept for future applications.
        self.member_covariance_matrix = \
            NP.zeros((i_dim, i_dim), dtype=NP.float64)
        self.member_w = NP.zeros(i_dim, dtype=NP.float64)

        self.member_dim = i_dim
        self.member_max_depth = i_depth
        # Kept for future applications.
        self.member_n = 0
        self.member_avg_y = NP.float64(0.0)
        self.member_std_y = NP.float64(0.0)
        self.member_min_n_for_split = i_min_n_for_split
        self.member_min_eigenvalue_ratio = i_min_eigenvalue_ratio
        self.member_min_std_per_split = i_min_std_per_split
        self.member_range_instead_of_projection_sum = \
            i_range_instead_of_projection_sum
        self.member_left = None
        self.member_right = None

    # Reserved for trimming.
    def function_destroy(self):
        if self.member_left is not None:
            self.member_left.function_destroy()
            del self.member_left # Will be done by the Garbage Disposal.
            self.member_left = None

        if self.member_right is not None:
            self.member_right.function_destroy()
            del self.member_right # Will be done by the Garbage Disposal.
            self.member_right = None

    def function_fit(self, f_in_x: NP.ndarray[NP.float64],
                     f_in_y: NP.ndarray[NP.float64],
                     f_depth: int = 0) -> \
            TYPING_Union[None, NP.ndarray[NP.float64]]:

        if f_in_x.ndim != 2:
            print("\33[91mERROR: x is not two dimensional.\33[00m")
            return None

        if f_in_x.shape[0] < 1:
            return None

        self.member_avg_y = NP.mean(f_in_y)
        self.member_std_y = NP.std(f_in_y)
        self.member_avg_x = NP.mean(f_in_x, axis=0)
        self.member_n = f_in_x.shape[0]

        f_results = NP.empty(f_in_x.shape[0], dtype=NP.float64)
        f_results[:] = self.member_avg_y

        if f_in_x.shape[0] < self.member_min_n_for_split:
            return f_results

        f_y = f_in_y - self.member_avg_y
        f_x = f_in_x - self.member_avg_x

        # -------------------------------------------------
        # Start, choose the best y-splitting x eigenvector.
        # -------------------------------------------------

        self.member_covariance_matrix = \
            f_x.T @ f_x / f_x.shape[0]

        f_eigenvalues, f_eigenvectors = \
            NP.linalg.eig(self.member_covariance_matrix)
        # Sort and then order from big to small instead of
        # small to big.
        f_sorted_idx = \
            NP.argsort(f_eigenvalues, kind='mergesort')[::-1]
        f_eigenvalues, f_eigenvectors = \
            f_eigenvalues[f_sorted_idx], \
                f_eigenvectors[:, f_sorted_idx]

        # Mask not allowing eigenvectors with too small eigenvalues.
        f_mask = \
            f_eigenvalues > (f_eigenvalues[0] *
                             self.member_min_eigenvalue_ratio)
        f_candidate_vectors = f_eigenvectors[:, f_mask]
        # Broadcasting on dimension with sample index.
        f_sample_norms = NP.clip(NP.linalg.norm(f_x, axis=1),
                                 a_min=0.000000000001, a_max=None)

        # w = (x - average_x) * (y - average_y) / Norm(x - average_x)
        # varies well along direction where one side has positive
        # delta_y = y - average_y and one side has negative delta_y.
        # We need to project the w vectors on the eigenvectors and
        # see which one splits the space best.
        # Alternatively, we can take a convex function f of
        # the norm of x - average_x if we do want also the geometry
        # of x to help.
        # w = (x - average_x) * (y - average_y) / Covex(x - average_x)

        f_weighted_samples = (f_x.T * f_y / f_sample_norms).T

        if self.member_range_instead_of_projection_sum:
            f_weights = \
                NP.abs(NP.ptp(f_weighted_samples @ f_candidate_vectors,
                              axis=0))
        else:
            f_weights = \
                NP.abs((f_weighted_samples @ f_candidate_vectors).
                       sum(axis=0))

        f_best_idx = f_weights.argmax()
        # self.member_w  is the splitting vector.
        self.member_w = f_candidate_vectors[:, f_best_idx]

        # -------------------------------------------------
        # End, choose the best y-splitting x eigenvector.
        # -------------------------------------------------

        if f_depth < self.member_max_depth and \
                self.member_std_y > self.member_min_std_per_split:

            # -------------------------
            # Start, split the samples.
            # -------------------------

            f_mask = (f_x @ self.member_w) > 0
            f_not = NP.logical_not(f_mask)
            f_positive_samples_x = f_x[f_mask, :]
            f_positive_samples_y = f_y[f_mask]
            f_negative_samples_x = f_x[f_not, :]
            f_negative_samples_y = f_y[f_not]

            # -------------------------
            # End, split the samples.
            # -------------------------

            if f_positive_samples_x.shape[0] > 0:
                if self.member_right is None:
                    self.member_right = \
                        REGRESSION_TREE_NODE(self.member_dim,
                                             self.member_max_depth)
                f_results[f_mask] += \
                    self.member_right. \
                        function_fit(f_positive_samples_x,
                                      f_positive_samples_y, f_depth+1)

            if f_negative_samples_x.shape[0] > 0:
                if self.member_left is None:
                    self.member_left = \
                        REGRESSION_TREE_NODE(self.member_dim,
                                             self.member_max_depth)
                f_results[f_not] += \
                    self.member_left. \
                        function_fit(f_negative_samples_x,
                                      f_negative_samples_y, f_depth+1)

        return f_results

    def function_predict(self, p_in_x: NP.ndarray[NP.float64],
                         p_depth: int = 0) -> \
            TYPING_Union[None, NP.ndarray[NP.float64]]:

        if p_in_x.ndim != 2:
            print("\33[91mERROR: x is not two dimensional.\33[00m")
            return None

        if p_in_x.shape[0] < 1:
            return None

        p_results = NP.empty(p_in_x.shape[0], dtype=NP.float64)
        p_results[:] = self.member_avg_y

        if p_in_x.shape[0] < self.member_min_n_for_split:
            return p_results

        p_x = p_in_x - self.member_avg_x

        if p_depth < self.member_max_depth:

            # -------------------------
            # Start, split the samples.
            # -------------------------

            p_mask = (p_x @ self.member_w) > 0
            p_not = NP.logical_not(p_mask)

            p_positive_samples_x = p_x[p_mask, :]
            p_negative_samples_x = p_x[p_not, :]

            # -------------------------
            # End, split the samples.
            # -------------------------

            if p_positive_samples_x.shape[0] > 0:
                if self.member_right is not None:

                    p_results[p_mask] += \
                        self.member_right. \
                            function_predict(p_positive_samples_x,
                                             p_depth + 1)

            if p_negative_samples_x.shape[0] > 0:
                if self.member_left is not None:
                    p_results[p_not] += \
                        self.member_left. \
                            function_predict(p_negative_samples_x,
                                             p_depth + 1)

        return p_results

class REGRESSION_TREE:
    def __init__(self, i_dim: int, i_depth: int):

        if i_dim < 2 or i_dim > 1000 or i_depth < 1 or i_depth > 32:

            if i_dim < 2 or i_dim > 1000:
                print('\33[91mInitialization error. '
                      'The dimension must be'
                      ' between 2 and 1000 inclusive.\33[00m')

            if i_depth < 1 or i_depth > 32:
                print('\33[91mError, tree depth is between 1 '
                      'and 32 inclusive.\33[00m')

            self.member_root = None
            self.member_dim = 0
            self.member_max_depth = 0

            return

        self.member_dim = i_dim
        self.member_max_depth = i_depth
        self.member_root = REGRESSION_TREE_NODE(i_dim, i_depth)

    def function_fit(self, f_in_x: NP.ndarray[NP.float64],
                     f_in_y: NP.ndarray[NP.float64]) -> \
            TYPING_Union[None, NP.ndarray[NP.float64]]:

        if self.member_root is None:
            return None

        return self.member_root.function_fit(f_in_x, f_in_y)


    def function_predict(self, p_in_x: NP.ndarray[NP.float64]) -> \
            TYPING_Union[None, NP.ndarray[NP.float64]]:

        if self.member_root is None:
            return None

        return self.member_root.function_predict(p_in_x)

class REGRESSION_TREE_FOREST:
    def __init__(self, i_dim : int, i_depth: int = 9, i_n_trees:int = 10,
                 i_alpha: float=0.5):

        if i_dim < 2 or i_dim > 1000 or i_depth < 1 or i_depth > 32 or \
                i_n_trees < 1 or i_n_trees > 50:

            if i_depth < 1 or i_depth > 32:
                print('\33[91mError, tree depth is between 1 '
                      'and 32 inclusive.\33[00m')

            if i_dim < 2 or i_dim > 1000:
                print('\33[91mError, dimension is between 2 '
                      'and 1000 inclusive.\33[00m')

            if i_n_trees < 1 or i_n_trees > 50:
                print('\33[91mError, number of trees is between 1 '
                      'and 50 inclusive.\33[00m')

            self.member_dim = 0
            self.member_n_trees = 0
            self.member_max_depth = 0
            return

        self.member_n_trees = i_n_trees
        self.member_dim = i_dim
        self.member_max_depth = i_depth
        self.member_alpha = NP.float64(i_alpha)

        i_tree_list = []

        for i in range(i_n_trees):
            i_tree_list.append(REGRESSION_TREE(i_dim, i_depth))

        self.member_trees = NP.array(i_tree_list)


    def function_fit(self, f_in_x: NP.ndarray[NP.float64],
                     f_in_y: NP.ndarray[NP.float64]) -> \
            TYPING_Union[None, NP.ndarray[NP.float64]]:

        f_y = f_in_y.copy()

        f_sum_r = NP.zeros(f_in_x.shape[0], dtype=NP.float64)

        for i in range(self.member_n_trees):
            f_r = self.member_alpha * \
                  self.member_trees[i].function_fit(f_in_x, f_y)
            f_sum_r += f_r
            f_y -= f_r

        return f_sum_r

    def function_predict(self, p_in_x: NP.ndarray[NP.float64]) ->\
            TYPING_Union[None, NP.ndarray[NP.float64]]:

        p_sum_r = NP.zeros(p_in_x.shape[0], dtype=NP.float64)

        for i in range(self.member_n_trees):
            p_r = self.member_alpha *\
                  self.member_trees[i].function_predict(p_in_x)
            p_sum_r += p_r

        return p_sum_r

def function_load_abalone_table(lat_file_name: str = "abalone.csv"):
    try:
        lat_df = PD.read_csv(lat_file_name)
    except Exception as lat_ex:
        lat_df = None
        print(lat_ex)

    if lat_df is None:
        print(f'\33[31mERROR: Could not load {lat_file_name}\33[00m')
        return None

    # Mapping words to numbers.
    lat_map_dict = {'F': 1, 'M': 2, 'I': 3 }
    # Table columns are: ['Sex', 'Length', 'Diameter', 'Height',
    #                     'WholeWeight', 'ShuckedWeight',
    #                     'VisceraWeight', 'ShellWeight', 'Rings']

    lat_df['Sex'] = lat_df['Sex'].map(lat_map_dict)
    lat_array = lat_df.to_numpy(dtype=NP.float64)
    return lat_array

def main():

    ma_forest_on = True
    ma_normalize_data = False
    ma_depth = 6
    ma_n_trees = 4

    ma_input_arr = function_load_abalone_table()

    if ma_input_arr is None:
        return

    ma_x_arr = ma_input_arr[:,:-1].copy()
    ma_y_arr = ma_input_arr[:, -1].copy() # Abalone rings.

    if ma_normalize_data:
        # Normalize each column.
        ma_means = NP.mean(ma_x_arr, axis=0, keepdims=True)
        ma_stds = NP.std(ma_x_arr, axis=0, keepdims=True)
        ma_x_arr = (ma_x_arr - ma_means) / ma_stds  # Normalize.

    ma_split = ma_x_arr.shape[0] - ma_x_arr.shape[0] // 10

    if ma_forest_on:
        ma_forest = REGRESSION_TREE_FOREST(i_dim=ma_x_arr.shape[1],
                                           i_depth=ma_depth,
                                           i_n_trees=ma_n_trees)
        ma_tree = None

        ma_forest.function_fit(ma_x_arr[:ma_split,:],
                               ma_y_arr[:ma_split])

        ma_r2 = ma_forest.function_predict(ma_x_arr[ma_split:,:])
    else:
        ma_tree = REGRESSION_TREE(i_dim=ma_x_arr.shape[1],
                                  i_depth=ma_depth)
        ma_forest = None

        ma_tree.function_fit(ma_x_arr[:ma_split,:],
                             ma_y_arr[:ma_split])

        ma_r2 = ma_tree.function_predict(ma_x_arr[ma_split:,:])

    ma_test_array = NP.hstack((ma_x_arr[ma_split:, :],
                              ma_r2.reshape(-1, 1)))

    ma_test_array = NP.hstack((ma_test_array,
                               ma_y_arr[ma_split:].reshape(-1, 1)))
    ma_column_names = ['Sex', 'Length', 'Diameter', 'Height',
                       'WholeWeight', 'ShuckedWeight',
                       'VisceraWeight', 'ShellWeight',
                       'Predicted_Rings', 'GT_Rings']

    ma_out_df = PD.DataFrame(ma_test_array,
                             columns= ma_column_names)
    ma_out_df['Error'] = \
        ma_out_df['Predicted_Rings'] - ma_out_df['GT_Rings']

    ma_output_test_csv = 'ABALONE_TEST_OUTPUT.csv'

    ma_out_df.to_csv(ma_output_test_csv, sep= ',', index=False)
    print(f'Check {ma_output_test_csv}')

    ma_abs_error_sum = abs(ma_r2 - ma_y_arr[ma_split:]).sum()

    print(f'Average of absolute error values: '
          f'{ma_abs_error_sum / (ma_x_arr.shape[0] - ma_split):.5f}')

if __name__ == '__main__':
    main()
