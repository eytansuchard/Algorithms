import xgboost as XGBOOST
import numpy as NP

class XGBOOST_CLASS(object):

    def __init__(self, i_xgboost_file_name: str='maintenance_prediction_xgboost.bin'):
        super(XGBOOST_CLASS, self).__init__()
        self.member_model = None
        self.member_file_name = i_xgboost_file_name
        self.member_params_dict = \
            { 'eta': 0.3, # Learning rate.
              'gamma': 0.1, # Loss reduction that justifies a leaf.
              'max_depth': 16,
              'min_child_weight': 1,
              'max_delta_step': 0.7, # Number of classes imbalance.
              'subsample': 0.7,
              'lambda': 0.1, # Weight regularization.
              'alpha': 0.1, # Weight regularization.
              #'objective': 'binary:logistic',
              'nthread': 4,
              'eval_metric': 'rmse'
              #'eval_metric': 'mae'
            }

        self.member_model = XGBOOST.Booster(self.member_params_dict)

        try:
            self.member_model.load_model(self.member_file_name)
        except:
            print('Initializing a new XGBoost model.')


    def function_train(self, t_train_x: NP.array, t_train_y: NP.array,
                       t_test_x: NP.array, t_test_y: NP.array,
                       t_n_iter: int = 14,
                       t_plot = True):

        t_dtrain = XGBOOST.DMatrix(t_train_x, label=t_train_y)
        t_dtest = XGBOOST.DMatrix(t_test_x, label=t_test_y)
        t_evallist = [(t_dtrain, 'train'), (t_dtest, 'eval')]
        self.member_model = XGBOOST.train(params=self.member_params_dict,
                                          dtrain=t_dtrain,
                                          num_boost_round=t_n_iter,
                                          evals=t_evallist,
                                          early_stopping_rounds=10) # ,
                                          # xgb_model=self.member_file_name)

        self.member_model.save_model(self.member_file_name)

        if t_plot:
            XGBOOST.plot_importance(self.member_model)

        return


    def function_predict(self, p_x, p_use_best=True):
        p_d = XGBOOST.DMatrix(p_x)

        if p_use_best:
            p_y = \
                self.member_model.predict(p_d,
                                          iteration_range=
                                          (0, self.member_model.best_iteration + 1))
        else:
            p_y = self.member_model.predict(p_d)

        return p_y
