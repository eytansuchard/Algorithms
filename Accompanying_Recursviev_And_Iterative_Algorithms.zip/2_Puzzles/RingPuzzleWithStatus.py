
RING_PUZZLE_ring_status = ''

def RING_PUZZLE_solve(s_n: int, s_forward: bool = True):

    global RING_PUZZLE_ring_status

    if s_n < 1:
        return 0

    if s_forward:
        RING_PUZZLE_ring_status = \
            RING_PUZZLE_ring_status[:s_n - 1] + 'B' + RING_PUZZLE_ring_status[s_n:]
        print(f'Thread up through back {s_n}, '
              f'ring status {RING_PUZZLE_ring_status[::-1]}')
        s_count = RING_PUZZLE_solve(s_n - 1, False)
        RING_PUZZLE_ring_status = \
            RING_PUZZLE_ring_status[:s_n - 1] + '-' + RING_PUZZLE_ring_status[s_n:]
        print(f'Thread down through front {s_n}, '
              f'ring status {RING_PUZZLE_ring_status[::-1]}')
        s_count += RING_PUZZLE_solve(s_n - 1, True)

        return s_count + 2
    else:
        s_count = RING_PUZZLE_solve(s_n - 1, False)
        RING_PUZZLE_ring_status = \
            RING_PUZZLE_ring_status[:s_n - 1] + 'F' + RING_PUZZLE_ring_status[s_n:]
        print(f'Thread up through front {s_n}, '
              f'ring status {RING_PUZZLE_ring_status[::-1]}')
        s_count += RING_PUZZLE_solve(s_n - 1, True)
        RING_PUZZLE_ring_status = \
            RING_PUZZLE_ring_status[:s_n - 1] + '-' + RING_PUZZLE_ring_status[s_n:]
        print(f'Thread down through back {s_n}, '
              f'ring status {RING_PUZZLE_ring_status[::-1]}')
        return s_count + 2

def main():
    global RING_PUZZLE_ring_status

    ma_n  = 4
    RING_PUZZLE_ring_status = '-' * ma_n + ' '

    ma_count = RING_PUZZLE_solve(ma_n)
    print(f'Number of moves: {ma_count}')
    print('The left side of the thread is held fixed during all steps.')
    print('The status is B if the thread is through the back of the ring.')
    print('The status is F if the thread is through the front of the ring.')


if __name__ == '__main__':
    main()
