
def RING_PUZZLE_solve(s_n: int, s_forward: bool = True):

    if s_n < 1:
        return 0

    if s_forward:
        print(f'Thread up through back {s_n}')
        s_count = RING_PUZZLE_solve(s_n - 1, False)
        print(f'Thread down through front {s_n}')
        s_count += RING_PUZZLE_solve(s_n - 1, True)

        return s_count + 2
    else:
        s_count = RING_PUZZLE_solve(s_n - 1, False)
        print(f'Thread up through front {s_n}')
        s_count += RING_PUZZLE_solve(s_n - 1, True)
        print(f'Thread down through back {s_n}')

        return s_count + 2

def main():
    ma_count = RING_PUZZLE_solve(3)
    print(f'Number of moves: {ma_count}')
    print('The left side of the thread is held fixed during all steps.')

if __name__ == '__main__':
    main()
