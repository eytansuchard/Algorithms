
from typing import Union as TYPING_Union
import numpy as NP

# Just print the steps. This is the easiest recursive process.
def HANOI_PUZZLE_solve(s_n: int = 5, s_a: int = 1, s_b: int = 2, s_c: int = 3):

    if s_n < 1:
        print('Error!')
        return

    if 1 == s_n:
        print(f'Move {s_a} to {s_c}')
        return

    # Move n-1 disks from a to b via c.
    HANOI_PUZZLE_solve(s_n-1, s_a, s_c, s_b)
    # Move the n^th disk from a to c.
    print(f'Move {s_a} to {s_c}')
    # Move n-1 disks from b to c via a.
    HANOI_PUZZLE_solve(s_n-1, s_b, s_a, s_c)


# Get the Hanoi state of each disk without performing all the steps.
# Writing this function requires more understanding of recursive functions.
def HANOI_PUZZLE_position(p_n: int = 5, p_m: int = 0, p_a: int = 1, p_b: int = 2, p_c: int = 3,
                          p_arr: TYPING_Union[NP.ndarray, None] = None):

    if p_n < 1:
        print('Error!')
        return

    if p_arr is None:
        # All disks are on pillar 1, 0 when zero based.
        p_arr = NP.empty(shape=(3, p_n), dtype=NP.int32)
        p_arr[p_a - 1, 0: p_n] = 1
        p_arr[p_b - 1, 0: p_n] = 0
        p_arr[p_c - 1, 0: p_n] = 0

    if 0 == p_m:
        # All disks are in the first pillar.
        return p_arr

    p_mid = 1 << (p_n - 1)

    if p_m < p_mid:
        return HANOI_PUZZLE_position(p_n-1, p_m, p_a, p_c, p_b, p_arr)

    # -------------------------------------------------------------------------------
    # Start: begin with n-1 disks transferred to position b and disk n in position c.
    # -------------------------------------------------------------------------------
    # p_m >= p_mid:
    # All n disks where transferred from position a.
    p_arr[p_a - 1, 0: p_n] = 0
    # n-1 disks where transferred to position b.
    p_arr[p_b - 1, 0: p_n - 1] = 1
    p_arr[p_b - 1, p_n - 1] = 0
    # Only disk n was transferred to position c.
    p_arr[p_c - 1, 0: p_n - 1] = 0
    p_arr[p_c - 1, p_n - 1] = 1
    # -------------------------------------------------------------------------------
    # End: begin with n-1 disks transferred to position b and disk n in position c.
    # -------------------------------------------------------------------------------

    if p_mid == p_m:
        return p_arr

    return HANOI_PUZZLE_position(p_n-1, p_m - p_mid, p_b, p_a, p_c, p_arr)

def main():

    ma_n = 4

    for i in range(0, 1 << ma_n):
        ma_arr = HANOI_PUZZLE_position(ma_n, i)

        for k in range(ma_n):
            print(f'{k + 1 if ma_arr[0, k] else "*"}'
                  f'{k + 1 if ma_arr[1, k] else "*"}'
                  f'{k + 1 if ma_arr[2, k] else "*"}')

        print('-----------')

    print('Done.')

if __name__ == '__main__':
    main()
